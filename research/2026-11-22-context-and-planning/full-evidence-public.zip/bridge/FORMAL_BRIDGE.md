# Formal bridge: a map, a runnable process, and knowledge about that process

The useful connection to the microscopy discussion is a question about abstraction loss. It is not evidence that Reactome caused ControllerGate's failures or that molecular crowding is the missing software mechanism.

## Credit the existing representation

Reactome already distinguishes compartments, molecular modifications, complexes, catalysts, regulation, alternatives and direct versus organism-inferred evidence. Its official data-model documentation expressly describes these features. A critique of a context-free pairwise graph must not be misattributed to Reactome's actual schema. [R1]

ControllerGate likewise already has conjunctive required inputs, unknown/hypothesis states, direct versus inferred records and safe nonauthorizing interlocks. An earlier primitive/runtime path also implements resource balance, compartment checks and canonical staged mechanism rehearsals. The inspected Batch103 acquisition runner and source-grounded shadow generator do not use all those capabilities: the latter performs the narrower operation-label hash chain. This is a path/integration distinction, not a claim that the project never implemented resource or context semantics. [CG1–CG8]

## Separate three models

1. **Structural model:** entities, states, compartments, reactions, prerequisites and dependencies. A reaction with two required inputs is an AND relation. Replacing it by two separately sufficient arrows changes its meaning.
2. **Execution model:** a state space S, admissibility condition E(a,s), transition T(s,a), resources, timing, outcomes and failure modes. A structural arrow does not supply rates, quantities, physical contact probability, consumption rules or software provider behavior.
3. **Observation model:** the measurable result O(s,a), its schema, missingness, context, uncertainty and the relation between a recorded result and a claim. An output file's existence is not the same as a verified predicate, and an unavailable observation is not a negative result of the intended experiment.

Spatial location can be part of S, but the software analogue needs a concrete meaning, such as sandbox/provider/service identity. It is not a claim that software has cellular crowding. Stoichiometry or a resource label alone is insufficient: a simulator needs explicit quantities and update rules, while an acquisition planner needs declared prerequisites and costs.

## Unknown, blocked, and enabled are different

Let B be the set of worlds consistent with the available observations. Define an action's physical readiness by E(a,s). Then:

- It is known enabled if E(a,s) holds for every s in B.
- It is known blocked if E(a,s) fails for every s in B.
- Its readiness is unresolved otherwise.

A missing field does not shrink B by itself. A valid observation of an unavailable conjunctive route can imply `not(A and B)` without proving `not A` or `not B` separately. The executable control preserves that distinction. It makes no claim that the finite B covers all real alternatives.

A safety gate may correctly refuse authorization in both the blocked and unresolved cases. The improvement is to retain different reasons and acquisition options, not to weaken the gate. A known missing prerequisite may call for a permitted materialization action. An unknown prerequisite may call for a discriminating observation. A forbidden action is not made legal by information gain. A proof of dependency is not a proof that the process will eventually run.

## Safety, evidence quality and liveness

Safety asks whether an inadmissible action is prevented. Evidence quality asks whether an observed result is correctly interpreted under its context. Liveness asks whether progress can occur or must eventually occur under the permitted actions and environment assumptions. A scheduler that always abstains can be safe and useless; a scheduler that always attempts every vault can preserve authorization while wasting its budget. The current synthetic results illustrate that distinction without claiming to solve real liveness.

An unreachable conclusion requires both a specified model and a proof that no admissible acquisition sequence can succeed in that model. Outside a complete declared model, the appropriate result may instead be `NO_REGISTERED_ROUTE_SUPPORTED`, `OBSERVATION_UNAVAILABLE`, or `BUDGET_EXHAUSTED`. Those are not claims that nature or the entire software system has no route.

## Freeze a policy rather than every action

A conditional policy is a predeclared function of the paid observation history and remaining budget:

    action = policy(public_model, observed_history, remaining_budget).

Preregistration can freeze that function, its legal action set, model assumptions, tie rules, costs and stopping criteria before outcomes. It need not forbid every observation-dependent change of action. Planning in the presence of sensing is established work; Levesque's 1996 formalization explicitly distinguishes physical actions from sensing and analyzes plans with missing or redundant sensing actions. [R2]

The inspected Batch103 runner is more restrictive: it creates a rank-derived score and requires the selected action to match the next frozen list entry. This experiment therefore cannot establish an advantage of adaptive context-sensitive selection. The new control isolates that missing experimental capability rather than claiming that AND prerequisites or observation states are newly invented.

## What the new executable control proves—and does not

The finite model supplies persistent Boolean prerequisites and noiseless costed observations. Exhaustive enumeration shows which conditional policies preserve attainable-pair coverage while using fewer actions. A generic exact solver and the reaction-schema adapter have identical models and traces. Renaming the biology-related metadata leaves the result unchanged.

This is a constructive improvement in local acquisition semantics and a negative result for labels as an extra source of power. It does not establish a better causal model, a molecular mechanism, or cross-candidate ControllerGate gain. Most cost savings occur on declared impossible cases; explicit preflight probes add little overall and cost more on successful cases than adaptive vault reading alone. Those tradeoffs are part of the result.

The prior failure records still require separate explanation. Contact-to-ownership errors, semantic projection errors, missing counterfactuals and actual execution shortages cannot be repaired simply by enriching a reaction diagram. Correct semantics must reach the executed call path before an adaptive policy can safely use them.

## Sources

[R1] Reactome's official data model: https://reactome.org/documentation/data-model — compartments, state distinctions, complexes, catalysis, regulation and inference provenance; retrieved Nov23 2026. Web references available to the parent: `turn231595064view0`, `turn440913438search0`.

[R2] H. J. Levesque, *What is planning in the presence of sensing?* (AAAI 1996), author-hosted primary PDF: https://www.cs.toronto.edu/kr/papers/sensing.pdf. Web references: `turn291003665view0`, `turn231595064search6`.

[CG1–CG5] Exact repository sources and physical line numbers are in `SOURCE_LEDGER.md`. No novelty claim is made for AND prerequisites, epistemic states, conditional planning or dynamic programming.
