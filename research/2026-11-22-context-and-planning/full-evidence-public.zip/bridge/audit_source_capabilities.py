"""Small source-level controls, separate from the frozen synthetic experiment.

Imports only the two pure, copied source modules. Does not execute a candidate,
historical campaign, workflow, repository mutation, or shadow generator.
"""
from copy import deepcopy
from datetime import datetime,timezone
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parent


def load(name,filename):
    spec=importlib.util.spec_from_file_location(name,ROOT/'source_snapshot'/filename)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    return module


def main():
    manifest=json.loads((ROOT/'source_snapshot_manifest.json').read_text())
    for row in manifest:
        assert hashlib.sha256((ROOT/row['snapshot_path']).read_bytes()).hexdigest()==row['sha256']
    planner=load('reviewed_reactome_planner','reactome_planner_v1.py')
    compiler=load('reviewed_reactome_compiler','reactome_source_grounded_scenarios_v2.py')
    actions=[{'intervention_id':'A','legal':True,'cost':1,'expected_information_gain':2.0},
             {'intervention_id':'B','legal':True,'cost':1,'expected_information_gain':1.0}]
    base={'source_hash':'controlled-source','reaction':'reaction-1','blocked':False,
          'missing_prerequisites':[],'alternative_pathways':[]}
    records=[]
    for name,relation,state,budget,inventory in [
        ('baseline',base,{'opened_outcome_count':0},1,actions),
        ('blocked_with_missing_prerequisite',{**base,'blocked':True,'missing_prerequisites':['A']},{'opened_outcome_count':0},1,actions),
        ('alternate_route_recommended',{**base,'alternative_pathways':['B']},{'opened_outcome_count':0},1,actions),
        ('maintenance_counts_changed',base,{'opened_outcome_count':12,'unavailable_selection_count':7},1,actions),
        ('positive_control_changed_score',base,{'opened_outcome_count':0},1,[{**actions[0],'expected_information_gain':0.0},actions[1]]),
        ('zero_budget',base,{'opened_outcome_count':0},0,actions),
    ]:
        result=planner.plan_intervention(candidate='controlled-case',maintenance_state=state,
            public_rpir_relations=[relation],legal_interventions=inventory,budget=budget).record()
        records.append({'case':name,'decision':result})
    assert [r['decision']['selected_intervention'] for r in records]==['A','A','A','A','B',None]
    first={field:{'state':'SOURCE_VALUE','value':[{'quantity':1,'context':'left'}]}
           for field in compiler.WRAPPED_REACTION_FIELDS}
    second={field:{'state':'SOURCE_VALUE','value':[{'quantity':1000,'context':'right'}]}
            for field in compiler.WRAPPED_REACTION_FIELDS}
    first_sequence=compiler.operation_sequence(first)
    second_sequence=compiler.operation_sequence(second)
    assert first_sequence==second_sequence
    receipt={'status':'PASS_SOURCE_BEHAVIOR_REPRODUCED','completed_utc':datetime.now(timezone.utc).isoformat(),
             'repository_commit':'38897b79588f3ff4b1b9002eedc299a9bcf05140',
             'sources':manifest,'planner_controls':records,
             'compiler_relation_value_control':{'both_have_same_source_field_presence':True,
                 'values_differ':True,'operation_sequences_equal':True,'operations':first_sequence},
             'findings':[
                 {'kind':'EXECUTED_PURE_FUNCTION_CONTROL','finding':'Changing blocked/missing/alternative and maintenance metadata does not change ranking when legal inventory, gain, cost and IDs are fixed. These metadata are retained in receipts. This helper still respects declared legality and budget and grants no patch authority.','source':'reactome_planner_v1.py','lines':[89,125]},
                 {'kind':'EXECUTED_PURE_FUNCTION_CONTROL','finding':'Operation families depend on source-value field presence; changing relation payload quantities or context while preserving field presence leaves this operation sequence unchanged. The compiler still records source lineage and expressly disallows causal authority.','source':'reactome_source_grounded_scenarios_v2.py','lines':[124,148]},
                 {'kind':'STATIC_CODE_INSPECTION','finding':'Batch103 runtime encodes fixed remaining-list rank as information gain and rejects deviations from its next frozen selection; unavailable vaults are recorded and the loop continues. Early success stopping exists, but observation-conditioned reordering does not.','source':'run_batch103_planner_arm.py','lines':[104,172]},
                 {'kind':'STATIC_CODE_INSPECTION','finding':'The inspected R3 shadow loop hashes source/operation labels and emits its verification record in the same generation loop. This path provides structural hash-chain receipts, not a resource/compartment dynamics simulation or an independent physical validator.','source':'build_batch103_reactome_closure.py','lines':[477,535]}],
             'scope':'Evidence about these exact pure functions and inspected call sites. No claim of global absence elsewhere, no explanation of every historical failure, no fresh provider run.'}
    (ROOT/'source_capability_audit.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':receipt['status'],'planner_controls':len(records),'compiler_controls':1,
                      'source_sha256s_verified':len(manifest),'output':'source_capability_audit.json'},indent=2))


if __name__=='__main__': main()
