"""Freeze first, then evaluate once; standard-library-only finite control."""
import argparse
from collections import Counter
from datetime import datetime,timezone
from fractions import Fraction
import hashlib
import io
import json
from pathlib import Path
import sys
import unittest

from conditional_acquisition import Model, ConditionalPolicy, compile_reaction_rows, best_frozen_order, run_episode

ROOT=Path(__file__).resolve().parent
SEALED=('experiment_spec.json','conditional_acquisition.py','test_conditional_acquisition.py','run_experiment.py','verify_experiment.py')


def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value): path.write_text(json.dumps(value,indent=2,sort_keys=True,allow_nan=False)+'\n')


def freeze():
    target=ROOT/'FROZEN_DESIGN.json'
    if target.exists(): raise RuntimeError('Refusing to replace frozen design')
    for name in SEALED:
        if not (ROOT/name).is_file(): raise RuntimeError(f'Missing frozen source: {name}')
    receipt={'schema':'LocalDesignSealV1','created_utc':datetime.now(timezone.utc).isoformat(),
             'source_hashes':{name:sha(ROOT/name) for name in SEALED},
             'evaluation_has_not_run':not (ROOT/'results.json').exists(),
             'scope':'Local integrity seal; not publisher authentication or external preregistration.'}
    if not receipt['evaluation_has_not_run']: raise RuntimeError('Existing evaluation output')
    write(target,receipt)
    print(json.dumps({'frozen_design':str(target),'sha256':sha(target),'evaluation_run':False}))


def verify_seal():
    seal=json.loads((ROOT/'FROZEN_DESIGN.json').read_text())
    for name,digest in seal['source_hashes'].items():
        if sha(ROOT/name)!=digest: raise RuntimeError(f'Frozen source changed: {name}')
    return seal


def execute():
    seal=verify_seal()
    target=ROOT/'results.json'
    if target.exists(): raise RuntimeError('Refusing to overwrite evaluation results')
    suite=unittest.defaultTestLoader.loadTestsFromName('test_conditional_acquisition')
    stream=io.StringIO()
    tested=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    write(ROOT/'test_receipt.json',{'tests':tested.testsRun,'failures':len(tested.failures),
                                  'errors':len(tested.errors),'output':stream.getvalue(),
                                  'frozen_design_sha256':sha(ROOT/'FROZEN_DESIGN.json')})
    if not tested.wasSuccessful(): raise RuntimeError('Development mechanism tests failed')
    spec=json.loads((ROOT/'experiment_spec.json').read_text())
    results=[]; models=[]
    for graph in spec['frozen_evaluation_graphs']:
        model=Model(spec['resource_count'],tuple(tuple(x) for x in graph['requires_all']))
        fixed_cost,order=best_frozen_order(model)
        generic=ConditionalPolicy(model,True)
        vault_only=ConditionalPolicy(model,False)
        bio_resources=['source-compartment','catalytic-cofactor','transport-resource']
        neutral_resources=['r2','r0','r1']
        def rows(names,biological):
            return [{'ordinal':i,'display_name':('reaction-complex-' if biological else 'neutral-job-')+str(i),
                     'requires_all':[names[r] for r in requirement],'roles':['incident','control']}
                    for i,requirement in enumerate(model.requirements)]
        adapter_model=compile_reaction_rows(rows(bio_resources,True),bio_resources)
        renamed_model=compile_reaction_rows(rows(neutral_resources,False),neutral_resources)
        if not model==adapter_model==renamed_model: raise RuntimeError('Compilation changed model')
        adapter=ConditionalPolicy(adapter_model,True)
        renamed=ConditionalPolicy(renamed_model,True)
        policies={'GENERIC_ADAPTIVE_VAULT_ONLY':vault_only,
                  'GENERIC_ADAPTIVE_WITH_PROBES':generic,
                  'REACTION_SCHEMA_ADAPTER':adapter,
                  'RELABELLED_REACTION_ADAPTER':renamed}
        graph_results=[]
        for world in model.worlds:
            for arm in spec['arms']:
                row=run_episode(model,world,arm,spec['budget'],policy=policies.get(arm),order=order)
                row['graph_id']=graph['id']
                row['pair_physically_available_in_synthetic_world']=model.any_route_available(world)
                results.append(row); graph_results.append(row)
        initial=generic.decide((),spec['budget'])
        models.append({'graph_id':graph['id'],'fixed_order':order,'fixed_expected_actions':str(fixed_cost),
                       'adaptive_initial_decision':initial,
                       'generic_dynamic_program_states':generic.solve.cache_info().currsize,
                       'vault_only_dynamic_program_states':vault_only.solve.cache_info().currsize})
        print(json.dumps({'completed_graph':graph['id'],'episodes':len(graph_results),
                          'dp_states':generic.solve.cache_info().currsize}),flush=True)
    summaries={}
    for arm in spec['arms']:
        subset=[r for r in results if r['arm']==arm]
        summaries[arm]={'scenarios':len(subset),'pair_acquisitions':sum(r['pair_acquired'] for r in subset),
                        'total_actions':sum(r['actions'] for r in subset),
                        'mean_actions':str(Fraction(sum(r['actions'] for r in subset),len(subset))),
                        'failed_vault_accesses':sum(r['failed_vault_accesses'] for r in subset),
                        'prerequisite_probes':sum(r['prerequisite_probes'] for r in subset),
                        'terminals':dict(Counter(r['terminal'] for r in subset))}
    receipt={'schema':'ConditionalAcquisitionResultsV1','completed_utc':datetime.now(timezone.utc).isoformat(),
             'frozen_design_sha256':sha(ROOT/'FROZEN_DESIGN.json'),'frozen_source_hashes':seal['source_hashes'],
             'scope':spec['scope'],'synthetic_scenarios':32,'arm_scenario_runs':len(results),
             'summaries':summaries,'models':models,'episodes':results,
             'limitations':['No actual provider execution or real archived outcome replay.',
                            'No measured biological kinetics, concentrations, crowding or spatial transport.',
                            'Declared dependencies and deterministic/noiseless observation law are assumptions.',
                            'The adapter and generic planner share the same solver; ties test semantic equivalence, not independent algorithm replication.',
                            'All availability worlds are exhaustively tested in four hand-selected small graphs; no population inference.']}
    write(target,receipt)
    print(json.dumps({'result':str(target),'summaries':summaries},indent=2))


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--freeze',action='store_true')
    parser.add_argument('--execute',action='store_true')
    args=parser.parse_args()
    if args.freeze == args.execute: parser.error('choose exactly one of --freeze/--execute')
    freeze() if args.freeze else execute()
