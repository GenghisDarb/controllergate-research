"""Independent trace/accounting verifier; does not regenerate evaluation data."""
from collections import Counter
from datetime import datetime,timezone
from fractions import Fraction
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent


def main():
    result=json.loads((ROOT/'results.json').read_text())
    spec=json.loads((ROOT/'experiment_spec.json').read_text())
    seal=json.loads((ROOT/'FROZEN_DESIGN.json').read_text())
    assert result['frozen_design_sha256']==hashlib.sha256((ROOT/'FROZEN_DESIGN.json').read_bytes()).hexdigest()
    for name,expected in seal['source_hashes'].items():
        assert hashlib.sha256((ROOT/name).read_bytes()).hexdigest()==expected
    graphs={g['id']:g['requires_all'] for g in spec['frozen_evaluation_graphs']}
    aggregate={arm:Counter() for arm in spec['arms']}
    indexed={}
    observation_count=0
    for episode in result['episodes']:
        requirements=graphs[episode['graph_id']]
        actual=episode['actual_world_for_scoring_only']
        worlds=list(range(8)); acquired=set(); attempted=set()
        for step,row in enumerate(episode['trace'],1):
            action=row['selection']['action']; observed=row['observation_after_charge']
            assert action not in attempted and 0 <= action < 11
            attempted.add(action)
            assert row['step']==step and row['history_length_at_selection']==step-1 and row['charged_cost']==1
            def physical_outcome(world):
                if action >= 8: return int(bool(world & (1<<(action-8))))
                return int(all(world & (1<<r) for r in requirements[action//2]))
            assert observed==physical_outcome(actual)
            worlds=[w for w in worlds if physical_outcome(w)==observed]
            assert actual in worlds
            if action < 8 and observed: acquired.add(action)
            observation_count += 1
        pair=any({2*r,2*r+1} <= acquired for r in range(4))
        assert episode['pair_acquired']==pair
        assert episode['actions']==len(episode['trace'])<=spec['budget']
        if episode['terminal']=='PAIR_ACQUIRED': assert pair
        if episode['terminal']=='UNREACHABLE_UNDER_DECLARED_MODEL':
            assert all(not any(all(w & (1<<r) for r in req) for req in requirements) for w in worlds)
        assert episode['patch_authority'] is False and episode['causal_ownership'] is False
        count=aggregate[episode['arm']]
        count['pair_acquisitions']+=pair; count['total_actions']+=episode['actions']
        count['failed_vault_accesses']+=episode['failed_vault_accesses']
        count['prerequisite_probes']+=episode['prerequisite_probes']
        indexed[(episode['graph_id'],actual,episode['arm'])]=episode
    assert len(indexed)==192
    label_equivalence=0
    for graph in graphs:
        for world in range(8):
            generic=indexed[(graph,world,'GENERIC_ADAPTIVE_WITH_PROBES')]
            for arm in ['REACTION_SCHEMA_ADAPTER','RELABELLED_REACTION_ADAPTER']:
                other=indexed[(graph,world,arm)]
                assert generic['trace']==other['trace'] and generic['terminal']==other['terminal']
                label_equivalence += 1
    for arm,counts in aggregate.items():
        for key,value in counts.items(): assert value==result['summaries'][arm][key]
    for model_record in result['models']:
        graph=model_record['graph_id']
        fixed=[indexed[(graph,w,'BEST_FROZEN_ORDER')] for w in range(8)]
        adaptive=[indexed[(graph,w,'GENERIC_ADAPTIVE_WITH_PROBES')] for w in range(8)]
        assert Fraction(sum(r['actions'] for r in fixed),8)==Fraction(model_record['fixed_expected_actions'])
        assert Fraction(sum(r['actions'] for r in adaptive),8)==Fraction(model_record['adaptive_initial_decision']['expected_remaining_actions'])
        assert Fraction(sum(r['pair_acquired'] for r in adaptive),8)==Fraction(model_record['adaptive_initial_decision']['expected_pair_probability'])
    receipt={'status':'PASS','completed_utc':datetime.now(timezone.utc).isoformat(),
             'episodes_verified':192,'charged_observations_verified':observation_count,
             'generic_adapter_trace_equivalences':label_equivalence,
             'budget_violations':0,'false_pair_terminals':0,'false_model_relative_unreachable_stops':0,
             'result_sha256':hashlib.sha256((ROOT/'results.json').read_bytes()).hexdigest(),
             'scope':'Independent elementary replay of recorded synthetic traces; no provider or physical validation.'}
    (ROOT/'verification.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps(receipt,indent=2))


if __name__=='__main__': main()
