import itertools
from fractions import Fraction
import unittest

from conditional_acquisition import Model, ConditionalPolicy, compile_reaction_rows, public_state, best_frozen_order, run_episode


class AcquisitionTests(unittest.TestCase):
    def test_and_prerequisites_are_joint(self):
        model=Model(2,((0,1),))
        self.assertEqual([model.available(w,0) for w in model.worlds],[False,False,False,True])

    def test_missing_observation_is_not_negative_observation(self):
        model=Model(2,((0,1),))
        self.assertEqual(public_state(model,())[0],(0,1,2,3))
        belief,_,_=public_state(model,((0,0),))
        self.assertEqual(belief,(0,1,2))
        self.assertTrue(any(w & 1 for w in belief))
        self.assertTrue(any(w & 2 for w in belief))

    def test_pair_requires_same_route(self):
        model=Model(2,((0,),(1,)))
        self.assertFalse(model.pair_acquired((1<<0)|(1<<3)))
        self.assertTrue(model.pair_acquired((1<<2)|(1<<3)))

    def test_costed_observation_beats_unaffordable_preflight(self):
        model=Model(1,((0,),))
        policy=ConditionalPolicy(model)
        initial=policy.decide((),2)
        self.assertEqual(initial['action'],0)
        self.assertEqual(initial['expected_pair_probability'],'1/2')
        self.assertEqual(initial['expected_remaining_actions'],'3/2')

    def test_unreachable_proof_is_conditional_on_history(self):
        model=Model(1,((0,),))
        policy=ConditionalPolicy(model)
        self.assertEqual(policy.decide(((0,0),),2)['reason'],'UNREACHABLE_UNDER_DECLARED_MODEL')
        self.assertNotEqual(policy.decide((),2)['reason'],'UNREACHABLE_UNDER_DECLARED_MODEL')

    def test_fixed_order_dp_matches_independent_exhaustion(self):
        model=Model(2,((0,),(1,)))
        expected,order=best_frozen_order(model)
        candidates=[]
        for permutation in itertools.permutations(range(4)):
            total=0
            for world in model.worlds:
                acquired=0
                for index,action in enumerate(permutation,1):
                    if model.outcome(world,action): acquired |= 1<<action
                    if model.pair_acquired(acquired): break
                total += index
            candidates.append((Fraction(total,4),permutation))
        self.assertEqual((expected,order),min(candidates))

    def test_relabelling_is_not_new_information(self):
        left=compile_reaction_rows([{'ordinal':0,'display_name':'catalytic assembly','requires_all':['cofactor'],'roles':['incident','control']}],['cofactor'])
        right=compile_reaction_rows([{'ordinal':0,'display_name':'job','requires_all':['r7'],'roles':['incident','control']}],['r7'])
        self.assertEqual(left,right)
        self.assertEqual(ConditionalPolicy(left).decide((),2),ConditionalPolicy(right).decide((),2))

    def test_history_is_the_only_world_information(self):
        model=Model(2,((0,),(1,)))
        policy=ConditionalPolicy(model)
        a=policy.decide((),3)
        self.assertEqual(a,policy.decide((),3))
        for world in model.worlds:
            result=run_episode(model,world,'GENERIC',3,policy=policy)
            self.assertEqual(result['trace'][0]['selection'],a)
            self.assertLessEqual(result['actions'],3)
            self.assertFalse(result['patch_authority'])

    def test_invalid_schema_and_impossible_observations_rejected(self):
        with self.assertRaises(ValueError):
            compile_reaction_rows([{'ordinal':0,'display_name':'a','requires_all':['absent'],'roles':['incident','control']}],['known'])
        model=Model(1,((0,),))
        with self.assertRaises(ValueError): public_state(model,((0,0),(1,1)))
        with self.assertRaises(ValueError): public_state(model,((0,0),(0,0)))
        with self.assertRaises(ValueError): public_state(model,((0,True),))


if __name__=='__main__':
    unittest.main()
