"""Independent bounded review; reads history repair, writes only bridge/.

Runs pure/helper fixtures, never provider subprocesses or a campaign main().
"""
from copy import deepcopy
from datetime import datetime,timezone
import hashlib
import importlib
import io
import json
from pathlib import Path
import sys
import unittest

ROOT=Path(__file__).resolve().parent
REPAIR=ROOT.parent/'history/repair_candidate'
sys.dont_write_bytecode=True
sys.path.insert(0,str(REPAIR))


def hashes():
    files=['registry_bound_semantics.py','fresh_semantic_seam.py','predicate_registry_v4.jsonl',
           'test_repair.py','test_integration_seam.py',
           'integration_candidate/scripts/run_batch102_candidate_slice.py',
           'integration_candidate/scripts/seal_batch103_candidate_outcomes.py',
           'integration_candidate/controllergate/evidence/registry_bound_semantics_candidate.py',
           'integration_candidate/controllergate/evidence/registry_bound_semantic_seam_candidate.py']
    return {name:hashlib.sha256((REPAIR/name).read_bytes()).hexdigest() for name in files}


def main():
    before=hashes()
    core=importlib.import_module('registry_bound_semantics')
    test=importlib.import_module('test_repair')
    integration=importlib.import_module('test_integration_seam')
    seam=importlib.import_module('fresh_semantic_seam')
    stream=io.StringIO()
    suite=unittest.TestSuite([unittest.defaultTestLoader.loadTestsFromModule(module)
                              for module in (test,integration)])
    tested=unittest.TextTestRunner(stream=stream,verbosity=2).run(suite)
    assert tested.wasSuccessful(),stream.getvalue()

    changed=deepcopy(test.outcome()); changed['satisfied']=1
    type_check=test.verified(changed)
    assert type_check['status']=='REJECTED'
    changed['record_hash']=core.canonical_hash({k:v for k,v in changed.items() if k!='record_hash'})
    resigned_check=test.verified(changed)
    assert resigned_check['status']=='REJECTED'
    minimal={'status':'EVALUATED','raw_observation_hash':'x'}
    minimal_check=test.replay(minimal,minimal)
    assert minimal_check['status']=='UNRESOLVED'

    unknown,cell=integration.wrapped({'structured_observation_missing':True,'return_code':1},
        candidate='audioread_144_py313_aifc_removed',program='batch100-audioread-144-aifc',
        role='control',legacy=True)
    status_helper=integration.inserted_helper('scripts/run_batch102_candidate_slice.py','current_cell_status',
        {'cell_status_after_verification':seam.cell_status_after_verification})
    checks=[{'id':unknown['execution_receipt_id'],'blockers':integration.sealed(unknown,cell)}]
    wrapper_status=status_helper([unknown],checks)
    assert wrapper_status=='EXECUTED_SEMANTICS_UNRESOLVED'
    assert status_helper([unknown],[])=='EXECUTED_RECEIPT_UNVERIFIED'

    ops=set()
    def collect(value):
        if isinstance(value,dict):
            if len(value)==1 and next(iter(value)) in {'all','any','not','exists','missing','implies','count','derived_relation','eq','ne','gt','ge','lt','le','contains','in','regex'}:
                ops.add(next(iter(value)))
            for item in value.values(): collect(item)
        elif isinstance(value,list):
            for item in value: collect(item)
    for line in (REPAIR/'predicate_registry_v4.jsonl').read_text().splitlines():
        if line.strip(): collect(json.loads(line))
    assert ops=={'all','eq','ge','gt','ne'}
    after=hashes(); assert before==after,'Code changed during review'
    receipt={'status':'PASS_WITH_STATED_SCOPE','completed_utc':datetime.now(timezone.utc).isoformat(),
             'source_hashes':before,'source_unchanged_during_review':True,
             'focused_methods_run':tested.testsRun,'failures':len(tested.failures),'errors':len(tested.errors),
             'original_defect_controls':{'bool_to_int_original_hash':type_check,
                  'bool_to_int_resigned':resigned_check,'minimal_forged_replay':minimal_check},
             'wrapper_missingness_status':wrapper_status,
             'current_v4_operators':sorted(ops),'operator_coverage':'All operators used by the current frozen v4 registry are supported; this is not full support for every operator in the historical general evaluator.',
             'review_findings':[
                 'The selected candidate/program/role predicate is actually evaluated and bound to the pinned registry bytes, raw structured observation and declared context.',
                 'The independent receipt verifier recomputes the outcome and projection and rejects type-changing or re-signed receipt mutations.',
                 'The public replay comparison verifies both sides against independent inputs before declaring same scoped outcome.',
                 'Missing required observations remain UNRESOLVED at both inserted wrapper accounting and seal; observed negative predicates remain distinct.',
                 'The isolated patch calls binding and verification helpers from the inspected main functions, not only from detached tests.',
                 'Source-shaped Poetry/Audioread schema mismatches remain unresolved instead of receiving invented aliases.'
             ],
             'limits':[
                 'Pure/helper fixture execution only: no entire provider workflow, full repository integration suite or external incident rerun.',
                 'Registry digest and supplied observation/context are external premises; this component alone does not authenticate raw execution or its anchor.',
                 'Same declared outcome means operand/context equality under this projection, not complete scientific equivalence.',
                 'Semantic agreement alone does not prove two independent fresh executions; broker/custody and distinct-execution obligations remain outside this semantic comparison.',
                 'No causal ownership, repair authority, biological claim or measured Reactome planning gain follows.'
             ],
             'test_output':stream.getvalue(),
             'review_script_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
    (ROOT/'repair_review_final.json').write_text(json.dumps(receipt,indent=2,sort_keys=True)+'\n')
    print(json.dumps({k:receipt[k] for k in ['status','focused_methods_run','failures','errors','wrapper_missingness_status','current_v4_operators']},indent=2))


if __name__=='__main__': main()
