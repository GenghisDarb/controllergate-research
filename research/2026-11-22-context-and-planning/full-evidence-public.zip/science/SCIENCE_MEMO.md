# Betzig clip, live-cell dynamics, and Reactome: primary-source audit

Prepared 2026-11-23 UTC. Research lane: `/root/paper_audit`. This is a source audit and proposed benchmark, not a new biological experiment or raw-data reanalysis. The parent agent handles the original clip transcript and quantitative demonstrations.

## Finding

The defensible criticism is that a reaction diagram does not uniquely specify a living cell's dynamics. Concentrations, binding lifetimes, transport, geometry, environmental conditions, and the microscope's observation process can change the measured behavior. The evidence does not establish that almost all cell biology is false, that perturbation experiments are generally unusable, or that Reactome's individual curated reactions are collectively invalid.

Reactome already distinguishes compartments, molecular modifications, complexes, transport, catalysis, and regulation. Its current organ FAQ describes a generic human-cell annotation with expression overlays. Compartment labels are useful context; they are not complete geometry, tissue-specific rates, or an independently validated whole-cell simulator. The scientific opportunity is a calibrated executable model plus an explicit observation model, retaining the curated evidence rather than discarding it.

## Primary evidence and limits

### B1. Original interview is an opinion source, not a new experimental result

Original episode: *Diffraction Limit, Microscopy, and Cell Biology | Eric Betzig on Super-Resolution Microscopy*, 632nm, 2026-09-08. URL: https://www.youtube.com/watch?v=RUB37QhWNkw . The publisher episode is https://share.transistor.fm/s/46173a34 . Web reference: `turn435049311youtube9`.

The longer indexed transcript contains an admission that the speaker is exaggerating. Third-party transcripts were discovery aids; the parent checks the original clip. The large numbers refer to molecules, not measured reaction events. Without a cell size and type, such counts are illustrative rather than universal. Neither the authority of the speaker nor clinical attrition identifies which particular curated molecular claim is false.

### B2. Chen et al. (2014): timing can change with little change in a bound fraction

*Single-molecule Dynamics of Enhanceosome Assembly in Embryonic Stem Cells*. Cell 156, 1274–1285. DOI: https://doi.org/10.1016/j.cell.2014.01.062 . Full text: https://pmc.ncbi.nlm.nih.gov/articles/PMC4040518/ . References: `turn390433793view1`, `turn944828018view7`, `turn944828018view8`.

This Betzig/Tjian collaboration used live cultured mouse embryonic stem cells, mutants, induction, knockdown, and complementary assays. In the Figure 5 Oct4-induction comparison, Sox2's specific residence time increased from 11.6 to 14.1 seconds while its long-lived bound fraction changed little. This is a real experimental illustration of kinetic information beyond an occupancy summary, not exact proof of equal occupancy. The work supports ordered Sox2-assisted Oct4 assembly and includes imaging controls. Here “in vivo” includes living cultured cells; it does not automatically mean an intact animal. A supplement table is available as XLSX; it was not successfully downloaded in this lane. GEO GSE54103 is ChIP-exo data, not a substitute for the raw single-molecule trajectories.

### B3. Hammar et al. (2014): a simple occupancy model both succeeds and fails

*Direct measurement of transcription factor dissociation excludes a simple operator occupancy model for gene regulation*. Nature Genetics 46, 405–408. DOI: https://doi.org/10.1038/ng.2905 . Full text: https://pmc.ncbi.nlm.nih.gov/articles/PMC6193529/ . References: `turn390433793view0`, `turn628624005search3`.

Published Table 1 compares LacI kinetics with repression in growing E. coli. For lacO1, the simple occupancy prediction is 11.2 ± 0.5 versus measured repression 10.0 ± 1.3; for lacOsym it is 21.2 ± 0.9 versus 29.7 ± 3.4. These are SEM, not standard deviations. The model is consistent with one operator and misses the other. The paper considers both operator-specific equilibrium cooperativity and nonequilibrium transcription mechanisms: the discrepancy alone does not uniquely identify nonequilibrium causation. Its notation uses tau_off for mean bound time and tau_on for mean free time. The parent reproduces table arithmetic only; rounded table inputs need not yield the exact rounded model predictions.

### B4. Liu et al. (2018): native context reveals differences and confirms some cultured-cell findings

*Observing the cell in its native state: Imaging subcellular dynamics in multicellular organisms*. Science 360, eaaq1392. DOI: https://doi.org/10.1126/science.aaq1392 . Full text: https://pmc.ncbi.nlm.nih.gov/articles/PMC6040645/ . References: `turn390433793view2`, `turn628624005search4`.

Adaptive-optics lattice light-sheet microscopy corrects aberrations while limiting illumination burden in multicellular settings. Zebrafish brain and muscle clathrin pits had similar initiation frequency and fluorescence intensity but different internalization speed. Importantly, the estimated membrane uptake was comparable to cultured-cell measurements, and ER and mitochondrial forms largely recapitulated cultured-cell observations. The uptake estimate of about 0.1% membrane per minute depends on assumptions about productive pit lifetimes and vesicle diameter. This paper is evidence for selective contextual validation and correction, not the wholesale failure of culture experiments. Optical corrections also change detectability, so an imaging improvement cannot be treated as a biology-only intervention.

### B5. Delarue et al. (2018): crowding has a concrete, size-dependent mechanism

*mTORC1 Controls Phase Separation and the Biophysical Properties of the Cytoplasm by Tuning Crowding*. Cell 174, 338–349.e20. DOI: https://doi.org/10.1016/j.cell.2018.05.042 . Primary abstract: https://pubmed.ncbi.nlm.nih.gov/29937223/ . Full-text location: https://pmc.ncbi.nlm.nih.gov/articles/PMC10080728/ . References: `turn312407652search5`, `turn954487602search6`.

Genetically encoded multimeric nanoparticles and interventions connect mTORC1, ribosome concentration, and mesoscale mobility. The reported effective diffusion changes exceed twofold for particles at least 20 nm across, while effects were not discernible for molecules at most 5 nm across. Thus crowding is not a universal slowdown applied identically to every molecular species. A context-dependent diffusion model can make falsifiable size-dependent predictions. Primary abstract/indexed material was inspected; the full-text endpoint later presented a challenge, and no raw experiment was rerun.

### B6. Hansen et al. (2018): explicit observation modeling already has an open benchmark

*Robust model-based analysis of single-particle tracking experiments with Spot-On*. eLife 7:e33125. DOI: https://doi.org/10.7554/eLife.33125 . Full text: https://pmc.ncbi.nlm.nih.gov/articles/PMC5809147/ . References: `turn213621274search1`, `turn721396666view1`.

Motion blur, trajectory assignment, and loss of fast particles from the focal plane bias single-particle estimates. Stroboscopic acquisition and Spot-On explicitly address these effects. The public release contains 1,064 experimental single-cell datasets from four cell lines and 15 acquisition settings, alongside separate simulations. The fitted quantities include diffusion coefficients and population fractions. Do not treat this as direct recovery of every binding/unbinding lifetime or a fully general anomalous-diffusion model. Cells and independent experiment days, not individual tracks, define the relevant replication hierarchy. Data inspection reached archive names, member names, sizes, and documented schema; no trajectory bytes or biological estimates were analyzed in this lane.

### B7. Wong, Siah and Lo (2019): the drug percentage needs its denominator

*Estimation of clinical trial success rates and related parameters*. Biostatistics 20, 273–286. DOI: https://doi.org/10.1093/biostatistics/kxx069 . Primary paper: https://academic.oup.com/biostatistics/article/20/2/273/4817524 . Author institution: https://dspace.mit.edu/entities/publication/b06de70c-6696-497a-a3ae-9fe1f43717dd . References: `turn213621274search7`, `turn628624005search0`.

The study examined 406,038 trial entries covering more than 21,143 compounds in 2000–2015. Its main industry phase-I-to-approval estimate was 13.8%; another estimator in the same paper gave 6.9%. It compared prior estimates including 9.6%. The endpoint, indication, dataset and estimator matter; exiting phase III is not exactly the same event as approval. A rough 9% remark may resemble an existing estimate but cannot be treated as a universal rate or evidence that one particular mechanistic defect causes all attrition.

### B8. Reactome's stated scope

*The Reactome Knowledgebase 2026*. Nucleic Acids Research 54, D673–D681. DOI: https://doi.org/10.1093/nar/gkaf1223 . Primary paper: https://academic.oup.com/nar/article/54/D1/D673/8326464 . PubMed: https://pubmed.ncbi.nlm.nih.gov/41251150/ . References: `turn954487602search0`, `turn954487602search4`.

Reactome is an evidence-curated reaction/pathway resource with disease and drug annotations. Current official documentation explicitly models state-specific entities and compartments. Its organ FAQ states generic human-cell coverage with expression overlays. Those facilities are useful but do not uniquely identify tissue-specific rates, concentrations, or three-dimensional dynamics. The 2026 paper describes release 94 from September 2025; those counts should not be labeled current November 2026 counts. A 2011 Reactome methods paper explicitly discussed absent kinetics/affinities, but that historical statement should not alone establish every detail of current exports. Likewise, valid SBML can omit kinetic laws; export format by itself does not establish executable biological prediction.

Current documentation: https://reactome.org/documentation/data-model (`turn379883822view0`); https://reactome.org/documentation/faq/37-general-website/203-pathways-per-organ (`turn379883822view1`). Historical methods: https://doi.org/10.1002/pmic.201100066 ; https://pmc.ncbi.nlm.nih.gov/articles/PMC4617659/ . SBML standard context: https://pmc.ncbi.nlm.nih.gov/articles/PMC5451324/ . ReactomeGSA's quantitative omics/gene-set analysis should not be confused with kinetic simulation.

## A concrete TORUS/TLD bridge, with novelty limits

A useful separation is curated reaction structure, dynamical law, observation process, and held-out validation. A conventional starting model is

\[
\dot x = S\,v(x;\theta,c),\qquad
Y_k = \mathcal M_{\psi,c}[X_{[t_k-\Delta,t_k]}] + \epsilon_k.
\]

Here S records reaction structure, theta rates and transport parameters, c cellular context, and psi exposure/point-spread/localization/tracking properties. A stochastic reaction model may be preferable to the deterministic equation. Reactome helps with structure and evidence; it does not determine all the remaining quantities.

For ordinary two-state binding with rates a and b, occupancy is a/(a+b), mean bound dwell is 1/b, and the stationary correlation time is 1/(a+b). Multiplying both rates by a positive factor preserves occupancy and the graph while changing dwell and correlation times. This is a standard identifiability fact, not a newly discovered TORUS mechanism. The parent supplies a labeled synthetic demonstration.

The strongest near-term experimental-data benchmark is the existing Spot-On acquisition series. Use held-out experiment days and cells to test whether an explicitly specified additional TORUS/TLD constraint improves predictive calibration beyond the established observation-aware model. Compare a naive trajectory summary, the original Spot-On method, and the proposed extension; preserve measurement metadata and preregister errors before choosing the best feature. Acquisition settings test observation bias, not a new biological intervention. Binding lifetimes would require a separate appropriately timed observation design and photobleaching corrections. Chen's induction/mutant comparisons and Hammar's successful and failed occupancy cases offer biological targets for a later kinetic benchmark.

No paper here establishes a fourteen-layer closure, a unique N14 count, a new physical time mechanism, or superiority of TORUS. The potentially publishable contribution is a new, demonstrably useful model constraint or benchmark with transparent held-out performance. Context dependence, reaction-diffusion modeling, and single-particle observation correction themselves are established fields.

## Data access and reproducibility boundary

The official experimental dataset is https://zenodo.org/records/834781 (version 1, published 2017-07-25). Its README defines CSV columns `frame`, `t`, `trajectory`, `x`, `y`, with spatial coordinates in micrometers; the stated timestamp column must be checked against the acquisition interval on actual ingestion. Each CSV is a single cell, with replicate/day and acquisition settings in its filename. The smallest containing ZIP is `CSV_mESC_Sox2_ExpA_PAJF549.zip`, listed as 40.2 MB with provider MD5 `426096681c867f38b970655d8ad34695`.

The public preview https://zenodo.org/records/834781/preview/CSV_mESC_Sox2_ExpA_PAJF549.zip?include_deleted=0 lists a 221.5 kB member, `mESC_C3_Halo-Sox2_PA-JF549_1ms-561nm_100Hz_rep2_cell03.csv`. The retrieved preview lists names and sizes but supplies no individual downloadable member link. A single direct, unauthenticated download attempt from the observed ZIP link returned HTTP 403 Forbidden after 10.0462 seconds, with the body “Forbidden. Calls to this URL are not allowed.” This is an access limit of the present route, not evidence that the public dataset is unavailable to others. The web tool separately reported a 40,222,696-byte content-length limit. The provider hash was recorded rather than independently verified. No CSV was inspected. This is a concrete follow-up target, not a claimed raw-data validation. Web references: `turn675127999view0`, `turn814871093view0`, `turn220389761view0`. The exact access receipt and precommitted first-lexicographic-cell inspection plan are saved beside this memo.

Code: https://gitlab.com/tjian-darzacq-lab/Spot-On-cli ; https://gitlab.com/tjian-darzacq-lab/spot-on-matlab . Author data index: https://www.ashansenlab.com/data.html . Simulation records: https://zenodo.org/records/834787 and https://zenodo.org/records/835541 . No code from these repositories was executed in this lane.
