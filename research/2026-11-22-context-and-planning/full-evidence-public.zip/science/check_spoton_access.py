"""One bounded unauthenticated public download and a fixed schema-only inspection.

No Spot-On inference or biological-effect estimation is performed.
"""
from pathlib import Path
from datetime import datetime, timezone
import collections
import csv
import hashlib
import io
import json
import math
import statistics
import time
import urllib.error
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
URL = 'https://zenodo.org/records/834781/files/CSV_mESC_Sox2_ExpA_PAJF549.zip?download=1'
EXPECTED_MD5 = '426096681c867f38b970655d8ad34695'
TARGET = ROOT / 'CSV_mESC_Sox2_ExpA_PAJF549.zip'
PART = TARGET.with_suffix('.zip.part')


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    plan = {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'scope': 'One public download attempt; fixed schema and data-quality inspection only.',
        'selection_rule': 'Lexicographically first .csv archive member, fixed before any trajectory bytes are inspected.',
        'no_inference': 'No Spot-On fit, dwell-time estimate, physiological claim, or choice of cell by its results.',
        'checks': ['provider MD5 and local SHA256', 'exact headers', 'finite numeric rows', 'frame and trajectory integer values',
                   'within-track ordering and duplicate frames', 'timestamp-step consistency with file-named 100 Hz',
                   'coordinate ranges and track-length histogram'],
        'access_limit_seconds': 30,
        'max_bytes': 55000000,
        'url': URL,
        'provider_md5': EXPECTED_MD5,
    }
    save('spoton_inspection_plan.json', plan)
    started = time.monotonic()
    receipt = {'attempt_started_utc': plan['created_utc'], 'url': URL, 'status': 'attempting', 'credentials_used': False,
               'selection_rule': plan['selection_rule']}
    try:
        request = urllib.request.Request(URL, headers={'User-Agent': 'research-file-check/1.0'})
        with urllib.request.urlopen(request, timeout=28) as response:
            receipt['http_status'] = response.status
            receipt['content_type'] = response.headers.get('Content-Type')
            receipt['declared_content_length'] = response.headers.get('Content-Length')
            size = 0
            with PART.open('wb') as out:
                while True:
                    if time.monotonic() - started > 30:
                        raise TimeoutError('30-second total download budget reached')
                    block = response.read(1024 * 1024)
                    if not block:
                        break
                    size += len(block)
                    if size > plan['max_bytes']:
                        raise ValueError('Download exceeds declared inspection byte limit')
                    out.write(block)
        raw = PART.read_bytes()
        receipt.update(download_bytes=len(raw), md5=hashlib.md5(raw).hexdigest(), sha256=hashlib.sha256(raw).hexdigest())
        if receipt['md5'] != EXPECTED_MD5:
            raise ValueError('Downloaded bytes do not match provider MD5; no CSV inspected')
        PART.replace(TARGET)
        receipt['status'] = 'downloaded_provider_md5_verified'
        with zipfile.ZipFile(TARGET) as archive:
            members = sorted(n for n in archive.namelist() if n.lower().endswith('.csv') and not n.startswith('__MACOSX/'))
            member = members[0]
            raw_csv = archive.read(member)
        safe_name = Path(member).name
        (ROOT / safe_name).write_bytes(raw_csv)
        rows = list(csv.DictReader(io.StringIO(raw_csv.decode('utf-8-sig'))))
        headers = list(rows[0]) if rows else []
        expected = ['frame', 't', 'trajectory', 'x', 'y']
        quality = {'member': member, 'bytes': len(raw_csv), 'sha256': hashlib.sha256(raw_csv).hexdigest(),
                   'archive_csv_count': len(members), 'row_count': len(rows), 'headers': headers,
                   'expected_documented_columns': expected, 'has_all_expected_columns': set(expected) <= set(headers),
                   'scope': 'One preselected cell; schema and quality only; not biological validation.'}
        if quality['has_all_expected_columns']:
            tracks = collections.defaultdict(list)
            invalid = []
            for index, row in enumerate(rows):
                try:
                    converted = {key: float(row[key]) for key in expected}
                    if not all(math.isfinite(v) for v in converted.values()):
                        raise ValueError('nonfinite')
                    tracks[converted['trajectory']].append(converted)
                except (ValueError, TypeError) as err:
                    invalid.append({'row': index + 2, 'error': str(err)})
            numeric = [r for track in tracks.values() for r in track]
            steps = [(right['frame'] - left['frame'], right['t'] - left['t'])
                     for track in tracks.values() for left, right in zip(track, track[1:])]
            dt_per_frame = [dt / df for df, dt in steps if df > 0]
            quality.update(invalid_row_count=len(invalid), invalid_row_examples=invalid[:10], track_count=len(tracks),
                           frame_values_integral=all(r['frame'].is_integer() for r in numeric),
                           trajectory_values_integral=all(r['trajectory'].is_integer() for r in numeric),
                           within_track_nonpositive_frame_steps=sum(df <= 0 for df, _ in steps),
                           within_track_nonpositive_time_steps=sum(dt <= 0 for _, dt in steps),
                           track_length_histogram=dict(sorted(collections.Counter(map(len, tracks.values())).items())),
                           coordinate_ranges_micrometers={k: [min(r[k] for r in numeric), max(r[k] for r in numeric)] for k in ['x', 'y']},
                           frame_range=[min(r['frame'] for r in numeric), max(r['frame'] for r in numeric)],
                           timestamp_range=[min(r['t'] for r in numeric), max(r['t'] for r in numeric)],
                           median_timestamp_step_per_frame=statistics.median(dt_per_frame) if dt_per_frame else None,
                           max_abs_timestamp_step_deviation_from_0p01_seconds=max((abs(dt - 0.01) for dt in dt_per_frame), default=None))
        save('spoton_one_cell_quality.json', quality)
        receipt['member_inspected'] = member
        receipt['quality_file'] = 'spoton_one_cell_quality.json'
    except urllib.error.HTTPError as err:
        receipt.update(status='blocked_http', http_status=err.code, error=str(err))
        body = err.read(2000).decode('utf-8', errors='replace')
        receipt['error_body_excerpt'] = body
    except Exception as err:
        receipt.update(status='not_completed', error_type=type(err).__name__, error=str(err))
    finally:
        receipt['elapsed_seconds'] = round(time.monotonic() - started, 4)
        if PART.exists():
            receipt['partial_bytes_deleted'] = PART.stat().st_size
            PART.unlink()
        save('spoton_download_receipt.json', receipt)
    print(json.dumps({k: v for k, v in receipt.items() if k != 'error_body_excerpt'}, indent=2))


if __name__ == '__main__':
    main()
