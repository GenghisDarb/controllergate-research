"""Build the complete source-audit report from frozen local result receipts."""
from __future__ import annotations

import json
from pathlib import Path
from xml.sax.saxutils import escape

from reportlab.lib import colors
from reportlab.lib.enums import TA_LEFT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image, PageBreak, KeepTogether

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "deliverables"
OUT.mkdir(exist_ok=True)
F = json.loads((ROOT / "report/summary_facts.json").read_text())
FONT = Path("/usr/share/fonts/truetype/dejavu")
for name, filename in [("DejaVu", "DejaVuSans.ttf"), ("DejaVu-Bold", "DejaVuSans-Bold.ttf"), ("DejaVu-Oblique", "DejaVuSans-Oblique.ttf")]:
    pdfmetrics.registerFont(TTFont(name, str(FONT / filename)))
pdfmetrics.registerFontFamily("DejaVu", normal="DejaVu", bold="DejaVu-Bold", italic="DejaVu-Oblique")
INK = colors.HexColor("#172a3c")
TEAL = colors.HexColor("#12656b")
MUTED = colors.HexColor("#53616d")
PALE = colors.HexColor("#edf3f6")
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(name="ReportTitle", fontName="DejaVu-Bold", fontSize=25, leading=31, textColor=INK, spaceAfter=16))
styles.add(ParagraphStyle(name="ReportSub", fontName="DejaVu", fontSize=12, leading=18, textColor=MUTED, spaceAfter=14))
styles.add(ParagraphStyle(name="H", fontName="DejaVu-Bold", fontSize=16, leading=21, textColor=TEAL, spaceBefore=8, spaceAfter=11, keepWithNext=True))
styles.add(ParagraphStyle(name="Hsmall", fontName="DejaVu-Bold", fontSize=11, leading=15, textColor=INK, spaceBefore=10, spaceAfter=6, keepWithNext=True))
styles.add(ParagraphStyle(name="B", fontName="DejaVu", fontSize=9.5, leading=14.2, textColor=INK, spaceAfter=9))
styles.add(ParagraphStyle(name="Small", fontName="DejaVu", fontSize=8, leading=11.2, textColor=MUTED, spaceAfter=7))
styles.add(ParagraphStyle(name="Cell", fontName="DejaVu", fontSize=8.3, leading=11.6, textColor=INK))
styles.add(ParagraphStyle(name="CellHead", fontName="DejaVu-Bold", fontSize=8.3, leading=11.6, textColor=colors.white))
styles.add(ParagraphStyle(name="Eq", fontName="DejaVu", fontSize=10, leading=16, textColor=TEAL, leftIndent=12, spaceBefore=5, spaceAfter=10))
story = []
plain = []


def p(text, style="B"):
    story.append(Paragraph(text, styles[style]))
    plain.append(text)


def h(text):
    p(text, "H")


def sub(text):
    p(text, "Hsmall")


def page():
    story.append(PageBreak())
    plain.append("\n\n")


def tab(headers, rows, widths):
    data = [[Paragraph(escape(str(c)), styles["CellHead"]) for c in headers]]
    data += [[Paragraph(escape(str(c)), styles["Cell"]) for c in row] for row in rows]
    table = Table(data, colWidths=widths, hAlign="LEFT", repeatRows=1)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), INK), ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, PALE]),
        ("LEFTPADDING", (0, 0), (-1, -1), 7), ("RIGHTPADDING", (0, 0), (-1, -1), 7),
        ("TOPPADDING", (0, 0), (-1, -1), 7), ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("LINEBELOW", (0, 0), (-1, 0), 0.6, TEAL),
    ]))
    story.append(table)
    story.append(Spacer(1, 10))
    plain.append(" | ".join(headers))
    plain.extend(" | ".join(map(str, row)) for row in rows)


def link(label, url):
    return '<link href="' + escape(url, {'"': '&quot;'}) + '" color="#12656b">' + escape(label) + '</link>'


p("Reactome, live-cell dynamics,<br/>and ControllerGate", "ReportTitle")
p("Source audit, local semantic repair, and controlled planning experiments", "ReportSub")
p("Prepared for Brad by Halcyon • 22 November 2026, Las Vegas<br/>Evidence cutoff and exact run times are retained in the accompanying receipts.", "Small")
h("What this investigation establishes")
p("The video points toward a real modeling limitation: a reaction map does not determine timing, context, or the measurement process. The most concrete progress here is closer to the software: the inspected fresh-execution path attached a newer predicate-registry hash while forwarding an older verdict. The planner test also constrained the next action to a fixed order. Those are specific, testable implementation and evaluation issues.")
p("This report preserves later ControllerGate improvements, including source-grounded mappings, typed uncertainty, interlocks, and genuine resource/compartment rehearsals. It does not reinterpret the entire project as a diagram-only prototype. The criticism of the Batch103 structural shadow loop is limited to that particular path.")
tab(["Result", "What is established"], [
    ("Current-source audit", "Fresh-result semantic binding and fixed-order test limitations were traced through the current accessible branch and the official-run source."),
    ("Local repair", F["repair_summary"]),
    ("Planning experiment", "192 frozen synthetic runs; equal obtainable-pair coverage across competent arms; meaningful cost differences and no benefit from biological relabeling."),
    ("Follow-up stopping ablation", F["stopping_summary"]),
    ("Biological evidence", "Primary research supports context- and observation-aware modeling. No new raw biological trajectory was analyzed here."),
    ("TORUS/TLD", "A better testable research route; no new empirical selection of fourteen layers or proof of the broader physical theory."),
], [125, 370])
p("Publication status: a useful technical audit and repair package exists now. A major biological or TORUS discovery is not established by these results. A substantial methods paper would require a new, specified contribution that beats a competent baseline on independent data.", "B")

page()
h("1. Evidence scope and development continuity")
p("I reviewed the relevant sections of the newest accessible Brad Systems Guide, modified 23 November 2026 at 06:10:43 UTC. I inspected the uploaded recording through frames and burned-in captions and checked the publisher's original episode. This is not a claim of a complete audio transcription. The video identity is recorded in video_receipt.json.")
p("The accessible repository is GenghisDarb/controllergate-research, branch controllergate-v1.7-alpha-real-trace-pilot, at commit <b>38897b79588f3ff4b1b9002eedc299a9bcf05140</b>. The key semantic-path files were also compared with official execution commit <b>3aa1a749be0a1e13bd735623c812335af9795f76</b>; the inspected files were identical. The remote inventory and exact file identities are in history/. This does not establish the current Windows PC working-tree or live Command Center state.")
tab(["Development stage", "Credit retained", "Remaining boundary"], [
    ("Earlier mechanisms", "Typed states, conjunctive interlocks, compartment checks, resource underflow, irreversible transitions and one-use behavior exist.", "Software rehearsals are not measured biological dynamics or a general causal-gain result."),
    ("Batch101", "Declarative predicate and replay work addresses earlier semantic concerns.", "A correct evaluator existing in the repository does not prove a later call path invokes it."),
    ("Batch102", "Fresh-execution and source/provider custody were strengthened.", "Custody does not establish that the declared predicate actually produced the outcome."),
    ("Batch103", "Reaction-specific source mapping and nonauthorizing planner arms were added.", "The inspected fresh wrapper forwards the older predicate result; the planner enforces fixed next-action order."),
], [83, 206, 206])
p("The repository reports official Batch103 evidence of 15 executed cells out of 70 registered, 55 unmaterialized, and no demonstrated causal gain or ordinary patches. Its handoff separately retains six issue-derived and four native external repairs from earlier work. These are inspected historical reports, not fresh reruns [C6]. The Actions endpoint returned zero available artifacts for the inspected run, so original raw outcomes could not be reclassified. A verified source defect warrants reopening the affected inference; it does not prove that every past negative result was wrong.")
sub("What was inspected, not rerun")
p("The earlier resource/compartment runtime and broad historical campaigns were inspected. Only the supplied local pure-function controls, semantic candidate fixtures, finite planning experiment, follow-up ablation, and exact numerical checks were executed in this pass. No external provider, repository push, public release, or Command Center task was created.")

page()
h("2. What the video supports")
p("The speaker is Eric Betzig, and the publisher's full interview is dated 8 September 2026 [B1]. The clip criticizes empty-space animations and static pictures of living systems. Treat the broad textbook rhetoric as a challenge to test models, rather than a measured finding that all cell biology is false.")
tab(["Clip theme", "Useful interpretation", "Inference not established"], [
    ("Crowded cellular interiors", "Geometry, mobility and local availability can matter for a prediction.", "Every curated interaction is wrong or every reaction is slowed equally."),
    ("Watch living dynamics", "Order and dwell time can distinguish models with similar static summaries.", "A static model is always useless in every condition."),
    ("Clinical attrition", "Mechanistic understanding and model transfer are difficult.", "A rough success percentage identifies Reactome as the cause of ControllerGate's outcomes."),
    ("Large-scale imaging and AI", "Scalable segmentation, tracking and observation models are concrete problems.", "Extra imaging coordinates or numerical coincidences verify TORUS's layer count."),
], [104, 195, 196])
p("The roughly nine-percent drug-development remark needs a defined endpoint, dataset and estimator. Wong, Siah and Lo's primary analysis illustrates how estimates vary with those choices [B7]. It does not supply a causal explanation for this software project's results.")
sub("Reactome is richer than a bare wiring diagram")
p("Reactome explicitly represents molecular state, modifications, complexes, compartments, transport, catalysts and regulation. It also marks some inference between model organisms and humans [B8]. A complex's required components and a set of interchangeable alternatives are different semantics. Those existing distinctions should survive translation into software.")
p("Its organ FAQ describes generic human-cell annotation with expression overlays. That useful resource does not uniquely specify every tissue's concentrations, kinetic rates or three-dimensional environment. The repair direction is to instantiate the missing quantities and test predictions. Replacing the curated resource with an unsupported universal model would not solve the gap.")

page()
h("3. Primary research that makes the bridge concrete")
tab(["Study", "Finding relevant here", "How to use it honestly"], [
    ("Chen et al., Cell 2014 [B2]", "Live-cell measurements distinguish ordered transcription-factor assembly and residence times; one induction comparison changes dwell with little change in bound fraction.", "Test dynamics beyond occupancy. Do not treat culture measurements as whole-animal observations or connect seconds near 14 to fourteen layers."),
    ("Hammar et al., Nature Genetics 2014 [B3]", "A simple occupancy prediction matches one operator better than a stronger alternative.", "Preserve both successful and failed conditions; equilibrium cooperativity remains an alternative to nonequilibrium explanation."),
    ("Liu et al., Science 2018 [B4]", "Native-context imaging shows tissue-dependent dynamics and also agreement with several cultured-cell observations.", "Use selective contextual correction; improved optics changes detectability as well as access to biology."),
    ("Delarue et al., Cell 2018 [B5]", "Perturbing mTORC1/ribosome crowding affects mesoscale mobility differently from much smaller probes.", "A falsifiable size-dependent mechanism is stronger than the vague statement that everything is crowded."),
    ("Hansen et al., eLife 2018 [B6]", "Spot-On explicitly addresses tracking and defocalization biases and supplies open experimental and simulation data.", "Use a competent observation-aware reference and independent cells/days. A track is not an independent organism."),
], [120, 190, 185])
sub("Published-summary arithmetic check")
p("Hammar's occupancy expression is RR = (τ_on + τ_off) / τ_on, where τ_off is bound time and τ_on is free time. Converting minutes to seconds gives 318 s and 558 s for the two bound times. Using the rounded means gives 11.2913 and 21.2174. These agree approximately with the published model values; underlying precision can explain the small rounding difference [B3].")
tab(["Operator", "Published prediction ± SEM", "Reporter result ± SEM"], [("lacO1", "11.2 ± 0.5", "10.0 ± 1.3"), ("lacOsym", "21.2 ± 0.9", "29.7 ± 3.4")], [110, 195, 190])
p("This is an arithmetic check of published summaries, not a new raw-data reanalysis, fitted model, or significance test. The primary-source memo records precise conditions, alternative explanations and access limits.", "Small")

page()
h("4. The concrete semantic repair")
sub("Root cause")
p("In the inspected Batch103 route, the Batch102 slice calls the Batch100 candidate runner. It copies that runner's predicate_satisfied Boolean while attaching the hash of the newer v4 registry. The relevant fresh-receipt verifier checks provenance and integrity fields but does not independently execute that v4 predicate on raw observations. The later outcome seal consumes these fields. The registry's identity and the verdict's actual computation can therefore disagree [C1–C3].")
sub("Why this can matter")
p("The Py-bugger example is decisive at the code level. The older rule requires ten attempts and equality between reported and successful counts; the newer incident predicate checks inflation. The saved synthetic fixture has 62 attempts, 7 successes, 1 persisted source difference and 10 reported insertions. The old rule rejects it, while the declared inflation condition is satisfied. An equal-count record can be accepted in the opposite direction. These are source-derived synthetic fixtures, not recovered official measurements.")
p("There is also a schema problem: some v4 fields do not match the raw runner's fields or nesting, including Audioread and Poetry examples. The repaired classification must remain unresolved until an explicit, independently checked mapping exists. Treating an absent exception field as proof that no exception occurred would convert missing evidence into a false success.")
sub("What the local candidate changes")
p(F["repair_detail"])
p("The candidate binds the exact registry bytes, selected predicate, complete raw observation and declared execution context. It keeps raw custody separate from a newly named projection of the measured outcome fields. That allows irrelevant stdout/stderr digest differences to remain visible without automatically redefining a reproducible measured outcome as different. Changed measurements or source/provider/command invariants still matter.")
p("A separate verification pass recomputes classification from supplied raw inputs and the expected registry digest. It does not merely accept a signed label. This shares the evaluator implementation, so it guards semantic binding and tampering; it is not proof against every possible common evaluator bug.")
sub("Review, repair and proof")
p(F["repair_review"])
p("Independent review specifically found an initial Boolean-versus-integer comparison edge case and an unenforced replay-helper precondition. The final candidate corrects those issues and retains the original review receipt. The initial fixture-extraction path error is also recorded. No historical result, expected scientific outcome, external provider, or private truth join was changed.")

page()
h("5. What the planning experiment actually tested")
p("The current Batch103 planner loop calls the ranking function, but constructs expected information gain from remaining list rank and raises an error if the selected action differs from the next frozen item. That establishes a test of fixed acquisition order with selected outcome access, not a full test of observation-dependent next-action planning [C4]. Freezing a conditional policy before evaluation would preserve a valid precommitment while allowing its later choice to depend on what it actually observes.")
p("I built a finite acquisition experiment with four shared-prerequisite graphs, three hidden availability bits, four incident/control pairs, and an eight-action budget. Every vault access and prerequisite probe costs one action. All eight hidden worlds were evaluated for every graph. The exact generic policy sees only the public model and paid observation history. The original fixed-order comparator is globally optimized within its class.")
tab(["Original frozen arm", "Pairs / 32", "All actions", "Actions on attainable cases", "Actions on unattainable cases"], [
    ("Best fixed order", "18", "164", "52", "112"),
    ("Generic adaptive, vault only", "18", "76", "44", "32"),
    ("Generic adaptive + probes", "18", "74", "48", "26"),
    ("Reaction-schema adapter", "18", "74", "48", "26"),
    ("Neutral-label adapter", "18", "74", "48", "26"),
    ("Unknown treated as unavailable", "0", "0", "0", "0"),
], [171, 57, 67, 100, 100])
p("All competent arms obtained all 18 attainable pairs. The other 14 cases had no available pair under the declared model. Much of the aggregate saving comes from justified early stopping in those cases. Extra probes save only two actions overall relative to adaptive vault access; they cost four more actions on successful cases. These are costs of evidence acquisition, not improved diagnosis, causal ownership or biological prediction.")
p("The reaction adapter compiles into the same generic solver. Its equal result and neutral-label invariance show that renaming the same semantics adds no information. They do not constitute an independent algorithm replication. The frozen run has 192 episodes, 462 charged observations and 64 generic/adapter trace equivalences, with no verified budget or false-pair errors. Nine mechanism tests pass.")
p("The design was sealed locally before evaluation; this is an integrity record, not externally authenticated preregistration. The finite worlds are deterministic, noiseless and supplied with correct dependencies. No scalability or real-provider generalization follows.", "Small")

page()
h("6. Separating better choices from better stopping")
p("The first experiment changed both next-action choice and the ability to stop when success was ruled out. Reporting its total cost saving as a pure reordering benefit would be misleading. A separately frozen exploratory follow-up therefore adds a stronger fixed vault-only order with sound model-relative impossibility stopping.")
p(F["stopping_detail"])
tab(["Follow-up comparison", "Total actions", "Attainable", "Unattainable"], F["stopping_rows"], [240, 85, 85, 85])
p(F["stopping_interpretation"])
p("This follow-up was motivated by the original results and uses the same scenario family. Its role is attribution and fairness, not independent held-out confirmation. It preserves the original seal and result file. No fixed sequence containing prerequisite probes was optimized; such probes could help early stopping. The well-matched 96-versus-76 contrast uses vault-only actions on both sides. The stopping_ablation directory records its separate design, computation, verification and scope.")
sub("What the original source controls add")
p("Six planner controls confirm that blocked/prerequisite metadata alone does not alter a choice when action scores stay fixed; changed scores and zero budget do affect it. A compiler control changes wrapped quantities while retaining field presence and gets the same operation families. This does not mean every stored value is discarded.")
p("The earlier runtime executes real resource and compartment rules. The specific Batch103 shadow generator uses an operation-label hash chain and structural receipts instead. It preserves useful lineage, but that path does not simulate molecular kinetics. Scientific claims must identify which executable path was tested [C5].")

page()
h("7. Why timing can matter even when a map looks right")
p("A standard two-state continuous-time model supplies an exact counterexample. Let state 0 switch to state 1 at rate a, and state 1 switch back at rate b. Balancing stationary flow gives (1 − p)a = pb, so p = a/(a + b). Multiplying both rates by the same positive number preserves that occupancy and the interaction graph, while changing residence time.")
p("p = a / (a + b)<br/>P(stays in state 1 for all of [0, τ] | starts in 1) = exp(−bτ)<br/>P(ends in state 1 | starts in 1) = p + (1 − p) exp(−(a + b)τ)", "Eq")
p("For a = b = 0.1 and a = b = 10, both occupancies are 50%. Over one arbitrary time unit, uninterrupted availability conditional on starting available is 90.4837% versus 0.004540%. Endpoint availability is different: approximately 90.9365% versus 50.0000%, because a system can leave and return. These are exact standard-model implications, not fitted biological results.")
story.append(Image(str(ROOT / "kinetics/same_occupancy_different_timing.png"), width=495, height=226))
plain.append("Figure: identical occupancy, different conditional continuous availability; arbitrary time units.")
p("The script checks stationary flow and independently compares the endpoint formula with a matrix exponential. A second review confirmed the formulas and corrected the plot's conditioning label. It is not a novel theorem and does not deserve a discovery claim by itself.")
p("The practical bridge is conditional: if an operation requires uninterrupted availability, its test must measure that property. If it only requires availability at the decision instant, a continuous-window requirement may be unnecessary. ControllerGate already has freshness, revocation and interlock concepts. This illustration does not establish that every current token or interlock fails to enforce its intended temporal contract.")

page()
h("8. A defensible TORUS/TLD research route")
p("Treat TORUS's dimensions as the intended cascading levels of organization and complexity. A physical observation can be compatible with that framing without selecting a unique count or demonstrating a new law. The video and the papers provide places to test a specified constraint, not a replacement for that test.")
tab(["Project idea", "Operational version worth testing", "What would establish added value"], [
    ("Interlock logic", "Explicit required components, alternative routes, timing and context prerequisites.", "Ablation changes held-out prediction or decision quality beyond an equivalent generic dependency model."),
    ("Observed / unobserved", "Separate latent state, the instrument's output, and missing observations.", "Better calibration or fewer false conclusions under controlled observation loss, against an established observation-aware baseline."),
    ("Scaling", "Carry units, spatial scale, exposure, frame interval and aggregation rule through every model comparison.", "A prespecified scale-dependent prediction transfers to held-out acquisition conditions or biological perturbations."),
    ("Elbow logic", "Define a measurable change point and candidate alternatives before inspecting evaluation data.", "An independent intervention or replicated held-out transition, not a selected visual bend."),
    ("Closure", "Name structural, dynamical, observational or authorization closure separately.", "The claimed closure criterion is executed and independently checked at the right level."),
    ("14 / 10+4", "A fully specified constraint or architecture with its parameter count and layer semantics.", "It outperforms 12,13,15,28 and unconstrained alternatives under equal tuning, or a noncircular theorem derives the count."),
], [94, 201, 200])
p("A useful ordinary starting point is dx/dt = S·v(x; θ,c), or a stochastic reaction model, paired with Yk = Mψ,c[X over the exposure window] + noise. S encodes reactions; θ contains rates and transport; c is context; M includes the instrument, blur, localization and tracking. These established model classes already implement much of the needed distinction. A TORUS/TLD contribution must specify what additional constraint it adds.")
p("Nothing here validates a 14-layer physical manifold, a double-cover cosmological closure, or a universal time mechanism. Seconds near fourteen, fourteen volume orders, and five imaging coordinates are different quantities with different units and meanings. They must not be counted as independent numerical corroboration.")

page()
h("9. The concrete biological benchmark and its limit")
p("The most immediately relevant existing benchmark is Spot-On's acquisition series [B6]. It supplies experimental single-cell trajectories and simulations designed to expose observation biases. A serious extension should compare a naive trajectory summary, the original observation-aware method, and the proposed additional constraint using the same information and budget.")
tab(["Design item", "Required specification"], [
    ("Data unit", "Preserve cell, experiment-day/replicate and acquisition metadata. Split at independent days/cells; do not distribute tracks from one cell across training and test sets."),
    ("Prediction", "Choose diffusion/population-fraction or observation-level predictions that the data support. Do not silently reinterpret short tracking data as complete binding-lifetime evidence."),
    ("Observation model", "Record exposure, frame interval, localization precision, tracking losses and focal-plane exit. Vary these as measurement conditions, not as biological perturbations."),
    ("Specific contribution", "Freeze an executable TORUS/TLD constraint, parameter count, fitting procedure and expected direction of benefit before evaluation."),
    ("Fair comparator", "Include an equally informed generic model and label-shuffled/constraint-removed ablations. Use a complexity penalty or equal tuning budget."),
    ("Success", "A repeatable improvement on held-out prediction/calibration, with uncertainty computed at the relevant experimental unit. Independent biological interventions remain a separate stage."),
], [116, 379])
p("A bounded public download was attempted after freezing a first-lexicographic-cell, schema-only inspection plan. The exact observed archive URL returned HTTP 403 with the message that calls to that URL were not allowed. The web tool separately rejected the 40,222,696-byte archive on size. This is an access-route limitation, not evidence that the public dataset is unavailable generally. No trajectory bytes were inspected or fitted here.")
p("The archive listing, member names, documented columns, provider checksum and failed-request receipt are retained. The provider checksum was recorded, not verified against downloaded bytes. Chen's perturbation comparisons and Hammar's matched successful/failed occupancy cases are additional biological targets; neither is silently substituted with synthetic trajectories.")
sub("What a large result would have to look like")
p("A valuable result would demonstrate that a specific new constraint improves predictive behavior under an independent change of context or measurement, and that the benefit cannot be reproduced by a competent generic model with the same information. The present code findings justify pursuing that question, but do not establish its answer.")

page()
h("10. Publication assessment and repair playbook")
tab(["Potential output", "Current status", "Publication threshold"], [
    ("Technical audit and reproducibility note", "Supported now: an exact call-path mismatch, local correction, executable controls, preserved negative outcomes.", "Useful engineering transparency; not presented as a major biological or theoretical discovery."),
    ("Methods paper on evidence acquisition", "A runnable finite benchmark and a meaningful stopping/reordering distinction now exist.", "Independent real-case benefit against equally informed generic policies, realistic costs, noise and missingness."),
    ("Biological modeling paper", "Literature-backed mechanism and a specific open benchmark identified.", "Actual trajectory analysis, a new defined constraint, independent context transfer and uncertainty estimates."),
    ("TORUS/TLD fundamental result", "Not established by this pass.", "A noncircular derivation or discriminating empirical prediction that survives layer-count and generic-model alternatives."),
], [129, 181, 185])
p("Under Brad's requirement for significant work, the local fixes and standard two-state calculation should not be promoted into separate breakthrough papers. Their value is that they remove ambiguity from a larger, testable program. The technical audit can be shared honestly as an audit; the major scientific claim must wait for evidence of the required kind.")
sub("Root cause → fix → detection → nearby exposure")
tab(["Failure class", "Repair and detection", "Where else to check"], [
    ("Registry identity without evaluation", "Recompute the selected predicate on bound raw inputs; use fixtures where old and new rules disagree.", "Fresh wrappers, seals, public evidence compilation and any imported verdict caches."),
    ("Missing field treated as negative", "Typed unresolved result and explicit schema mapping; omit required fields deliberately in tests.", "Nested observations, exception checks, provider differences and versioned extractors."),
    ("Raw bytes confused with outcome", "Keep full custody hash plus a declared observable projection; vary logs while holding measured fields fixed.", "Replay comparisons and provenance claims at every summarization boundary."),
    ("Fixed sequence called adaptive", "Freeze a conditional policy and compare with sound-stop baselines; inspect response to changed observations.", "Information-gain labels, stopping rules, unavailable-input handling and scoring criteria."),
    ("Structural receipt called dynamics", "Name the actual executed state-transition path and its quantities; require perturbation-sensitive outputs.", "Reaction mapping, simulated rehearsals, compiler family selection and closure summaries."),
], [123, 208, 164])

page()
h("11. Reproduction and remaining boundaries")
p("The companion package contains the code, frozen specifications, exact local results, source identity ledger, focused regression fixtures, integration candidate, independent review, plotting script and access receipts. It does not duplicate the uploaded video or Brad's full private Systems Guide. The package manifest binds every included payload by SHA256.")
sub("Verification already completed")
p(F["verification_summary"])
p("The original planning verifier checks all 192 episodes and its sealed source hashes. The follow-up has a separate record. The exact timing calculation uses SciPy's matrix exponential as a numerical cross-check; it does not claim biological validation. PDF rendering and text/layout checks are recorded separately.")
sub("Reproduction entry points")
p("Run the top-level verify_package.py first to check file identities. The README.txt then gives the semantic candidate and wrapper-seam regression command, the original planning verifier, the separate stopping-ablation verifier, and the kinetics script. Replays should be written to a fresh directory so they do not overwrite the original evidence. Dependency versions are recorded in the environment receipt.")
sub("What remains unverified")
p("The corrected semantic path has not been deployed or executed against fresh external providers. Unmapped observation schemas remain unresolved. The original raw run artifacts were not available to reclassify historical outcomes. The new policy has not demonstrated real-case repair or causal ownership. Raw biological observations were not downloaded. No general result selecting fourteen layers or proving TORUS's physical claims follows.")
p("Those limits do not erase the verified source defect or the completed local work. They define the next kind of evidence needed: correctly evaluated fresh observations, equally informed policy comparisons, and an explicit biological model tested on independent data. A new diagram or another numerical analogy would not provide that evidence.")
sub("Done-here record")
p("A concise completion note is included for Brad's records. It has not been sent to Command Center and is not a new board task. No remote repository, provider environment, account setting, or public publication was modified by this research pass.")

page()
h("12. Source index")
sources = [
    ("B1", "632nm. Eric Betzig interview, 8 September 2026. Original publisher episode and companion article.", "https://share.transistor.fm/s/46173a34"),
    ("B2", "Chen et al. Single-molecule Dynamics of Enhanceosome Assembly in Embryonic Stem Cells. Cell (2014). DOI 10.1016/j.cell.2014.01.062.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC4040518/"),
    ("B3", "Hammar et al. Direct measurement of transcription factor dissociation excludes a simple operator occupancy model for gene regulation. Nature Genetics (2014). DOI 10.1038/ng.2905.", "https://elflab.icm.uu.se/lore/ref/NatureGen-2014-Hammar.pdf"),
    ("B4", "Liu et al. Observing the cell in its native state: Imaging subcellular dynamics in multicellular organisms. Science (2018). DOI 10.1126/science.aaq1392.", "https://pmc.ncbi.nlm.nih.gov/articles/PMC6040645/"),
    ("B5", "Delarue et al. mTORC1 Controls Phase Separation and the Biophysical Properties of the Cytoplasm by Tuning Crowding. Cell (2018). DOI 10.1016/j.cell.2018.05.042.", "https://www.sciencedirect.com/science/article/pii/S0092867418306548"),
    ("B6", "Hansen et al. Robust model-based analysis of single-particle tracking experiments with Spot-On. eLife (2018). DOI 10.7554/eLife.33125. Experimental data DOI 10.5281/zenodo.834781.", "https://elifesciences.org/articles/33125"),
    ("B7", "Wong, Siah and Lo. Estimation of clinical trial success rates and related parameters. Biostatistics (2019). DOI 10.1093/biostatistics/kxx069.", "https://academic.oup.com/biostatistics/article/20/2/273/4817524"),
    ("B8", "Reactome official data model; organ FAQ; Reactome Knowledgebase 2026, DOI 10.1093/nar/gkaf1223. Current documentation checked separately from paper release counts.", "https://reactome.org/documentation/data-model"),
    ("B9", "Levesque. What is planning in the presence of sensing? (1996). Prior work on conditional planning; adaptation to observations is not a new TORUS invention.", "https://www.cs.toronto.edu/kr/papers/sensing.pdf"),
]
for key, desc, url in sources:
    p("<b>" + key + ".</b> " + escape(desc) + " " + link("Primary source", url), "Small")
base = "https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/"
for key, desc, path in [
    ("C1", "Fresh wrapper: legacy runner invocation and forwarded predicate result.", "scripts/run_batch102_candidate_slice.py"),
    ("C2", "Legacy candidate-specific predicate and raw-observation replay comparison.", "scripts/run_batch100_candidate_program.py"),
    ("C3", "Declared v4 semantic predicates; also inspect the fresh verifier and outcome seal in the source ledger.", "configs/batch102_outcome_semantic_registry_v4.jsonl"),
    ("C4", "Fixed next-action enforcement and rank-based information-gain field.", "scripts/run_batch103_planner_arm.py"),
    ("C5", "Specific source-grounded structural shadow generator. Earlier primitives/runtime are separately credited.", "scripts/build_batch103_reactome_closure.py"),
    ("C6", "Current handoff and the repository's reported official outcomes.", "docs/CURRENT_CONTROLLERGATE_HANDOFF.md"),
]:
    p("<b>" + key + ".</b> " + escape(desc) + " " + link(path, base + path), "Small")
p("Full source keys, physical line ranges, retrieval identities and per-claim limits appear in the companion source ledgers. Video time ranges are approximate and refer to the uploaded screen recording.", "Small")


def footer(canvas, doc):
    canvas.saveState()
    width, height = A4
    canvas.setStrokeColor(colors.HexColor("#cbd7dd"))
    canvas.line(50, 40, width - 50, 40)
    canvas.setFont("DejaVu", 7.5)
    canvas.setFillColor(MUTED)
    canvas.drawString(50, 26, "Halcyon / TORUS research • Source audit and local candidate • 22 Nov 2026")
    canvas.drawRightString(width - 50, 26, str(doc.page))
    canvas.restoreState()


pdf = OUT / "Reactome_ControllerGate_Research_Review_2026-11-22.pdf"
doc = SimpleDocTemplate(str(pdf), pagesize=A4, rightMargin=50, leftMargin=50, topMargin=46,
                        bottomMargin=55, title="Reactome, live-cell dynamics, and ControllerGate",
                        author="Halcyon for Brad")
doc.build(story, onFirstPage=footer, onLaterPages=footer)
(ROOT / "report/report_text.txt").write_text("\n\n".join(plain) + "\n", encoding="utf-8")
print(pdf)
