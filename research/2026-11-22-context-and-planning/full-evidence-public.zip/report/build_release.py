"""Package this standalone audit, retaining original receipts and source identities."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import subprocess
import sys
import zipfile
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "deliverables"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


files = []
for directory in ("context", "history", "bridge", "science", "stopping_ablation", "kinetics"):
    for path in sorted((ROOT / directory).rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix != ".pyc":
            files.append(path)
for name in ("video_receipt.json", "README.txt", "DONE_HERE_NOTE.txt", "CLAIM_LEDGER.json", "verify_package.py"):
    files.append(ROOT / name)
for name in ("build_report.py", "build_release.py", "summary_facts.json", "report_text.txt",
             "FINAL_PDF_QA.json", "PATCH_APPLICABILITY.json", "environment_receipt.json"):
    files.append(ROOT / "report" / name)
pdf = OUT / "Reactome_ControllerGate_Research_Review_2026-11-22.pdf"
files.append(pdf)
files = sorted(set(files))
missing = [str(p) for p in files if not p.is_file()]
if missing:
    raise RuntimeError("Missing deliverables: " + ", ".join(missing))

manifest = {
    "schema": "ResearchAuditPayloadManifestV1",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "scope": "Standalone report, isolated research candidates and limited source evidence; no whole repository clone or live deployment.",
    "files": [{"path": str(p.relative_to(ROOT)), "bytes": p.stat().st_size, "sha256": sha(p)} for p in files],
    "exclusions": ["manifest itself", "release ZIP and external release receipt", "original video",
                   "full personal guide", "OCR intermediates", "PDF preview images", "Python caches"],
}
mp = ROOT / "MANIFEST.json"
mp.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
check = subprocess.run([sys.executable, str(ROOT / "verify_package.py")], text=True, capture_output=True, check=True)
verification = json.loads(check.stdout)
archive = OUT / "Reactome_ControllerGate_Evidence_and_Repair_2026-11-22.zip"
prefix = "Reactome_ControllerGate_2026-11-22"
with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    for path in files + [mp]:
        z.write(path, arcname=f"{prefix}/{path.relative_to(ROOT).as_posix()}")
with zipfile.ZipFile(archive) as z:
    if z.testzip() is not None:
        raise RuntimeError("Archive CRC failed")
    # Check exact archived payload bytes, not merely the source-side hashes.
    for row in manifest["files"]:
        data = z.read(f"{prefix}/{row['path']}")
        if len(data) != row["bytes"] or hashlib.sha256(data).hexdigest() != row["sha256"]:
            raise RuntimeError("Archived payload mismatch: " + row["path"])

receipt = {
    "status": "PASS",
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "payload_files": len(files),
    "payload_bytes": sum(r["bytes"] for r in manifest["files"]),
    "manifest_sha256": sha(mp),
    "package_integrity_verification": verification,
    "zip_crc_and_payload_verification": "PASS",
    "report": {"filename": pdf.name, "bytes": pdf.stat().st_size, "sha256": sha(pdf), "pages": 13},
    "archive": {"filename": archive.name, "bytes": archive.stat().st_size, "sha256": sha(archive)},
    "semantic_repair": {"focused_methods_passed": 33, "independent_review": "PASS_WITH_STATED_SCOPE",
                         "patch_applicability": "PASS", "provider_workflow_executed": False, "deployed": False},
    "planning": {"original_episodes": 192, "charged_observations": 462, "mechanism_tests": 9,
                 "exploratory_followup_episodes": 64, "fixed_permutations_checked": 161280,
                 "attainable_pairs_acquired_by_competent_arms": 18, "scenarios_per_arm": 32},
    "raw_biological_data_analyzed": False,
    "new_TORUS_or_N14_empirical_validation": False,
    "scope": "Integrity and stated local verification; hashes and passing tests do not establish biological truth or authenticate external provider execution.",
}
rp = OUT / "Reactome_ControllerGate_Verification_2026-11-22.json"
rp.write_text(json.dumps(receipt, indent=2, sort_keys=True) + "\n", encoding="utf-8")
print(json.dumps(receipt, indent=2))
