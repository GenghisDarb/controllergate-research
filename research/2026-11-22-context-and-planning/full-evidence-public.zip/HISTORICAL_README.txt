REACTOME / LIVE-CELL DYNAMICS / CONTROLLERGATE
Source audit and local repair package. User-facing date: 2026-11-22, Las Vegas.

START HERE
The complete report is deliverables/Reactome_ControllerGate_Research_Review_2026-11-22.pdf.
Run `python verify_package.py` from this folder to check the manifest-bound payload.
That checks bytes; it does not establish scientific truth or authenticate providers.

WHAT WAS COMPLETED
1. Inspected the uploaded video via frames and captions and verified original publisher context.
2. Read relevant sections of the newest accessible Brad Systems Guide and audited current
   ControllerGate source, including later corrections and the official-run call path.
3. Created a concrete four-file local integration patch that binds outcome classifications
   to the actual frozen registry and raw observation, preserving unresolved cases.
4. Ran 33 focused semantic/wrapper/seal methods, with a separate independent review.
5. Ran a pre-sealed 192-episode synthetic evidence-acquisition experiment, nine mechanism
   tests, source-function controls, and independent trace verification.
6. Ran a separately frozen exploratory stopping ablation (64 more episodes), checking
   exact optimal fixed vault orders against all 40,320 permutations per graph.
7. Checked exact two-state mathematics and arithmetic from published Hammar table means.
8. Audited primary biological papers and attempted one bounded public-data download.
   That route returned HTTP 403; no raw biological trajectory was analyzed.

MAIN RESULT BOUNDARIES
The actual software evaluation path has a verified semantic-binding defect and a fixed-order
planning limitation. The local patch has not been deployed or tested in a full external
provider workflow. Old reported campaign counts are preserved, not revised.

The acquisition experiments demonstrate bounded cost savings, with unchanged attainable
pair coverage. The strongest matched fixed vault-only order plus sound stopping used 96
actions versus 76 for adaptive vault-only selection. Adding probes gave 74 total but cost
more on successful cases. Reaction labels added no benefit. Worlds, dependencies and
observations were tiny, exact and noiseless; no real-provider gain is claimed.

The biology supports explicit dynamics, context and measurement models. The standard
kinetic example is not a novel discovery. No result here selects fourteen layers or proves
TORUS/TLD physical claims. Existing ControllerGate interlocks and real resource/compartment
simulation work are credited rather than falsely described as absent.

DIRECTORY MAP
context/                 Guide metadata, evidence scope and approximate video claim map.
video_receipt.json       Identity of the separately uploaded original video.
history/                 Current-source manifest, chronology, source excerpts and semantic audit.
history/repair_candidate/ Reviewable patch, copied comparison fixtures, integration copies,
                         development/error record, tests and final verification.
bridge/                  Original sealed experiment, generic planner, adapter, source controls,
                         trace verifier and independent repair/report reviews.
stopping_ablation/       Separately frozen follow-up, all 64 new traces and exhaustive checks.
science/                 Primary-source memo/bibliography, claim boundaries, failed access receipt.
kinetics/                Exact calculation, published-summary arithmetic, results and plot.
report/                  PDF builder, complete report text, numerical facts and QA records.
MANIFEST.json            SHA256 and length for every included payload; excludes itself.

REPRODUCTION WITHOUT OVERWRITING ORIGINAL RECEIPTS
Make a working COPY of the unpacked package first. Some verifiers regenerate their own
time-stamped verification receipts; never treat such rewritten receipts as the originals.
The semantic and planning code uses the Python standard library.

Semantic repair (inside history/repair_candidate):
  python run_checks.py --output fresh_local_checks
The destination must be new or empty. Tests execute inserted wrapper/seal helpers and
verify their call sites. They do not launch provider workflows.

Original planning (inside bridge, in the working copy):
  python -B verify_experiment.py
  python -B -m unittest -v test_conditional_acquisition.py
For a new full original experiment, follow bridge/README.md: copy the five sealed source
and spec files into a fresh folder, freeze, execute once and verify. Preserve originals.

Stopping ablation:
Read stopping_ablation/README.md. In a WORKING COPY retain the sibling bridge/ inputs;
use a fresh stopping-ablation directory containing only run_stopping_ablation.py and
experiment_spec.json, then run --freeze followed by --execute. This is an exploratory
follow-up on the same scenarios, not an independent validation set.

Kinetics (inside kinetics, in the working copy):
  python check_kinetics.py
Requires NumPy, SciPy and Matplotlib. No data or parameter fitting occurs. The Python and
package versions used for this report are in report/environment_receipt.json.

PDF regeneration (working copy):
  python report/build_report.py
Requires ReportLab and DejaVu fonts at the path in the builder. The saved PDF needs no
Python to read. A plain extracted report is report/report_text.txt.

PATCH STATUS
history/repair_candidate/INTEGRATION_CANDIDATE.patch applies cleanly to the inspected source
at 38897b79588f3ff4b1b9002eedc299a9bcf05140. Wrapper and seal changes belong together;
predicate_result is nullable for unresolved evidence. Other consumers need a compatibility
review before deployment. Unmapped Audioread/Poetry fields deliberately remain unresolved.
This package does not apply the patch to a live repository or authorize an external repair.

PROVENANCE AND STORAGE SCOPE
Included source snippets/snapshots are the limited evidence necessary for an audit, with
their exact repository identities. This is not a clone or backup of the whole repository.
The full personal Systems Guide, original 61 MB video, OCR frames, temporary caches and
provider environments are not duplicated. No Command Center memory/task was written.
