"""Verify packaged payload bytes only. No network, providers, or code changes."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / "MANIFEST.json").read_text(encoding="utf-8"))
failures = []
for row in manifest["files"]:
    path = (root / row["path"]).resolve()
    if root not in path.parents:
        failures.append({"path": row["path"], "error": "path_not_inside_package"})
        continue
    if not path.is_file():
        failures.append({"path": row["path"], "error": "missing_file"})
        continue
    raw = path.read_bytes()
    if len(raw) != row["bytes"] or hashlib.sha256(raw).hexdigest() != row["sha256"]:
        failures.append({"path": row["path"], "error": "payload_mismatch"})
print(json.dumps({"status": "PASS" if not failures else "FAIL",
                  "payload_files_checked": len(manifest["files"]),
                  "failures": failures,
                  "scope": "Integrity of listed bytes, not scientific truth or authenticity of external execution."}, indent=2))
raise SystemExit(bool(failures))
