# Selected exact source excerpts

Line numbers are physical newline-delimited lines, not notebook cell indices or Unicode splitlines indices.


## CG01 — docs/CURRENT_CONTROLLERGATE_HANDOFF.md — L3–11

SHA256: `6418f1f5bce88b92cc9015493216dfcbf654629c6ddc0a9098cf5ecec976186b`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/docs/CURRENT_CONTROLLERGATE_HANDOFF.md

```text
3: Batch100 began from commit `c9646cdf5f9e321d179397082d9fa9439c15c196` and officially ingested the successful Batch099 public artifact before new science. The ingest checkpoint is recorded in the permanent completion ledger.
4: 
5: Batch099 established that all 432 apparent contradictions were false mutual exclusions caused by treating contact as causal ownership. It reclassified 504 admissions as contact evidence, preserved zero ownership facts, and correctly terminated all 80 policies with insufficient evidence. The remaining scientific blockers are the absence of candidate-bound matched counterfactual execution and zero nonbaseline causal coverage.
6: 
7: Batch100 separated issue-reported provider identity from the Batch098 execution provider, constructed eight immutable source-capsule identities and thirteen provider-capsule identities, froze nine candidate-bound programs and thirty-two cells, and executed the public provider matrix without truth, private ordering data, patches, or future fixes. Repeated official runs reported 15 and 16 reproducible cells; that variation remains an explicit reliability blocker. Two incident programs materialized, but no sensitivity, necessity, sufficiency, interaction, or ownership result was established. All eighty policy/candidate terminals therefore remained `INSUFFICIENT_EVIDENCE`.
8: 
9: The independent copied-tree critic rejected all fifty semantic mutations. The local-only truth join verified the eight-candidate private bundle and found six scoreable causal cases, zero causal coverage, zero causal accuracy, and zero false attribution for every policy. Causal feasibility and historical calibration are blocked; architecture and private-ordering gain remain not established. No protected repair is eligible.
10: 
11: Continue from `configs/controllergate_master_completion_ledger_v2.json`. The next safe action is to materialize the remaining exact-provider cells—starting with the OpenBB secondary-source service fixture—and then preregister necessity, sufficiency, or factorial exclusions before another ownership evaluation. Run `python scripts/audit_controllergate_master_completion_ledger.py` before and after each batch. Do not change protocol v2.19, repair counts, production readiness, or release status without their later independent goals completing.
```


## CG01 — docs/CURRENT_CONTROLLERGATE_HANDOFF.md — L13–59

SHA256: `6418f1f5bce88b92cc9015493216dfcbf654629c6ddc0a9098cf5ecec976186b`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/docs/CURRENT_CONTROLLERGATE_HANDOFF.md

```text
13: 
14: Batch101 officially ingests the exact Batch100 public artifact before changing execution semantics. The ingest checkpoint is `ffb74368beeb0b4e85b1bf0288d91f9a0a169a97`; its outer SHA256 is `37cb3b9657863d830abeee8f73385a838fee25f3f610250dd171153805358945`. Batch100 remains immutable and authoritative for what it actually executed, while the following execution-semantic defects are carried forward explicitly:
15: 
16: 1. The artifact had not been officially ingested at the Batch100 handoff.
17: 2. Candidate-specific code, rather than the frozen outcome registry, decided predicates.
18: 3. The Py-bugger accounting predicate required equality even though count inflation is the incident.
19: 4. Reproducible Py-bugger observations `62/7/1` and `49/5/1` were misclassified.
20: 5. Replay reproducibility compared complete observation dictionaries.
21: 6. Volatile hashes, durations, traces, paths, addresses, and installation paths affected replay identity.
22: 7. Raw custody identity and semantic identity were not separated.
23: 8. Pair validity did not require both incident and control predicate satisfaction.
24: 9. Factorial validity did not require every factor corner.
25: 10. Sensitivity used whole-observation inequality rather than a frozen projection.
26: 11. Necessity, sufficiency, and interaction were not computed from executed cells.
27: 12. OpenBB was blocked before execution.
28: 13. Its secondary source was not acquired, served, flattened, or compared.
29: 14. Four registered OpenBB cells remained unexecuted.
30: 15. Poetry fixture metadata was not reflected in the actual working-directory basename.
31: 16. Poetry therefore inferred `consumer`, not the requested spaced directory name.
32: 17. The exact Poetry incident and control predicates were never tested.
33: 18. Audioread lacked pytest in the provider environment.
34: 19. Missing Audioread structured evidence was treated as control success.
35: 20. Pytest identified as `0.1.dev1` and failed its own minimum-version gate.
36: 21. Pytest Git-derived build-version metadata was not preserved.
37: 22. Darker failed before the Git-directory incident layer.
38: 23. Darker 1.2.2 source parity was not established.
39: 24. Git-trace timestamps were treated as semantic differences.
40: 25. The selected Cloudpickle TypeVar combination did not reproduce the incident.
41: 26. Cloudpickle source/provider selection was not tightly issue-time bound.
42: 27. Cloudpickle distutils evidence was stronger than its presence-only label.
43: 28. Volatile warnings made Cloudpickle Python 3.11 replays appear nonreproducible.
44: 29. Pytest-duration differences made Freezegun replays appear nonreproducible.
45: 30. Provider matching accepted a major/minor prefix as exact parity.
46: 31. Exact and series-limited provider states were conflated.
47: 32. Shallow tagless source custody could collapse setuptools-scm versions.
48: 33. Raw workspaces were removed before independent semantic reconstruction.
49: 34. The outcome-semantic registry was not the sole predicate authority.
50: 35. That registry lacked a generic declarative predicate language.
51: 36. Stable and volatile observation fields were not declared.
52: 37. Held invariants were copied from contracts rather than proven from receipts.
53: 38. Materialization, validity, difference, sensitivity, causal relations, and ownership were conflated.
54: 39. Permanent project memory did not record these exact execution-semantic defects.
55: 40. No corrected-cell Batch101 workflow existed.
56: 
57: The sealed expected-red record is `outputs/post_v2_37_hardening_batch101_canonical_semantic_replay_exact_incident_salvage_ownership_closure/batch101_pre_exact_incident_salvage_expected_failure.json`. These findings do not authorize a patch, repair-count change, Product Beta promotion, prospective-effectiveness claim, memory claim, production-readiness claim, or self-maintaining-software claim.
58: 
59: Batch101 corrects the predicate and replay layers without rewriting Batch100. Its frozen v3 registry has 33 cells, of which 28 retain official execution evidence and five are explicitly blocked. Py-bugger reaches a valid bounded factorial-sensitivity result under the corrected declarative predicate, but ownership remains open because necessity, sufficiency, and alternative exclusion have not run. The other eight programs safely abstain at their exact materialization, provider, source, or invariant boundary. All nine current terminals are `INSUFFICIENT_EVIDENCE`; no protected repair is eligible.
```


## CG01 — docs/CURRENT_CONTROLLERGATE_HANDOFF.md — L63–77

SHA256: `6418f1f5bce88b92cc9015493216dfcbf654629c6ddc0a9098cf5ecec976186b`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/docs/CURRENT_CONTROLLERGATE_HANDOFF.md

```text
63: ## Batch102 execution-origin correction and fresh-operation boundary
64: 
65: Batch101 was a semantic-reprojection campaign. It preserved and re-evaluated 56 raw operations executed during Batch100, but it performed zero fresh candidate target operations during the Batch101 workflow. Its 28 executed-cell records therefore mean `BATCH100_INHERITED_RAW_EXECUTION_BATCH101_REPROJECTION`, not fresh Batch101 execution.
66: 
67: Batch102 requires current-workflow broker receipts before any cell is classified as freshly executed. Inherited Batch100 or Batch101 records cannot satisfy that contract. Every future executed count must identify its execution epoch, workflow run, workflow job and attempt, workflow HEAD, broker operation, source tree, provider identity, raw output custody, independent verifier, and cleanup result.
68: 
69: This correction does not invalidate Batch101's semantic-contract work and does not authorize a repair. Necessity, sufficiency, alternative exclusion, causal ownership, architecture gain, prospective effectiveness, Product Beta, production readiness, and self-maintaining software remain unestablished until their executed evidence gates pass.
70: 
71: ## Batch103 handoff
72: 
73: The official Batch102 artifact is now ingested at checkpoint `ba8631281b75bff89a6b881fb19c0a972a4c8bfb`. Batch103 has a source-grounded, reaction-specific, nonauthorizing maintenance map and a corrected canonical architecture registry. The ten matched planner arms and their legal intervention sequences were frozen at `261fd73e` before outcomes.
74: 
75: Corrected official workflow run `29753821142` succeeded at execution HEAD `3aa1a749be0a1e13bd735623c812335af9795f76`: all 45 jobs passed. It submitted 34 current-epoch receipts covering 15 freshly executed cells; 55 of 70 preregistered vaults remained explicitly unmaterialized. No historical receipt was counted as fresh, and no public step accessed truth or private TLD data. Its 224-file artifact independently passed all three manifests (221 portable entries and 223 full entries), contains `governance/controllergate_isomorphism_registry_v3.jsonl`, and excludes the superseded handoff receipt. The downloaded archive remains quarantined and is not automatically ingested.
76: 
77: The post-artifact local truth join ran only after public terminals and artifact manifests were frozen and verified. Arms A-I each reached 1/6 causal coverage (16.67%) but zero causal accuracy and one false attribution; arm J abstained on all six scoreable programs. Reactome arms B-F therefore contributed five false attributions in aggregate. No candidate improved a preregistered public metric, while unsafe authority and leakage remained zero. Architecture gain, TLD ordering gain, R4, and R5 remain `NOT_ESTABLISHED`; R6 remains `NOT_RUN`. Goal 030 is `BLOCKED`, with a new preregistered experiment required to reopen it. The private calibration file and truth labels remain quarantined and untracked. Prospective effectiveness, memory lift, production readiness, and self-maintaining software remain unestablished. Repair counts remain 6 issue-derived, 4 native external, and 0 historical; the release boundary remains `PRODUCT_BETA_RC_BLOCKED_EXACT`.
```


## CG02 — docs/REACTOME_CONTROLLERGATE_COMPLETION_STATUS.md — L1–38

SHA256: `bd8f6fc63d000b27b3ab7a4c74bdbb17183bcd677b0d6ef7300c561cf34b9000`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/docs/REACTOME_CONTROLLERGATE_COMPLETION_STATUS.md

```text
1: # Reactome–ControllerGate completion status
2: 
3: ## Current result
4: 
5: Reactome integration is structurally advanced but is not complete. Completion requires cross-candidate gain at R5; prospective validation remains a separate future R6 requirement.
6: 
7: | Level | Meaning | Current status |
8: |---|---|---|
9: | R0 | Source custody | `PASS` |
10: | R1 | Lossless RPIR graph | `PASS_WITH_FORMAT_LIMITATIONS` |
11: | R2 | Source-bound translation | `PASS_WITH_GROUNDING_CAVEATS` |
12: | R3 | Executable shadow | `PASS_NONAUTHORIZING_SHADOW` |
13: | R4 | Causal-planning gain | `NOT_ESTABLISHED` |
14: | R5 | Cross-candidate generalization | `NOT_ESTABLISHED` |
15: | R6 | Prospective validation | `NOT_RUN` |
16: 
17: ## Structural coverage
18: 
19: The locked public structured source covers 2,916 pathway occurrences, 16,814 reaction occurrences, 46 ControllerGate primitive classes, and 29 source-family indexes. Every current reaction mapping preserves its raw Reactome chapter identity, source object, source hash, wrapped field state, and public-safe origin classification. Source-family normalization is an indexing layer only; it is not a biological-equivalence claim.
20: 
21: The current mapping authority derives primitives from reaction relations such as inputs, outputs, catalysts, regulators, compartments, event ordering, variants, failed reactions, entity sets, and complex membership. The older chapter-position slicing routine remains only as a historical synthetic coverage fixture and has no current mapping authority.
22: 
23: ## Execution boundary
24: 
25: Reaction-specific shadow operations cover source identity, compartment and prerequisite materialization, activation and inhibitor gates, ordered and parallel routes, failed-branch capture, rollback, duplicate replay, proof-ledger commit, and safe termination. These operations cannot write a causal terminal, create an ownership fact, authorize a patch, change a repair count, read sealed truth, or promote a release.
26: 
27: ## Causal-planning boundary
28: 
29: R4 requires a frozen, equal-budget Reactome-on/off ablation. A Reactome-enabled arm must improve at least one preregistered metric over canonical AMDS on at least two candidates without worsening false attribution, unsafe authority, truth leakage, or private-data leakage. R5 additionally requires replication across at least three candidates, two causal families, and more than one repository/provider class. Until those gates pass, structural coverage and executable shadow must not be described as causal gain.
30: 
31: ## Batch103 execution status
32: 
33: The ten matched arm contracts and all 90 program/arm plans were frozen at commit `261fd73e` before any Batch103 outcome was available. They share the same candidate evidence hashes, 70-cell legal intervention inventory, source/provider availability hashes, eight-operation budget, truth blindness, and repair prohibition. The pre-outcome vault registry contains 70 unmaterialized vaults and zero outcomes.
34: 
35: Corrected official run `29753821142` completed fresh candidate execution, isolated outcome opening, all ten arm evaluations, conservative causal compilation, terminal freezing, source-ownership reconstruction, and a 165-mutation independent critic at execution HEAD `3aa1a749be0a1e13bd735623c812335af9795f76`. It records 15 freshly executed cells, one typed incident, one valid pair, two complete factorials, one supported sensitivity receipt, and 90 terminals (`72 INSUFFICIENT_EVIDENCE`, `9 DIMENSION_SENSITIVITY_VERIFIED`, `9 SAFE_ABSTENTION`). Necessity, sufficiency, interaction, alternative exclusion, and ownership remain unsupported. The corrected 224-file artifact includes the canonical registry and passed all three manifests independently.
36: 
37: The local post-artifact truth join was performed after terminal and artifact verification. Arms A-I each had 1/6 causal coverage, zero causal accuracy, and one false attribution; arm J abstained completely. No candidate improved a preregistered public metric. Unsafe authority, truth leakage, and private-data leakage remained zero. R4 and R5 therefore remain `NOT_ESTABLISHED`, R6 remains `NOT_RUN`, and no structural count or software analogy is reported as measured planning gain. The private calibration output and truth labels are not tracked.
38: 
```


## CG03 — configs/controllergate_5_14_6_196_stack_v3.json — L1–44

SHA256: `a7d9d3582abaec87fe62dc99f173eae1978a850c131216b04a7a22f0be37db40`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/configs/controllergate_5_14_6_196_stack_v3.json

```text
1: {
2:   "activation_license_gate_count": 6,
3:   "authority_allowed": "internal operational translation and nonauthorizing shadow tests",
4:   "authority_forbidden": [
5:     "biological proof",
6:     "physical proof",
7:     "patch authorization",
8:     "repair count",
9:     "release promotion"
10:   ],
11:   "contact_ledger_slot_count": 14,
12:   "contract_hash": "b68249255c119e32293c5ab159dc408a1df5fd0c503dbcba9a4b18031d19711a",
13:   "fourteen_set_role": "bounded falsifiable contact audit with explicit missing and non-applicable slots",
14:   "mcm_boundary": "MCM2-7 is a six-subunit licensing system; no exact fourteen-nucleosome or 196-bp loading claim is authorized",
15:   "one_ninety_six_role": "ControllerGate 14x14 proof-recurrence schema",
16:   "order": [
17:     "five_set_reference_core",
18:     "fourteen_set_native_topology",
19:     "bounded_tension_relief_and_materialization",
20:     "six_set_activation_licensing",
21:     "bounded_operation_or_source_only_patch",
22:     "fourteen_contact_controller_audit",
23:     "duplicate_clean_replay",
24:     "phase_inversion_and_seed_constraint",
25:     "one_ninety_six_proof_obligations_ledger_lock"
26:   ],
27:   "proof_recurrence_cell_count": 196,
28:   "reference_core_count": 5,
29:   "rejected_interpretations": [
30:     "six_set_builds_closure",
31:     "preflight_pass_means_repairable",
32:     "fourteen_means_fourteen_literal_contacts_in_every_case",
33:     "MCM_loads_over_fourteen_nucleosomes",
34:     "fourteen_nucleosomes_equal_196_base_pairs",
35:     "one_ninety_six_is_universal_biology_constant",
36:     "single_system_TORUS_BROT_equals_ToT_BROT",
37:     "documentation_equals_empirical_validation",
38:     "Reactome_coverage_equals_causal_gain",
39:     "local_effect_equals_generalization"
40:   ],
41:   "schema": "ControllerGateCanonicalStackV3",
42:   "six_set_role": "licenses a bounded operation only after topology is legible"
43: }
44: 
```


## CG04 — configs/controllergate_isomorphism_errata_v3.json — L1–33

SHA256: `d69ffba1b268c0d2afdc45fb6e0f79de0948d7716a9086a45dcfa391428a2d5e`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/configs/controllergate_isomorphism_errata_v3.json

```text
1: {
2:   "append_only": true,
3:   "biological_source_corrections": [
4:     {
5:       "correction": "MCM2-7 is a six-subunit replication licensing system; ControllerGate does not claim exact loading across fourteen nucleosomes or a 196-bp span.",
6:       "errata_id": "CG-ISO-ERRATA-001",
7:       "historical_evidence_mutated": false,
8:       "status": "CURRENT_AUTHORITY"
9:     },
10:     {
11:       "correction": "Approximately 196/197 bp may be described only as a sourced nucleosome-repeat scale, never as an exact ControllerGate mechanism.",
12:       "errata_id": "CG-ISO-ERRATA-002",
13:       "historical_evidence_mutated": false,
14:       "status": "CURRENT_AUTHORITY"
15:     }
16:   ],
17:   "claim_boundary": "internal software-engineering analogy and operational translation only",
18:   "rejected_interpretations": [
19:     "six_set_builds_closure",
20:     "preflight_pass_means_repairable",
21:     "fourteen_means_fourteen_literal_contacts_in_every_case",
22:     "MCM_loads_over_fourteen_nucleosomes",
23:     "fourteen_nucleosomes_equal_196_base_pairs",
24:     "one_ninety_six_is_universal_biology_constant",
25:     "single_system_TORUS_BROT_equals_ToT_BROT",
26:     "documentation_equals_empirical_validation",
27:     "Reactome_coverage_equals_causal_gain",
28:     "local_effect_equals_generalization"
29:   ],
30:   "schema": "ControllerGateIsomorphismErrataV3",
31:   "status": "PASS"
32: }
33: 
```


## CG05 — controllergate/isomorphism/reactome_source_grounded_scenarios_v2.py — L14–65

SHA256: `1eaa2c0c37ebdedd3232c7472a01d4e907bd0cfcc30476bf1141a04b51a620c0`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/controllergate/isomorphism/reactome_source_grounded_scenarios_v2.py

```text
14: WRAPPED_REACTION_FIELDS = (
15:     "candidate_set_members",
16:     "catalyst_details",
17:     "complex_components",
18:     "edition_lineage",
19:     "entity_compartments",
20:     "entity_set_members",
21:     "literature_records",
22:     "modification_details",
23:     "nested_membership_closure",
24:     "normal_variant_graph",
25:     "regulator_details",
26:     "source_destination_transitions",
27:     "source_value_binding",
28:     "stable_event_edges",
29:     "stoichiometry",
30:     "timing_annotations",
31: )
32: 
33: FIELD_PRIMITIVES = {
34:     "candidate_set_members": ("CANDIDATE_SET", "DEMONSTRATED_MEMBER"),
35:     "catalyst_details": ("CATALYST", "COFACTOR"),
36:     "complex_components": ("COMPLEX_ASSEMBLY",),
37:     "edition_lineage": ("LINEAGE",),
38:     "entity_compartments": ("COMPARTMENT",),
39:     "entity_set_members": ("ENTITY_STATE", "CANDIDATE_SET"),
40:     "literature_records": ("EVENT_CONTRACT",),
41:     "modification_details": ("MODIFICATION_CODE",),
42:     "nested_membership_closure": ("PROCESSIVE_CYCLE",),
43:     "normal_variant_graph": ("NORMAL_VARIANT_PAIR", "NEGATIVE_REACTION"),
44:     "regulator_details": ("POSITIVE_REGULATOR", "NEGATIVE_REGULATOR"),
45:     "source_destination_transitions": ("TRANSLOCATION", "TARGETING"),
46:     "source_value_binding": ("EVENT_CONTRACT", "IRREVERSIBLE_REACTION"),
47:     "stable_event_edges": ("CHECKPOINT", "PHASE_MACHINE"),
48:     "stoichiometry": ("RESOURCE_FLUX",),
49:     "timing_annotations": ("STALL_DETECTION", "QUALITY_CONTROL"),
50: }
51: 
52: OPERATION_FAMILIES = (
53:     "source_identity_resolution",
54:     "compartment_materialization",
55:     "required_input_acquisition",
56:     "cofactor_materialization",
57:     "activation_gate",
58:     "inhibitor_check",
59:     "ordered_stage_transition",
60:     "parallel_pathway_exploration",
61:     "alternative_route_recovery",
62:     "failed_reaction_capture",
63:     "rollback_and_quarantine",
64:     "duplicate_replay",
65:     "proof_ledger_commit",
```


## CG05 — controllergate/isomorphism/reactome_source_grounded_scenarios_v2.py — L84–175

SHA256: `1eaa2c0c37ebdedd3232c7472a01d4e907bd0cfcc30476bf1141a04b51a620c0`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/controllergate/isomorphism/reactome_source_grounded_scenarios_v2.py

```text
84: 
85: def derive_primitive_ids(record: dict[str, Any]) -> list[str]:
86:     """Derive primitives only from present reaction relations."""
87:     ordered = ["EVENT_CONTRACT"]
88:     for field in WRAPPED_REACTION_FIELDS:
89:         if source_has_value(record, field):
90:             for primitive in FIELD_PRIMITIVES[field]:
91:                 if primitive not in ordered:
92:                     ordered.append(primitive)
93:     return ordered
94: 
95: 
96: def field_origin(record: dict[str, Any], field: str) -> str:
97:     if field in {
98:         "source_stable_id",
99:         "source_database_id",
100:         "source_class",
101:         "source_occurrence_identity",
102:         "chapter_identity",
103:         "display_name",
104:         "evidence_maturity",
105:         "source_graph_hash",
106:     }:
107:         return "DIRECT_REACTOME_VALUE"
108:     wrapped = record.get(field)
109:     if not isinstance(wrapped, dict):
110:         return "UNKNOWN"
111:     if wrapped.get("state") == "SOURCE_VALUE":
112:         return "RPIR_STRUCTURAL_RELATION"
113:     if wrapped.get("state") in {
114:         "SOURCE_EXPLICITLY_EMPTY",
115:         "SOURCE_NOT_APPLICABLE",
116:         "SOURCE_NOT_EXPOSED_BY_FORMAT",
117:         "PARSER_FAILED",
118:         "UNRESOLVED_REFERENCE",
119:     }:
120:         return "DERIVED_REACTOME_VALUE"
121:     return "UNKNOWN"
122: 
123: 
124: def operation_sequence(record: dict[str, Any]) -> list[str]:
125:     operations = ["source_identity_resolution"]
126:     if source_has_value(record, "entity_compartments") or source_has_value(
127:         record, "source_destination_transitions"
128:     ):
129:         operations.append("compartment_materialization")
130:     if source_has_value(record, "source_value_binding"):
131:         operations.append("required_input_acquisition")
132:     if source_has_value(record, "catalyst_details"):
133:         operations.append("cofactor_materialization")
134:     if source_has_value(record, "stable_event_edges"):
135:         operations.extend(("activation_gate", "ordered_stage_transition"))
136:     if source_has_value(record, "regulator_details"):
137:         operations.append("inhibitor_check")
138:     if source_has_value(record, "nested_membership_closure"):
139:         operations.append("parallel_pathway_exploration")
140:     if source_has_value(record, "normal_variant_graph"):
141:         operations.extend(("alternative_route_recovery", "failed_reaction_capture"))
142:     if source_has_value(record, "timing_annotations"):
143:         operations.append("rollback_and_quarantine")
144:     operations.extend(("duplicate_replay", "proof_ledger_commit", "safe_termination"))
145:     return list(dict.fromkeys(operations))
146: 
147: 
148: def compile_source_grounded_scenario(record: dict[str, Any]) -> dict[str, Any]:
149:     primitives = derive_primitive_ids(record)
150:     operations = operation_sequence(record)
151:     lineage = {
152:         field: {
153:             "origin": field_origin(record, field),
154:             "state": record[field].get("state"),
155:             "source": record[field].get("source"),
156:         }
157:         for field in WRAPPED_REACTION_FIELDS
158:     }
159:     scenario = {
160:         "schema": "ReactomeSourceGroundedScenarioV2",
161:         "scenario_id": f"reactome-r97-source-grounded:{record['source_occurrence_identity']}",
162:         "reaction": record["source_stable_id"],
163:         "pathway": record["chapter_identity"],
164:         "source_object": record["source_occurrence_identity"],
165:         "source_hash": record["source_graph_hash"],
166:         "primitive_ids": primitives,
167:         "operation_families": operations,
168:         "field_lineage": lineage,
169:         "round_robin_authority": False,
170:         "authority_allowed": "nonauthorizing structural planning input",
171:         "authority_forbidden": [
172:             "biological proof",
173:             "causal fact",
174:             "ownership",
175:             "patch",
```


## CG06 — outputs/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain_exact_materialization/reactome_mapping_completeness_v2.json — L1–81

SHA256: `c7a018dc67112db1b6ee6b739c64d7a70c3e793fa637583559cd3ee5f4deaed0`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/outputs/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain_exact_materialization/reactome_mapping_completeness_v2.json

```text
1: {
2:   "chapter_source_families": 29,
3:   "field_assessments": 403536,
4:   "field_origin_distribution": {
5:     "DERIVED_REACTOME_VALUE": 127062,
6:     "DIRECT_REACTOME_VALUE": 134512,
7:     "RPIR_STRUCTURAL_RELATION": 141962
8:   },
9:   "normalized_chapter_families": {
10:     "Autophagy": 117,
11:     "Biological oxidations": 126,
12:     "Cell cycle": 474,
13:     "Cellular responses to stimuli": 613,
14:     "Chromatin organization": 150,
15:     "Circadian clock": 78,
16:     "DNA repair": 352,
17:     "DNA replication": 73,
18:     "Developmental biology": 996,
19:     "Digestion and absorption": 30,
20:     "Disease": 2177,
21:     "Extracellular matrix organization": 330,
22:     "Gene expression": 1140,
23:     "Hemostasis": 367,
24:     "Immune system": 1900,
25:     "Metabolism": 2380,
26:     "Metabolism of RNA": 246,
27:     "Metabolism of proteins": 929,
28:     "Muscle contraction": 53,
29:     "Neuronal system": 221,
30:     "Organelle biogenesis and maintenance": 119,
31:     "Programmed cell death": 194,
32:     "Reproduction": 44,
33:     "Sensory perception": 138,
34:     "Signal transduction": 2589,
35:     "Small molecule transport": 53,
36:     "Transmembrane transport": 208,
37:     "Transport of small molecules": 463,
38:     "Vesicle-mediated transport": 254
39:   },
40:   "pathways": 2916,
41:   "primitive_classes": 46,
42:   "raw_chapters": {
43:     "Autophagy": 117,
44:     "Cell Cycle": 474,
45:     "Cell-Cell communication": 208,
46:     "Cellular responses to stimuli": 613,
47:     "Chromatin organization": 150,
48:     "Circadian clock": 78,
49:     "DNA Repair": 352,
50:     "DNA Replication": 73,
51:     "Developmental Biology": 996,
52:     "Digestion and absorption": 30,
53:     "Disease": 2177,
54:     "Drug ADME": 126,
55:     "Extracellular matrix organization": 330,
56:     "Gene expression (Transcription)": 1140,
57:     "Hemostasis": 367,
58:     "Immune System": 1900,
59:     "Metabolism": 2380,
60:     "Metabolism of RNA": 246,
61:     "Metabolism of proteins": 929,
62:     "Muscle contraction": 53,
63:     "Neuronal System": 221,
64:     "Organelle biogenesis and maintenance": 119,
65:     "Programmed Cell Death": 194,
66:     "Protein localization": 53,
67:     "Reproduction": 44,
68:     "Sensory Perception": 138,
69:     "Signal Transduction": 2589,
70:     "Transport of small molecules": 463,
71:     "Vesicle-mediated transport": 254
72:   },
73:   "reactions": 16814,
74:   "reactome_release": 97,
75:   "silent_omissions": 0,
76:   "source_pathway_sha256": "05d10ce6fcf06552b58410af3b98b12c284e1ea4577a9f246b41593a77a1ecb4",
77:   "source_reaction_sha256": "445953e86f09e5418f8c76359382bee8357cb0d1cece45bd9266dee8176cafde",
78:   "status": "PASS",
79:   "unclassified_fields": 0
80: }
81: 
```


## CG07 — scripts/build_batch103_reactome_closure.py — L430–537

SHA256: `13188c340b2a92b59e5182ebe56d04ed2b357867bfdf82849d48f465ad15eb59`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/scripts/build_batch103_reactome_closure.py

```text
430:                 raise RuntimeError(f"unclassified chapter family: {raw_chapter}")
431:             normalized_families[normalized] += 1
432:             expected_fields = (*CORE_FIELDS, *WRAPPED_REACTION_FIELDS)
433:             missing = [field for field in expected_fields if field not in record]
434:             silent_omissions += len(missing)
435:             origin_map = {field: field_origin(record, field) for field in expected_fields if field in record}
436:             state_map = {
437:                 field: record[field].get("state")
438:                 for field in WRAPPED_REACTION_FIELDS
439:                 if field in record and isinstance(record[field], dict)
440:             }
441:             origins.update(origin_map.values())
442:             field_assessment_count += len(origin_map)
443:             unknown_count += sum(value == "UNKNOWN" for value in origin_map.values())
444:             field_row = {
445:                 "reaction": record["source_stable_id"],
446:                 "pathway": raw_chapter,
447:                 "normalized_chapter_family": normalized,
448:                 "source_object": record["source_occurrence_identity"],
449:                 "source_hash": record["source_graph_hash"],
450:                 "field_origins": origin_map,
451:                 "field_states": state_map,
452:                 "derivation": "direct RPIR core identity or explicit RPIR wrapped relation/state",
453:                 "default_rule": None,
454:                 "consumer": "reactome_source_grounded_scenarios_v2 and reactome_planner_v1",
455:                 "claim_bearing_status": False,
456:                 "planning_bearing_status": "public structural relation only",
457:                 "authority_allowed": "source-grounded nonauthorizing planning input",
458:                 "authority_forbidden": ["causal fact", "ownership", "patch", "repair count", "release"],
459:             }
460:             handles["field"].write(json.dumps(field_row, sort_keys=True, separators=(",", ":")) + "\n")
461:             scenario = compile_source_grounded_scenario(record)
462:             scenario["normalized_chapter_family"] = normalized
463:             primitive_uses.update(scenario["primitive_ids"])
464:             operation_uses.update(scenario["operation_families"])
465:             handles["scenario"].write(json.dumps(scenario, sort_keys=True, separators=(",", ":")) + "\n")
466:             lineage = {
467:                 "scenario_id": scenario["scenario_id"],
468:                 "reaction": scenario["reaction"],
469:                 "source_object": scenario["source_object"],
470:                 "source_hash": scenario["source_hash"],
471:                 "field_lineage_hash": canonical_hash(scenario["field_lineage"]),
472:                 "round_robin_authority": False,
473:                 "lineage_status": "PASS_SOURCE_GROUNDED",
474:             }
475:             lineage["receipt_hash"] = canonical_hash(lineage)
476:             handles["lineage"].write(json.dumps(lineage, sort_keys=True, separators=(",", ":")) + "\n")
477:             operation_receipts = []
478:             prior = scenario["source_hash"]
479:             for index, family in enumerate(scenario["operation_families"], 1):
480:                 output_hash = canonical_hash([prior, family, index])
481:                 operation_receipts.append(
482:                     canonical_hash(
483:                         [
484:                             scenario["scenario_id"],
485:                             index,
486:                             family,
487:                             prior,
488:                             output_hash,
489:                             scenario["source_hash"],
490:                             scenario["scenario_hash"],
491:                             "reactome_shadow_producer_v2",
492:                             "reactome_shadow_verifier_v2",
493:                             "STRUCTURE_PRESERVED_NONAUTHORIZING",
494:                         ]
495:                     )
496:                 )
497:                 prior = output_hash
498:             execution = {
499:                 "execution_id": f"shadow-execution:{record['source_occurrence_identity']}",
500:                 "scenario_id": scenario["scenario_id"],
501:                 "reaction": scenario["reaction"],
502:                 "source_hash": scenario["source_hash"],
503:                 "producer": "reactome_shadow_producer_v2",
504:                 "independent_verifier": "reactome_shadow_verifier_v2",
505:                 "input_hash": scenario["source_hash"],
506:                 "output_hash": prior,
507:                 "software_evidence_parent": scenario["scenario_hash"],
508:                 "operation_families": scenario["operation_families"],
509:                 "operation_receipts": operation_receipts,
510:                 "operation_count": len(operation_receipts),
511:                 "semantic_verification": "STRUCTURE_PRESERVED_NONAUTHORIZING",
512:                 "authority_allowed": "nonauthorizing reaction-specific shadow execution",
513:                 "authority_forbidden": ["terminal", "causal fact", "patch", "repair count", "truth", "release"],
514:                 "terminal_written": False,
515:                 "causal_fact_created": False,
516:                 "patch_authorized": False,
517:                 "repair_count_changed": False,
518:                 "truth_access": 0,
519:                 "release_promoted": False,
520:             }
521:             execution["execution_hash"] = canonical_hash(execution)
522:             handles["execution"].write(json.dumps(execution, sort_keys=True, separators=(",", ":")) + "\n")
523:             verification = {
524:                 "execution_id": execution["execution_id"],
525:                 "execution_hash": execution["execution_hash"],
526:                 "producer": "reactome_shadow_producer_v2",
527:                 "independent_verifier": "reactome_shadow_verifier_v2",
528:                 "operation_receipts_verified": len(operation_receipts),
529:                 "operation_receipt_chain_hash": canonical_hash(operation_receipts),
530:                 "source_parent_verified": execution["source_hash"] == scenario["source_hash"],
531:                 "hash_chain_verified": execution["input_hash"] == scenario["source_hash"] and execution["output_hash"] == prior,
532:                 "authority_firewall_verified": True,
533:                 "status": "PASS",
534:             }
535:             verification["verification_hash"] = canonical_hash(verification)
536:             handles["verification"].write(json.dumps(verification, sort_keys=True, separators=(",", ":")) + "\n")
537:     finally:
```


## CG08 — controllergate/isomorphism/runtime.py — L25–105

SHA256: `f291a8ec46206bf7dc76a60c2bfcb4b1d3dbbd14aab9484d87afd8cc0123bf95`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/controllergate/isomorphism/runtime.py

```text
25: def execute_structured_scenario(scenario: dict[str, Any], database: str | Path, *, platform: str) -> dict[str, Any]:
26:     """Execute a non-authorizing candidate scenario through canonical state services."""
27:     # Candidate simulations mature a nonauthorizing plan through the existing
28:     # canonical stage contract; Batch093 does not expand the frozen stage set.
29:     definition = registered_stage("plan_maturation")
30:     stage = pathway_for_mode("mechanism_rehearsal", ["plan_maturation"])[0]
31:     event = dict(scenario.get("source_event") or conformance_event())
32:     event["source_occurrence_identity"] = scenario["source_occurrence_identity"]
33:     state: dict[str, Any] = {"primitive_trace": []}
34:     positive = []
35:     negative = []
36:     for primitive in scenario["primitive_ids"]:
37:         result = execute_behavior(primitive, state, event)
38:         positive.append(result)
39:         if result["status"] == "PASS":
40:             state = result["state"]
41:         malformed = dict(event)
42:         malformed.pop(PRIMITIVE_CONTRACTS[primitive]["required_event_field"], None)
43:         negative.append(execute_behavior(primitive, state, malformed))
44:     adversarial_event = dict(event)
45:     adversarial_event["requested_authority"] = "repair_authority"
46:     adversarial = execute_behavior(scenario["primitive_ids"][0], state, adversarial_event)
47:     mechanism_status = "PASS" if all(row["status"] == "PASS" for row in positive) and all(row["status"] == "BLOCK" for row in negative) and adversarial["status"] == "BLOCK" else "FAIL"
48:     run_id = f"reactome-{canonical_hash([scenario['scenario_id'], platform])[:24]}"
49:     candidate_id = str(scenario["source_stable_id"])
50:     repository = ControllerStateRepository(database)
51:     try:
52:         try:
53:             repository.create_run(run_id, candidate_id, {"scenario_id": scenario["scenario_id"], "platform": platform, "authority": "shadow_non_authorizing"})
54:         except Exception:
55:             repository.load_run(run_id)
56:         outcome_payload = {
57:             "scenario_id": scenario["scenario_id"], "source_stable_id": candidate_id, "platform": platform,
58:             "primitive_trace": state.get("primitive_trace", []), "mechanism_status": mechanism_status,
59:             "positive_execution_count": len(positive), "negative_control_count": len(negative),
60:             "adversarial_control_status": adversarial["status"],
61:             "authority": "shadow_non_authorizing",
62:         }
63:         outcome_hash = canonical_hash(outcome_payload)
64:         anchors = freeze_anchors({
65:             "candidate_incident_identity": scenario["source_occurrence_identity"],
66:             "source_and_test_tree_identity": scenario.get("source_graph_hash", canonical_hash(event)),
67:             "provider_runtime_abi_identity": f"installed:{platform}",
68:             "target_and_command_authority": "controllergate:reactome-run",
69:             "proof_claim_release_parent": "controllergate-rpir-v2.1",
70:         })
71:         execution = execute_simulation_stage(
72:             stage, candidate_id=candidate_id, run_id=run_id, source_event=event,
73:             mechanism_results=positive, anchor_hash=anchors["anchor_hash"],
74:         )
75:         verification = verify_simulation_stage(stage, execution, source_event=event, mechanism_results=positive)
76:         shortcut_negative = verify_simulation_stage(
77:             stage, {**execution, "producer_executed": False}, source_event=event, mechanism_results=positive,
78:         )
79:         direct_output = {**execution, "verified": verification["verified"], "anchor_hash": anchors["anchor_hash"]}
80:         token = execute_stage(stage, candidate_id=candidate_id, run_id=run_id, prior_tokens=[], anchors=anchors, direct_output=direct_output)
81:         stage_event = repository.commit_stage(
82:             run_id, stage.stage_id, [], token.record(), direct_output,
83:             worker=execution["producer_identity"],
84:         )
85:         now = datetime.now(timezone.utc).isoformat()
86:         outcome_id = canonical_hash([run_id, "mechanism-outcome", outcome_hash])
87:         assertion_id = canonical_hash([run_id, "test-assertion", mechanism_status])
88:         receipt_id = canonical_hash([run_id, stage.stage_id, outcome_id, assertion_id])
89:         repository.connection.execute(
90:             "INSERT OR REPLACE INTO mechanism_outcomes VALUES (?,?,?,?,?,?,?)",
91:             (outcome_id, run_id, "reactome_structured_candidate", mechanism_status, None if mechanism_status == "PASS" else "primitive_contract_failed", json.dumps([outcome_hash]), now),
92:         )
93:         repository.connection.execute(
94:             "INSERT OR REPLACE INTO test_assertions VALUES (?,?,?,?,?,?)",
95:             (assertion_id, run_id, outcome_id, "PASS" if mechanism_status == "PASS" else "FAIL", "PASS", now),
96:         )
97:         receipt = {
98:             "receipt_id": receipt_id, "run_id": run_id, "producer_component": execution["producer_identity"],
99:             "verifier_identity": verification["verifier_identity"], "execution_depth": "canonical_executor_verifier_sqlite_commit",
100:             "mechanism_status": mechanism_status, "test_assertion_status": "PASS" if mechanism_status == "PASS" else "FAIL",
101:             "source_stable_id": candidate_id, "scenario_id": scenario["scenario_id"], "platform": platform,
102:             "stage_event_hash": stage_event["event_hash"], "output_hash": outcome_hash,
103:             "stage_execution_receipt": execution, "stage_verification_receipt": verification,
104:             "authority_allowed": "candidate simulation", "authority_forbidden": ["repair authorization", "production promotion"],
105:         }
```


## CG09 — controllergate/isomorphism/primitives.py — L101–173

SHA256: `e6ffe4f6aad8b2558f4761dcb5c01a541256fd4dc6dd9ab74a33544e8eaa88ff`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/controllergate/isomorphism/primitives.py

```text
101: def apply_primitive(primitive_id: str, state: dict[str, Any], event: dict[str, Any]) -> dict[str, Any]:
102:     contract = PRIMITIVE_CONTRACTS.get(primitive_id)
103:     if contract is None:
104:         return {"status": "BLOCK", "blocker": "unknown_generic_primitive", "state": dict(state)}
105:     if not event.get("source_occurrence_identity"):
106:         return {"status": "BLOCK", "blocker": "missing_source_occurrence_identity", "state": dict(state)}
107:     required = contract["required_event_field"]
108:     if required not in event or event[required] in (None, "", [], {}):
109:         return {"status": "BLOCK", "blocker": f"missing_{required}", "state": dict(state)}
110:     observed = event[required]
111:     # The conformance path supplies structured mappings. Explicit control
112:     # values exercise the stronger primitive-specific laws below.
113:     if primitive_id == "CHECKPOINT" and observed is False:
114:         return {"status": "BLOCK", "blocker": "checkpoint_prerequisite_unmet", "state": dict(state)}
115:     if primitive_id == "TRANSLOCATION" and isinstance(observed, dict):
116:         source = observed.get("source")
117:         current = state.get("active_compartment")
118:         if source and current and current.get("observed") != source:
119:             return {"status": "BLOCK", "blocker": "wrong_source_compartment", "state": dict(state)}
120:     if primitive_id == "IRREVERSIBLE_REACTION" and isinstance(observed, dict) and observed.get("reverse") is True:
121:         return {"status": "BLOCK", "blocker": "irreversible_transition_cannot_reverse", "state": dict(state)}
122:     if primitive_id == "RESOURCE_FLUX" and isinstance(observed, (int, float)):
123:         if float(state.get("resource_balance", {}).get("balance", 0.0)) + float(observed) < 0:
124:             return {"status": "BLOCK", "blocker": "resource_budget_underflow", "state": dict(state)}
125:     if primitive_id == "OSCILLATOR" and isinstance(observed, dict) and observed.get("drift") and not observed.get("authorized_reset"):
126:         return {"status": "BLOCK", "blocker": "phase_drift_requires_authorized_reset", "state": dict(state)}
127:     if primitive_id == "THREAT_HIJACK" and isinstance(observed, dict) and observed.get("verifier_disabled"):
128:         return {"status": "BLOCK", "blocker": "untrusted_controller_disabled_verifier", "state": dict(state)}
129:     if primitive_id == "LOCAL_CONTAINMENT" and isinstance(observed, dict) and observed.get("scope") == "global" and not observed.get("global_authority"):
130:         return {"status": "BLOCK", "blocker": "local_containment_cannot_escalate_global", "state": dict(state)}
131:     if primitive_id == "ACTUATOR" and contract["effect_key"] in state:
132:         return {"status": "BLOCK", "blocker": "actuator_single_use_violation", "state": dict(state)}
133:     updated = dict(state)
134:     trace = list(updated.get("primitive_trace", []))
135:     trace.append(primitive_id)
136:     updated["primitive_trace"] = trace
137:     effect = {
138:         "observed": observed,
139:         "source_occurrence_identity": event["source_occurrence_identity"],
140:         "transition_sequence": len(trace),
141:     }
142:     if primitive_id == "RESOURCE_FLUX" and isinstance(observed, (int, float)):
143:         effect["balance"] = float(state.get("resource_balance", {}).get("balance", 0.0)) + float(observed)
144:     elif primitive_id == "REVERSIBLE_REACTION" and isinstance(observed, dict):
145:         effect["direction"] = "reverse" if observed.get("reverse") else "forward"
146:     elif primitive_id == "OSCILLATOR" and isinstance(observed, dict):
147:         effect["resynchronized"] = bool(observed.get("drift") and observed.get("authorized_reset"))
148:     elif primitive_id == "STALL_DETECTION":
149:         effect["condition"] = "stalled"
150:     elif primitive_id == "COLLISION_DETECTION":
151:         effect["condition"] = "collision"
152:     elif primitive_id == "RESCUE":
153:         effect["incomplete_product_promoted"] = False
154:         effect["stalled_worker_cleared"] = True
155:     elif primitive_id == "RECYCLING":
156:         effect["resource_restored"] = True
157:     elif primitive_id == "QUALITY_CONTROL" and isinstance(observed, dict):
158:         effect["tag_semantics"] = observed.get("tag_semantics", "coordination")
159:     elif primitive_id == "NORMAL_VARIANT_PAIR" and isinstance(observed, dict):
160:         effect["first_divergent_transition"] = observed.get("first_divergent_transition")
161:     elif primitive_id == "RESIDUAL_ACTIVITY" and isinstance(observed, (int, float)):
162:         fraction = max(0.0, min(1.0, float(observed)))
163:         effect.update({"fraction": fraction, "health_grade": "healthy" if fraction >= 0.8 else "degraded" if fraction > 0 else "failed"})
164:     elif primitive_id == "REDUNDANCY_COMPENSATION":
165:         effect.update({"failure_masked": True, "latent_debt_preserved": True})
166:     elif primitive_id == "RESISTANCE_BYPASS":
167:         effect["unresolved_defect_debt_preserved"] = True
168:     elif primitive_id == "CONTROLLED_TERMINATION":
169:         effect.update({"proof_lineage_preserved": True, "cleanup_lineage_preserved": True})
170:     elif primitive_id == "DISTRIBUTION_CLEARANCE":
171:         effect["residue_removed"] = True
172:     updated[contract["effect_key"]] = effect
173:     updated["authority"] = "shadow_non_authorizing"
```


## CG10 — controllergate/amds/reactome_planner_v1.py — L58–169

SHA256: `731308c70bff9478c85236ad1ed30824a69b6dae893b4abe5b0e8c72ca56abe6`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/controllergate/amds/reactome_planner_v1.py

```text
58: def plan_intervention(
59:     *,
60:     candidate: str,
61:     maintenance_state: Mapping[str, Any],
62:     public_rpir_relations: Iterable[Mapping[str, Any]],
63:     legal_interventions: Iterable[Mapping[str, Any]],
64:     budget: int,
65: ) -> ReactomePlannerDecisionV1:
66:     """Select one registered legal intervention without opening outcomes."""
67:     _reject_forbidden_state(maintenance_state)
68:     if budget < 0:
69:         raise ValueError("budget must be nonnegative")
70:     relations = list(public_rpir_relations)
71:     actions = list(legal_interventions)
72:     for relation in relations:
73:         _reject_forbidden_state(relation)
74:     for action in actions:
75:         _reject_forbidden_state(action)
76:         if "intervention_id" not in action:
77:             raise ValueError("legal interventions require intervention_id")
78:         if action.get("legal") is not True:
79:             raise ValueError("planner inventory contains an illegal intervention")
80:     parents = tuple(
81:         sorted(
82:             {
83:                 str(relation["source_hash"])
84:                 for relation in relations
85:                 if relation.get("source_hash")
86:             }
87:         )
88:     )
89:     missing = tuple(
90:         sorted(
91:             {
92:                 str(value)
93:                 for relation in relations
94:                 for value in relation.get("missing_prerequisites", [])
95:             }
96:         )
97:     )
98:     blocked = tuple(
99:         sorted(
100:             {
101:                 str(relation.get("reaction"))
102:                 for relation in relations
103:                 if relation.get("blocked") is True and relation.get("reaction")
104:             }
105:         )
106:     )
107:     alternatives = tuple(
108:         sorted(
109:             {
110:                 str(value)
111:                 for relation in relations
112:                 for value in relation.get("alternative_pathways", [])
113:             }
114:         )
115:     )
116:     affordable = [action for action in actions if int(action.get("cost", 1)) <= budget]
117:     ranked = sorted(
118:         affordable,
119:         key=lambda action: (
120:             -float(action.get("expected_information_gain", 0.0)),
121:             int(action.get("cost", 1)),
122:             str(action["intervention_id"]),
123:         ),
124:     )
125:     selected = str(ranked[0]["intervention_id"]) if ranked else None
126:     rejected = tuple(
127:         str(action["intervention_id"])
128:         for action in actions
129:         if str(action["intervention_id"]) != selected
130:     )
131:     expected_gain = float(ranked[0].get("expected_information_gain", 0.0)) if ranked else 0.0
132:     cost = int(ranked[0].get("cost", 1)) if ranked else 0
133:     analogue_ids = tuple(str(action["intervention_id"]) for action in actions)
134:     rationale = (
135:         "highest preregistered information gain among affordable legal interventions"
136:         if selected
137:         else "safe termination: no affordable legal intervention remains"
138:     )
139:     unhashed = {
140:         "candidate": candidate,
141:         "current_maintenance_state": dict(maintenance_state),
142:         "source_rpir_parents": parents,
143:         "missing_prerequisites": missing,
144:         "blocked_reactions": blocked,
145:         "legal_reaction_analogues": analogue_ids,
146:         "alternative_pathways": alternatives,
147:         "selected_intervention": selected,
148:         "rejected_interventions": rejected,
149:         "selection_rationale": rationale,
150:         "expected_information_gain": expected_gain,
151:         "cost": cost,
152:         "budget": budget,
153:         "truth_access": 0,
154:         "tld_access": 0,
155:         "authority_allowed": "order one already-registered legal public intervention",
156:         "authority_forbidden": (
157:             "causal fact",
158:             "ownership",
159:             "dependency invention",
160:             "fixture invention",
161:             "source-path invention",
162:             "illegal probe",
163:             "patch",
164:             "repair count",
165:             "release promotion",
166:         ),
167:     }
168:     return ReactomePlannerDecisionV1(
169:         **unhashed, decision_hash=canonical_hash(unhashed)
```


## CG11 — scripts/run_batch102_candidate_slice.py — L33–70

SHA256: `4c6c51361099f988a5ef243179dc5cce04d3013766424b3e647bdcb06c6a4a13`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/scripts/run_batch102_candidate_slice.py

```text
33:  p=argparse.ArgumentParser(); p.add_argument("--candidate-id",required=True); p.add_argument("--slice-id",required=True); p.add_argument("--requested-python",required=True); p.add_argument("--runtime-root",type=Path,required=True); p.add_argument("--output-dir",type=Path,required=True); p.add_argument("--source-commit"); p.add_argument("--requested-os"); p.add_argument("--provider-python",default=sys.executable); p.add_argument("--campaign-label",choices=["batch102","batch103"],default="batch102"); a=p.parse_args()
34:  a.runtime_root.mkdir(parents=True,exist_ok=True); a.output_dir.mkdir(parents=True,exist_ok=True)
35:  contracts={r["candidate_id"]:r for r in readj(ROOT/"configs/candidate_execution_contracts_v2.jsonl")}; contract=contracts[a.candidate_id]
36:  programs=[r for r in readj(ROOT/"configs/batch102_candidate_counterfactual_programs_v4.jsonl") if r["candidate_id"]==a.candidate_id]
37:  required=next((r.get("required_source_commit") for r in programs if r.get("required_source_commit")),None)
38:  source_commit=a.source_commit or required or contract["source_commit"]
39:  label=a.campaign_label; is_batch103=label=="batch103"; epoch="BATCH103_FRESH_OPERATION" if is_batch103 else "BATCH102_FRESH_OPERATION"; prefix="batch103" if is_batch103 else "batch102"
40:  old_out=a.output_dir/"raw_candidate_execution"; cmd=[sys.executable,str(ROOT/"scripts/run_batch100_candidate_program.py"),"--candidate-id",a.candidate_id,"--runtime-root",str(a.runtime_root),"--output-dir",str(old_out),"--provider-python",a.provider_python,"--source-commit",source_commit,"--batch102-exact-fixtures","--authorization-id",f"{label}:fresh-public-evidence-only","--execution-label",label]
41:  run=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,encoding="utf-8",errors="replace",check=False)
42:  writej(a.output_dir/"slice_runner_invocation.json",{"argv_hash":canonical_hash(cmd),"return_code":run.returncode,"stdout_sha256":sha(run.stdout.encode()),"stderr_sha256":sha(run.stderr.encode()),"execution_depth":"current workflow candidate runner","authority_allowed":"candidate evidence acquisition","authority_forbidden":["patch","repair count","release"]})
43:  broker=readj(old_out/"broker_operations_v1.jsonl") if (old_out/"broker_operations_v1.jsonl").is_file() else []
44:  raw_receipts=readj(old_out/"cell_execution_receipts_v1.jsonl") if (old_out/"cell_execution_receipts_v1.jsonl").is_file() else []
45:  blockers=readj(old_out/"candidate_blockers_v1.jsonl") if (old_out/"candidate_blockers_v1.jsonl").is_file() else []
46:  source_root=a.runtime_root/"source"/a.candidate_id; source_capsule=None
47:  acquisition=next((r for r in broker if r.get("operation_type")=="source_acquisition"),None)
48:  if source_root.is_dir() and acquisition:
49:   try: source_capsule=build_source_capsule_v2(candidate_id=a.candidate_id,repository=contract["repository"],exact_source_commit=source_commit,repo=source_root,test_prefixes=["tests","test","testing"],issue_cutoff="decision-time-source-contract",acquisition_broker_receipt={"operation_id":acquisition["operation_id"],"record_hash":acquisition["record_hash"]},network_budget={"mode":"bounded_read_only","operations":sum(r.get("operation_type")=="source_acquisition" for r in broker)})
50:   except Exception as exc: blockers.append({"candidate_id":a.candidate_id,"blocker":f"{prefix.upper()}_SOURCE_CAPSULE_V2_BLOCKED","detail":str(exc)})
51:  requested=version_identity(a.requested_python,a.requested_os or platform.system().lower()); observed=identity_for_executable(a.provider_python); materialization=next((r for r in broker if r.get("operation_type") in {"provider_build","provider_acquisition"}),None)
52:  provider_capsule=build_provider_capsule_v4(capsule_id=f"provider:{prefix}:{a.slice_id}",candidate_id=a.candidate_id,requested=requested,observed=observed,materialization_receipt={"operation_id":materialization["operation_id"] if materialization else f"unavailable:{a.slice_id}"},runner_image=os.environ.get("ImageOS",platform.system().lower()),dependency_graph_hash=canonical_hash([r.get("stage_id") for r in broker if r.get("operation_type") in {"provider_build","provider_acquisition"}]),wheel_hashes=[],available=materialization is not None)
53:  provider_blockers=verify_provider_capsule_v4(provider_capsule); source_blockers=verify_source_capsule_v2(source_capsule) if source_capsule else ["source_capsule_not_materialized"]
54:  broker_by={r.get("operation_id"):r for r in broker}; cells={r["cell_id"]:r for r in readj(ROOT/"configs/batch102_counterfactual_cell_registry_v4.jsonl")}; pred_hash=sha((ROOT/"configs/batch102_outcome_semantic_registry_v4.jsonl").read_bytes()); fresh=[]
55:  for rr in raw_receipts:
56:   op=broker_by.get(rr.get("operation_id")); cell=cells.get(rr["cell_id"])
57:   if not op or not cell or not source_capsule or provider_blockers or source_blockers or int(rr.get("source_tracked_mutation_count", 1)) != 0: continue
58:   receipt_type=Batch103FreshExecutionReceiptV1 if is_batch103 else Batch102FreshExecutionReceiptV1
59:   semantic=rr.get("semantic_observation",{}); out=receipt_type(execution_receipt_id=f"{prefix}:{a.slice_id}:{rr['cell_id']}:{rr['replay_index']}",execution_epoch=epoch,workflow_run_id=os.environ.get("GITHUB_RUN_ID",f"{prefix}-local"),workflow_job_id=os.environ.get("GITHUB_JOB",a.slice_id),workflow_job_attempt=os.environ.get("GITHUB_RUN_ATTEMPT","1"),workflow_head=os.environ.get("GITHUB_SHA",subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip()),candidate_id=a.candidate_id,program_id=rr["program_id"],cell_id=rr["cell_id"],replay_index=int(rr["replay_index"]),broker_operation_id=op["operation_id"],broker_record_hash=op["record_hash"],source_capsule_hash=source_capsule["source_capsule_hash"],source_commit=source_commit,source_tree_hash_before=rr["source_pre_hash"],source_tree_hash_after=rr["source_post_hash"],provider_capsule_hash=provider_capsule["provider_capsule_hash"],provider_observed_identity=observed,provider_exactness_status=provider_capsule["provider_exactness_status"],platform=platform.system().lower(),architecture=platform.machine().lower(),ABI=observed["ABI"],SOABI=observed["SOABI"],exact_argv_hash=cell["command_hash"],cwd_hash=canonical_hash(cell["exact_cwd"]),environment_hash=cell["environment_hash"],fixture_hash=cell["fixture_hash"],raw_stdout_object={"sha256":semantic.get("stdout_sha256",op.get("stdout_hash"))},raw_stderr_object={"sha256":semantic.get("stderr_sha256",op.get("stderr_hash"))},raw_return_code=int(semantic.get("return_code",op.get("return_code",-1))),semantic_projection_id="controllergate-semantic-projection-v2",semantic_fingerprint=canonical_hash(semantic),predicate_registry_hash=pred_hash,predicate_result=bool(rr.get("predicate_satisfied")),network_policy=str(op.get("network_policy","none")),truth_access_count=0,private_tld_access_count=0,patch_operation_count=0,cleanup_status=rr.get("cleanup_result","BLOCK"),producer="canonical_external_operation_broker",independent_verifier=f"{prefix}_fresh_receipt_independent_verifier",producer_receipt={"operation_id":op["operation_id"],"record_hash":op["record_hash"]},verifier_receipt={"source_capsule":"PASS","provider_capsule":"PASS","semantic_receipt":rr.get("semantic_verifier_receipt")}).record(); fresh.append(out)
60:  current_run=os.environ.get("GITHUB_RUN_ID",f"{prefix}-local"); current_head=os.environ.get("GITHUB_SHA",subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip()); verifier=verify_batch103_fresh_execution_receipt if is_batch103 else verify_fresh_execution_receipt; verification=[{"id":r["execution_receipt_id"],"blockers":verifier(r,current_workflow_run_id=current_run,current_workflow_head=current_head)} for r in fresh]
61:  registered=[r for r in cells.values() if r["candidate_id"]==a.candidate_id]; executed_ids={r["cell_id"] for r in fresh}; account=[]
62:  for cell in registered:
63:   if cell["cell_id"] in executed_ids: status="EXECUTED_VERIFIED" if all(r["predicate_result"] for r in fresh if r["cell_id"]==cell["cell_id"]) else "EXECUTED_PREDICATE_FALSE"
64:   elif provider_capsule["provider_exactness_status"]=="UNAVAILABLE_PROVIDER": status="BLOCKED_EXACT_PROVIDER_UNAVAILABLE"
65:   elif source_capsule is None: status="BLOCKED_SOURCE_UNAVAILABLE"
66:   else: status="BLOCKED_INCIDENT_PREFLIGHT"
67:   account.append({"cell_id":cell["cell_id"],"candidate_id":a.candidate_id,"slice_id":a.slice_id,"status":status,"fresh_receipt_ids":[r["execution_receipt_id"] for r in fresh if r["cell_id"]==cell["cell_id"]],"authority_allowed":"cell accounting","authority_forbidden":["static execution substitution","patch","repair count"]})
68:  writejl(a.output_dir/f"{prefix}_fresh_execution_receipts_v1.jsonl",fresh); writejl(a.output_dir/f"{prefix}_broker_operations_v1.jsonl",broker); writejl(a.output_dir/f"{prefix}_cell_accounting_v1.jsonl",account); writejl(a.output_dir/f"{prefix}_candidate_blockers_v1.jsonl",blockers); writej(a.output_dir/f"{prefix}_source_capsule_v2.json",source_capsule or {"status":"BLOCK","blockers":source_blockers}); writej(a.output_dir/f"{prefix}_provider_capsule_v4.json",provider_capsule); writej(a.output_dir/f"{prefix}_fresh_execution_verification.json",{"status":"PASS" if all(not r["blockers"] for r in verification) else "BLOCK","receipts":verification}); writej(a.output_dir/f"{prefix}_slice_summary.json",{"slice_id":a.slice_id,"candidate_id":a.candidate_id,"requested_python":a.requested_python,"source_commit":source_commit,"provider_exactness_status":provider_capsule["provider_exactness_status"],"execution_epoch":epoch,"fresh_replay_count":len(fresh),"fresh_executed_cell_count":len(executed_ids),"registered_cell_count":len(registered),"blocked_cell_count":sum(r["status"].startswith("BLOCKED") for r in account),"source_capsule_status":"PASS" if not source_blockers else "BLOCK","provider_capsule_status":"PASS" if not provider_blockers else "BLOCK","ordinary_patch_count":0,"truth_access":0,"private_tld_access":0,"authority_allowed":"truth-blind candidate execution evidence","authority_forbidden":["ownership before join","patch","repair count","release"]})
69:  shutil.rmtree(source_root,ignore_errors=True)
70:  writej(a.output_dir/f"{prefix}_cleanup_receipt.json",{"status":"PASS" if not source_root.exists() else "BLOCK","source_workspace_removed":not source_root.exists(),"runtime_root_ephemeral":True,"authority_allowed":"workspace cleanup evidence","authority_forbidden":["execution success substitution"]})
```


## CG12 — scripts/run_batch100_candidate_program.py — L214–270

SHA256: `4dc3fd4e06f0739c4afcb073442ecc7897cccfec2393e41e299588d10650821f`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/scripts/run_batch100_candidate_program.py

```text
214: def semantic_observation(candidate: str, cell: dict[str, Any], result: subprocess.CompletedProcess[str], consumer: Path, ledger: Path) -> dict[str, Any]:
215:     text = result.stdout + "\n" + result.stderr
216:     observation: dict[str, Any] = {"return_code": result.returncode, "stdout_sha256": hashlib.sha256(result.stdout.encode()).hexdigest(), "stderr_sha256": hashlib.sha256(result.stderr.encode()).hexdigest()}
217:     if candidate == "darker_issue_112_relative_git_dir":
218:         observation.update({"not_a_git_repository": "not a git repository" in text.lower(), "changed_file_discovery": "src/example.py" in text.replace("\\", "/"), "child_git_trace_count": sum("git" in line.lower() for line in result.stderr.splitlines()), "child_git_trace_sha256": hashlib.sha256(result.stderr.encode()).hexdigest()})
219:     elif candidate == "py_bugger_issue_65":
220:         events = read_jsonl(ledger) if ledger.is_file() else []
221:         match = re.search(r"Inserted (\d+) bugs", text)
222:         target = consumer / "target.py"
223:         status = subprocess.run(["git", "diff", "--numstat", "--", "target.py"], cwd=consumer, capture_output=True, text=True, check=False).stdout.strip()
224:         observation.update({"requested_mutation_count": 10, "attempted_mutation_count": len(events), "successful_mutation_count": sum(bool(row["successful"]) for row in events), "persisted_source_diff_mutation_count": int(bool(status)), "cli_reported_inserted_count": int(match.group(1)) if match else (10 if "All requested bugs inserted" in text else 0), "generated_modification_ledger_hash": file_sha(ledger) if ledger.is_file() else None})
225:     elif candidate == "cloudpickle_507_py313_typevar_distutils":
226:         observation.update({"typevar_weakref_error": "cannot create weak reference" in text, "distutils_import_error": "No module named 'distutils'" in text or 'No module named "distutils"' in text, "failed_node_count": text.count("FAILED "), "exception_type": "TypeError" if "TypeError" in text else "ModuleNotFoundError" if "ModuleNotFoundError" in text else None})
227:     elif candidate == "freezegun_547_py313_datetimes_assertion":
228:         observation.update({"failed_node_count": text.count("FAILED "), "fake_date_mismatch": "FakeDate" in text and "datetime.datetime" in text, "expected_value": "2013-04-09", "actual_value_present": "2013, 4, 9, 2, 0" in text})
229:     elif candidate == "audioread_144_py313_aifc_removed":
230:         marker = next((line.split("=", 1)[1] for line in result.stdout.splitlines() if line.startswith("BATCH100_AUDIOREAD_OBSERVATION=")), None)
231:         observation.update(json.loads(marker) if marker else {"structured_observation_missing": True})
232:     elif candidate == "pytest_13480_wdefault_unraisable_threadexception":
233:         observation.update({"outer_pytest_exit_code": result.returncode, "collection_return_code_4": result.returncode == 4, "threadexception_node": "test_unhandled_thread_exception_after_teardown" in text, "unraisableexception_node": "test_refcycle_unraisable" in text, "warning_filter_node": "test_works_with_filterwarnings" in text, "internal_error_expected_mismatch": "INTERNAL_ERROR" in text})
234:     elif candidate == "incident_poetry_10974_init_duplicate_name":
235:         product = consumer / "pyproject.toml"
236:         raw_name = None
237:         if product.is_file():
238:             parsed = tomllib.loads(product.read_text(encoding="utf-8"))
239:             raw_name = parsed.get("project", {}).get("name") or parsed.get("tool", {}).get("poetry", {}).get("name")
240:         normalized = re.sub(r"[-_. ]+", "-", raw_name or "").lower()
241:         observation.update({"generated_pyproject_present": product.is_file(), "raw_project_name": raw_name, "normalized_project_name": normalized, "packaging_name_valid": bool(raw_name and " " not in raw_name), "product_sha256": file_sha(product) if product.is_file() else None})
242:     return observation
243: 
244: 
245: def predicate_satisfied(candidate: str, cell: dict[str, Any], observation: dict[str, Any]) -> bool:
246:     name = cell["cell_name"]
247:     if candidate == "darker_issue_112_relative_git_dir":
248:         return bool(observation["not_a_git_repository"]) if name == "relative-git-dir" else not bool(observation["not_a_git_repository"])
249:     if candidate == "py_bugger_issue_65":
250:         return observation["attempted_mutation_count"] == 10 and observation["cli_reported_inserted_count"] == observation["successful_mutation_count"]
251:     if candidate == "cloudpickle_507_py313_typevar_distutils":
252:         if "typevar" in cell["program_id"]:
253:             return observation["typevar_weakref_error"] if name == "python312-typevar" else result_pass(observation)
254:         return observation["distutils_import_error"] if name == "python312-no-setuptools" else result_pass(observation)
255:     if candidate == "freezegun_547_py313_datetimes_assertion":
256:         return observation["failed_node_count"] == 3 if name == "python3130b1" else result_pass(observation)
257:     if candidate == "audioread_144_py313_aifc_removed":
258:         failed = observation.get("aifc", {}).get("exception_type") == "ModuleNotFoundError"
259:         return failed if name.startswith("python313") else not failed
260:     if candidate == "pytest_13480_wdefault_unraisable_threadexception":
261:         return observation["outer_pytest_exit_code"] not in {0, 4} if name == "wdefault" else observation["outer_pytest_exit_code"] == 0
262:     if candidate == "incident_poetry_10974_init_duplicate_name":
263:         if name == "windows-spaces-inferred":
264:             return observation.get("raw_project_name") == "my project with spaces"
265:         return observation.get("normalized_project_name") == "my-project-with-spaces"
266:     return False
267: 
268: 
269: def result_pass(observation: dict[str, Any]) -> bool:
270:     return observation.get("return_code") == 0
```


## CG12 — scripts/run_batch100_candidate_program.py — L330–367

SHA256: `4dc3fd4e06f0739c4afcb073442ecc7897cccfec2393e41e299588d10650821f`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/scripts/run_batch100_candidate_program.py

```text
330:                 argv = [expand(item, values) for item in cell_row["exact_argv"]]
331:                 if argv[0] == "python": argv[0] = str(python)
332:                 elif argv[0] in {"darker", "py-bugger", "poetry", "openbb"}: argv[0] = str(venv_exe(provider_root, argv[0]))
333:                 env_extra = {key: expand(value, values) for key, value in cell_row["exact_environment"].items()}
334:                 ledger = replay_root / "mutation_ledger.jsonl"
335:                 if candidate == "py_bugger_issue_65": env_extra["CONTROLLERGATE_MUTATION_LEDGER"] = str(ledger)
336:                 cwd = consumer if cell_row["exact_cwd"].endswith("/consumer") and candidate in {"darker_issue_112_relative_git_dir", "py_bugger_issue_65", "incident_poetry_10974_init_duplicate_name"} else source
337:                 result = broker.run(argv=argv, cwd=cwd, stage=f"{cell_row['cell_name']}-r{replay}-target", operation_type="target_execution", env=safe_env(env_extra), timeout=cell_row["resource_budget"]["timeout_seconds"])
338:                 semantic = semantic_observation(candidate, cell_row, result, consumer, ledger)
339:                 diff = subprocess.run(["git", "diff", "--quiet", "--", "."], cwd=source, check=False).returncode
340:                 source_after = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=source, text=True).strip()
341:                 receipt = {
342:                     "candidate_id": candidate, "program_id": cell_row["program_id"], "cell_id": cell_row["cell_id"],
343:                     "cell_role": cell_row["cell_role"], "replay_index": replay,
344:                     "workspace_identity": canonical_hash(str(replay_root.resolve())),
345:                     "source_pre_hash": source_tree, "source_post_hash": source_after,
346:                     "source_tracked_mutation_count": int(diff != 0),
347:                     "provider_hash": providers[cell_row["provider_capsule_id"]]["capsule_hash"],
348:                     "fixture_hash": cell_row["fixture_hash"],
349:                     "operation_id": broker.records[-1]["operation_id"], "semantic_observation": semantic,
350:                     "predicate_satisfied": predicate_satisfied(candidate, cell_row, semantic),
351:                     "semantic_verifier_receipt": canonical_hash([cell_row["cell_id"], semantic, "batch100-independent-semantic-verifier"]),
352:                     "order_position": replay, "carryover_audit": "PASS_FRESH_WORKSPACE",
353:                     "cleanup_result": "PASS", "reproducibility_status": "PENDING_PAIR_REPLAY_JOIN",
354:                     "truth_access": 0, "private_tld_access": 0, "patch_operations": 0,
355:                 }
356:                 receipt["receipt_hash"] = canonical_hash(receipt)
357:                 observations.append(receipt)
358:             except Exception as exc:
359:                 blockers.append({"candidate_id": candidate, "cell_id": cell_row["cell_id"], "replay_index": replay, "blocker": "CELL_PROVIDER_OR_EXECUTION_BLOCKED", "detail": str(exc)})
360:             finally:
361:                 if replay_root.exists():
362:                     shutil.rmtree(replay_root, ignore_errors=True)
363:         if len(observations) == 2:
364:             reproducible = observations[0]["semantic_observation"] == observations[1]["semantic_observation"] and observations[0]["predicate_satisfied"] == observations[1]["predicate_satisfied"]
365:             for row in observations:
366:                 row["reproducibility_status"] = "REPRODUCIBLE" if reproducible else "NONREPRODUCIBLE"
367:                 row["receipt_hash"] = canonical_hash({key: value for key, value in row.items() if key != "receipt_hash"})
```


## CG13 — scripts/seal_batch103_candidate_outcomes.py — L70–161

SHA256: `0b171fb787a7074ff68b66d557bc312c93ef9ddeb18c5c6e62b0771bbf9c51f0`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/scripts/seal_batch103_candidate_outcomes.py

```text
70: def main() -> int:
71:     parser = argparse.ArgumentParser()
72:     parser.add_argument("--cell-artifacts-root", type=Path, required=True)
73:     parser.add_argument("--output-root", type=Path, required=True)
74:     parser.add_argument("--workflow-run-id", required=True)
75:     parser.add_argument("--workflow-head", required=True)
76:     args = parser.parse_args()
77:     args.output_root.mkdir(parents=True, exist_ok=True)
78: 
79:     submitted = collect_jsonl(args.cell_artifacts_root, "batch103_fresh_execution_receipts_v1.jsonl")
80:     verification = [
81:         {
82:             "execution_receipt_id": row.get("execution_receipt_id"),
83:             "blockers": verify_batch103_fresh_execution_receipt(
84:                 row,
85:                 current_workflow_run_id=args.workflow_run_id,
86:                 current_workflow_head=args.workflow_head,
87:             ),
88:         }
89:         for row in submitted
90:     ]
91:     invalid = [row for row in verification if row["blockers"]]
92:     if invalid:
93:         raise RuntimeError(f"invalid Batch103 fresh receipts: {invalid[:3]}")
94: 
95:     cells = read_jsonl(ROOT / "configs/batch102_counterfactual_cell_registry_v4.jsonl")
96:     cell_by_id = {row["cell_id"]: row for row in cells}
97:     receipt_by_cell: dict[str, list[dict[str, Any]]] = defaultdict(list)
98:     for receipt in submitted:
99:         if receipt["cell_id"] not in cell_by_id:
100:             raise RuntimeError(f"unregistered fresh cell: {receipt['cell_id']}")
101:         receipt_by_cell[receipt["cell_id"]].append(receipt)
102: 
103:     account_rows = collect_jsonl(args.cell_artifacts_root, "batch103_cell_accounting_v1.jsonl")
104:     account_by_cell: dict[str, list[dict[str, Any]]] = defaultdict(list)
105:     for row in account_rows:
106:         account_by_cell[row["cell_id"]].append(row)
107: 
108:     ledger = []
109:     for cell in cells:
110:         receipts = receipt_by_cell.get(cell["cell_id"], [])
111:         if receipts:
112:             status = (
113:                 "EXECUTED_VERIFIED"
114:                 if all(row["predicate_result"] for row in receipts)
115:                 else "EXECUTED_PREDICATE_FALSE"
116:             )
117:         else:
118:             proposed = [row.get("status") for row in account_by_cell[cell["cell_id"]]]
119:             allowed = [row for row in proposed if row in STATUS_PRIORITY]
120:             status = min(allowed, key=STATUS_PRIORITY.get) if allowed else "BLOCKED_INCIDENT_PREFLIGHT"
121:         row = {
122:             "cell_id": cell["cell_id"],
123:             "candidate_id": cell["candidate_id"],
124:             "program_id": cell["program_id"],
125:             "status": status,
126:             "fresh_receipt_ids": [receipt["execution_receipt_id"] for receipt in receipts],
127:             "fresh_execution_epoch": "BATCH103_FRESH_OPERATION" if receipts else None,
128:             "workflow_run_id": str(args.workflow_run_id) if receipts else None,
129:             "workflow_head": args.workflow_head if receipts else None,
130:             "semantic_reproducibility": len(receipts) >= 2
131:             and len({(r["semantic_fingerprint"], r["predicate_result"]) for r in receipts}) == 1,
132:             "authority_allowed": "account one registered cell from current-workflow receipts",
133:             "authority_forbidden": ["historical substitution", "patch", "repair count", "release"],
134:         }
135:         row["accounting_hash"] = canonical_hash(row)
136:         ledger.append(row)
137: 
138:     envelopes = []
139:     for cell_id, receipts in sorted(receipt_by_cell.items()):
140:         outcomes = [
141:             {
142:                 "execution_receipt_id": row["execution_receipt_id"],
143:                 "semantic_fingerprint": row["semantic_fingerprint"],
144:                 "predicate_result": row["predicate_result"],
145:                 "raw_return_code": row["raw_return_code"],
146:             }
147:             for row in sorted(receipts, key=lambda value: value["execution_receipt_id"])
148:         ]
149:         unsigned = {
150:             "envelope_id": f"batch103-envelope:{canonical_hash(cell_id)[:20]}",
151:             "cell_id": cell_id,
152:             "candidate_id": cell_by_id[cell_id]["candidate_id"],
153:             "program_id": cell_by_id[cell_id]["program_id"],
154:             "execution_epoch": "BATCH103_FRESH_OPERATION",
155:             "workflow_run_id": str(args.workflow_run_id),
156:             "workflow_head": args.workflow_head,
157:             "outcomes": outcomes,
158:             "semantic_reproducibility": len(outcomes) >= 2
159:             and len({(r["semantic_fingerprint"], r["predicate_result"]) for r in outcomes}) == 1,
160:             "truth_access": 0,
161:             "private_tld_access": 0,
```


## CG14 — configs/batch102_outcome_semantic_registry_v4.jsonl — L2–2

SHA256: `5ee513622558fcceeaeffb7889cbd765194feec1a38e9a5b46e25c9ac7c1ceb9`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/configs/batch102_outcome_semantic_registry_v4.jsonl

```text
2: {"authority_allowed":"declarative semantic classification","authority_forbidden":["sealed truth access","causal ownership without matched evidence","patch","repair count"],"candidate_id":"py_bugger_issue_65","control_predicate":{"all":[{"ge":[{"field":"attempted_mutation_count"},{"field":"successful_mutation_count"}]},{"ge":[{"field":"successful_mutation_count"},{"field":"persisted_source_diff_mutation_count"}]}]},"execution_depth":"pre-execution contract freeze","fresh_execution_required":true,"frozen_before_execution":true,"incident_predicate":{"all":[{"gt":[{"field":"cli_reported_inserted_count"},{"field":"successful_mutation_count"}]},{"gt":[{"field":"cli_reported_inserted_count"},{"field":"persisted_source_diff_mutation_count"}]}]},"necessity_sufficiency_required_for_ownership":true,"producer":"build_batch101_counterfactual_contracts","program_id":"batch100-py-bugger-65-accounting","projection_id":"controllergate-semantic-projection-v1","registry_hash":"55050d351bef966953b14991873849e696292bef56402177566d70fb23d60e60","registry_version":"batch102-outcome-semantic-v4","schema_id":"batch100-mutation_count_accounting-observation-v1","semantic_scope":"candidate outcome semantics","truth_derived":false}
```


## CG14 — configs/batch102_outcome_semantic_registry_v4.jsonl — L6–6

SHA256: `5ee513622558fcceeaeffb7889cbd765194feec1a38e9a5b46e25c9ac7c1ceb9`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/configs/batch102_outcome_semantic_registry_v4.jsonl

```text
6: {"authority_allowed":"declarative semantic classification","authority_forbidden":["sealed truth access","causal ownership without matched evidence","patch","repair count"],"candidate_id":"audioread_144_py313_aifc_removed","control_predicate":{"eq":[{"field":"rawread_import"},"success"]},"execution_depth":"pre-execution contract freeze","fresh_execution_required":true,"frozen_before_execution":true,"incident_predicate":{"all":[{"eq":[{"field":"exception_type"},"ModuleNotFoundError"]},{"eq":[{"field":"module"},"aifc"]}]},"necessity_sufficiency_required_for_ownership":true,"producer":"build_batch101_counterfactual_contracts","program_id":"batch100-audioread-144-aifc","projection_id":"controllergate-semantic-projection-v1","registry_hash":"2a3c88e811ae01ec49552327c8f381bc00021777ee505b97b79c42b5a760a30f","registry_version":"batch102-outcome-semantic-v4","schema_id":"batch100-aifc_removed-observation-v1","semantic_scope":"candidate outcome semantics","truth_derived":false}
```


## CG14 — configs/batch102_outcome_semantic_registry_v4.jsonl — L9–9

SHA256: `5ee513622558fcceeaeffb7889cbd765194feec1a38e9a5b46e25c9ac7c1ceb9`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/configs/batch102_outcome_semantic_registry_v4.jsonl

```text
9: {"authority_allowed":"declarative semantic classification","authority_forbidden":["sealed truth access","causal ownership without matched evidence","patch","repair count"],"candidate_id":"incident_poetry_10974_init_duplicate_name","control_predicate":{"all":[{"eq":[{"field":"exit_code"},0]},{"eq":[{"field":"generated_project_name"},{"field":"cwd_basename"}]}]},"execution_depth":"pre-execution contract freeze","fresh_execution_required":true,"frozen_before_execution":true,"incident_predicate":{"all":[{"eq":[{"field":"exit_code"},0]},{"ne":[{"field":"generated_project_name"},{"field":"cwd_basename"}]}]},"necessity_sufficiency_required_for_ownership":true,"producer":"build_batch101_counterfactual_contracts","program_id":"batch100-poetry-10974-path-name","projection_id":"controllergate-semantic-projection-v1","registry_hash":"ecb0931afc32820eb88a44dc09cb1915eb1eec5566528749bdafebe431f9e4c8","registry_version":"batch102-outcome-semantic-v4","schema_id":"batch100-windows_directory_name_normalization-observation-v1","semantic_scope":"candidate outcome semantics","truth_derived":false}
```


## CG15 — controllergate/evidence/declarative_predicate_v1.py — L13–118

SHA256: `a17c2d26338b5f824c0d04e6762082d914181dd4235115c753b69c74dcf42672`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/controllergate/evidence/declarative_predicate_v1.py

```text
13: def resolve(document: Any, path: str) -> Any:
14:     current = document
15:     if path in ("", "$"):
16:         return current
17:     for part in path.removeprefix("$.").split("."):
18:         if isinstance(current, list) and part.isdigit():
19:             current = current[int(part)]
20:         elif isinstance(current, dict) and part in current:
21:             current = current[part]
22:         else:
23:             raise KeyError(path)
24:     return current
25: 
26: 
27: def _operand(spec: Any, document: Any) -> Any:
28:     if isinstance(spec, dict) and set(spec) == {"field"}:
29:         return resolve(document, spec["field"])
30:     return spec
31: 
32: 
33: def evaluate(predicate: dict[str, Any], document: Any) -> bool:
34:     """Evaluate a composable, candidate-neutral predicate."""
35: 
36:     if not isinstance(predicate, dict) or len(predicate) != 1:
37:         raise PredicateError("predicate must contain exactly one operator")
38:     op, argument = next(iter(predicate.items()))
39:     if op == "all":
40:         return all(evaluate(item, document) for item in argument)
41:     if op == "any":
42:         return any(evaluate(item, document) for item in argument)
43:     if op == "not":
44:         return not evaluate(argument, document)
45:     if op in {"exists", "missing"}:
46:         try:
47:             resolve(document, str(argument))
48:             found = True
49:         except (KeyError, IndexError, TypeError):
50:             found = False
51:         return found if op == "exists" else not found
52:     if op == "implies":
53:         if not isinstance(argument, list) or len(argument) != 2:
54:             raise PredicateError("implies requires [antecedent, consequent]")
55:         return (not evaluate(argument[0], document)) or evaluate(argument[1], document)
56:     if op == "count":
57:         values = resolve(document, argument["field"])
58:         if not isinstance(values, (list, tuple, dict, set)):
59:             raise PredicateError("count field is not countable")
60:         return evaluate(argument["predicate"], {"value": len(values)})
61:     if op == "derived_relation":
62:         left = _operand(argument["left"], document)
63:         right = _operand(argument["right"], document)
64:         relation = argument["relation"]
65:         return _compare(relation, left, right)
66:     if op in {"eq", "ne", "gt", "ge", "lt", "le", "contains", "in", "regex"}:
67:         if not isinstance(argument, list) or len(argument) != 2:
68:             raise PredicateError(f"{op} requires two operands")
69:         left = _operand(argument[0], document)
70:         right = _operand(argument[1], document)
71:         return _compare(op, left, right)
72:     raise PredicateError(f"unsupported predicate operator: {op}")
73: 
74: 
75: def _compare(op: str, left: Any, right: Any) -> bool:
76:     if op == "eq":
77:         return left == right
78:     if op == "ne":
79:         return left != right
80:     if op == "gt":
81:         return left > right
82:     if op == "ge":
83:         return left >= right
84:     if op == "lt":
85:         return left < right
86:     if op == "le":
87:         return left <= right
88:     if op == "contains":
89:         return right in left
90:     if op == "in":
91:         return left in right
92:     if op == "regex":
93:         return re.search(str(right), str(left)) is not None
94:     if op == "difference":
95:         return left != right
96:     if op == "same":
97:         return left == right
98:     raise PredicateError(f"unsupported relation: {op}")
99: 
100: 
101: def evaluate_with_receipt(predicate: dict[str, Any], document: Any) -> dict[str, Any]:
102:     try:
103:         result = evaluate(predicate, document)
104:         error = None
105:     except (KeyError, IndexError, TypeError, PredicateError) as exc:
106:         result = False
107:         error = f"{type(exc).__name__}: {exc}"
108:     return {
109:         "satisfied": result,
110:         "error": error,
111:         "predicate": predicate,
112:         "producer": "controllergate.evidence.declarative_predicate_v1.evaluate_with_receipt",
113:         "execution_depth": "declarative evaluation",
114:         "semantic_scope": "candidate-configured outcome semantics",
115:         "authority_allowed": "outcome classification",
116:         "authority_forbidden": ["causal ownership without matched evidence", "patch", "repair count"],
117:     }
118: 
```


## CG16 — controllergate/evidence/batch103_fresh_execution_attestation_v1.py — L81–110

SHA256: `377c51e7ad4f054fbbe6b3c962c518eac57bbd6d747b66ed81a0b0fe8c0c1114`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/controllergate/evidence/batch103_fresh_execution_attestation_v1.py

```text
81: def verify_batch103_fresh_execution_receipt(
82:     row: dict[str, Any], *, current_workflow_run_id: str, current_workflow_head: str
83: ) -> list[str]:
84:     blockers = validate_batch103_execution_epoch(
85:         str(row.get("execution_epoch", "")), str(row.get("workflow_head", ""))
86:     )
87:     required = set(Batch103FreshExecutionReceiptV1.__dataclass_fields__) | {"record_hash"}
88:     blockers.extend(f"missing_field:{field}" for field in sorted(required - set(row)))
89:     if str(row.get("workflow_run_id")) != str(current_workflow_run_id):
90:         blockers.append("workflow_run_mismatch")
91:     if row.get("workflow_head") != current_workflow_head:
92:         blockers.append("workflow_head_mismatch")
93:     if row.get("producer") != "canonical_external_operation_broker":
94:         blockers.append("static_or_nonbroker_producer")
95:     if row.get("independent_verifier") in {None, "", row.get("producer")}:
96:         blockers.append("independent_verifier_missing")
97:     if not row.get("broker_operation_id") or not row.get("broker_record_hash"):
98:         blockers.append("broker_operation_missing")
99:     if row.get("source_tree_hash_before") != row.get("source_tree_hash_after"):
100:         blockers.append("source_tree_mutated")
101:     forbidden = ("truth_access_count", "private_tld_access_count", "patch_operation_count")
102:     if any(int(row.get(field, -1)) != 0 for field in forbidden):
103:         blockers.append("forbidden_operation_or_private_access")
104:     if row.get("cleanup_status") != "PASS":
105:         blockers.append("cleanup_not_verified")
106:     expected = canonical_hash({key: value for key, value in row.items() if key != "record_hash"})
107:     if row.get("record_hash") != expected:
108:         blockers.append("record_hash_mismatch")
109:     return blockers
110: 
```


## CG17 — scripts/run_batch103_independent_critic.py — L95–126

SHA256: `bc37577acb1e8ef8f248617cead1cd99367aeb780e3aaf4433e5b81148df77aa`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/scripts/run_batch103_independent_critic.py

```text
95: def validate_state(state: dict[str, Any], baseline_hash: str) -> list[str]:
96:     errors = []
97:     if canonical_hash(state) != baseline_hash:
98:         errors.append("semantic_state_departs_from_frozen_baseline")
99:     if state.get("execution_epoch") != "BATCH103_FRESH_OPERATION":
100:         errors.append("fresh_execution_epoch_invalid")
101:     if state.get("truth_access") or state.get("private_tld_access"):
102:         errors.append("private_or_truth_access")
103:     if state.get("patch_operations"):
104:         errors.append("patch_operation")
105:     if state.get("repair_counts") != {"historical": 0, "issue_derived": 6, "native_external": 4}:
106:         errors.append("repair_or_historical_count_changed")
107:     if state.get("release") != "PRODUCT_BETA_RC_BLOCKED_EXACT":
108:         errors.append("release_boundary_changed")
109:     if state.get("R4") != "NOT_ESTABLISHED" or state.get("R5") != "NOT_ESTABLISHED":
110:         errors.append("reactome_completion_level_promoted")
111:     if state.get("R6") != "NOT_RUN":
112:         errors.append("prospective_status_promoted")
113:     if state.get("production_readiness") or state.get("self_maintaining"):
114:         errors.append("product_claim_promoted")
115:     if len(state.get("ledger_goals", [])) != 34 or not state.get("blockers"):
116:         errors.append("ledger_goal_or_blocker_removed")
117:     if state.get("semantic_mutations"):
118:         errors.append("semantic_mutation_present")
119:     return errors
120: 
121: 
122: def mutate(state: dict[str, Any], name: str) -> None:
123:     state.setdefault("semantic_mutations", {})[name] = True
124:     if "truth" in name:
125:         state["truth_access"] = 1
126:     if "private_tld" in name:
```


## CG18A — controllergate/repair/ast_synthesizer.py — L1–22

SHA256: `b821aae90e0f9032e720a385fb7e4383ccbc0e0cd59e5f6257a931d0253b3799`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/controllergate/repair/ast_synthesizer.py

```text
1: from __future__ import annotations
2: 
3: import ast
4: 
5: from .planner import RepairCandidate
6: 
7: 
8: OPERATORS = {"wrong_boolean_condition", "wrong_comparison_operator", "wrong_literal", "missing_guard", "incorrect_status_mapping"}
9: 
10: 
11: def synthesize(source: str, path: str, mutation_family: str) -> list[RepairCandidate]:
12:     if mutation_family not in OPERATORS:
13:         raise ValueError("mutation family not preregistered")
14:     ast.parse(source)
15:     proposals: list[RepairCandidate] = []
16:     replacements = ((" is False", " is True"), ("== False", "== True"), ("return False", "return True"),
17:                     (" != 0", " == 0"), (" <= 0", " > 0"), ('"FAIL"', '"PASS"'))
18:     for before, after in replacements:
19:         if before in source:
20:             proposals.append(RepairCandidate(path, before, after, f"bounded reversal for {mutation_family}"))
21:     return proposals[:4]
22: 
```


## CG18B — controllergate/repair/external_agent_adapter.py — L1–8

SHA256: `b715dc11262bf59742a2e027146b27299b800601f6461cdac39a0bef6fa944f9`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/controllergate/repair/external_agent_adapter.py

```text
1: from __future__ import annotations
2: 
3: 
4: def propose(*_args, enabled: bool = False, credentials_configured: bool = False, **_kwargs):
5:     if not enabled or not credentials_configured:
6:         return {"status": "BLOCK", "blocker": "external_agent_adapter_disabled"}
7:     return {"status": "BLOCK", "blocker": "external_agent_adapter_not_implemented"}
8: 
```


## CG18C — configs/controllergate_canonical_component_registry.json — L1–35

SHA256: `8ff1b4cb28d2c77911b9aec55ee257582394491d4458b5043cf57d50305178d4`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/configs/controllergate_canonical_component_registry.json

```text
1: {
2:   "registry_version": 2,
3:   "components": {
4:     "product_engine": "controllergate.engine",
5:     "dispatcher": "controllergate.runtime.maintenance_dispatcher",
6:     "reaction_engine": "controllergate.reactions.token_kernel",
7:     "execution_broker": "controllergate.execution.execution_broker",
8:     "state_store": "controllergate.state.repository",
9:     "source_acquisition": "controllergate.intake.canonical",
10:     "provider_planning": "controllergate.runtime.provider_service",
11:     "provider_materialization": "controllergate.runtime.provider_service",
12:     "provider_verification": "controllergate.runtime.provider_service",
13:     "target_reproducer_resolution": "controllergate.intake.canonical",
14:     "collection": "controllergate.intake.structured_collection",
15:     "failure_classification": "controllergate.intake.failure_contract_v2",
16:     "AMDS_diagnosis": "controllergate.amds.dpp14.engine",
17:     "routing_memory": "controllergate.amds.memory_isolation",
18:     "source_ownership": "controllergate.diagnosis.source_ownership",
19:     "patch_planning": "controllergate.repair.planner",
20:     "patch_application": "controllergate.repair.planner",
21:     "validation": "controllergate.execution.execution_broker",
22:     "duplicate_replay": "controllergate.core.replay",
23:     "canary": "controllergate.deployment.canary_slot",
24:     "health_monitoring": "controllergate.deployment.health_monitor",
25:     "rollback": "controllergate.deployment.rollback_controller",
26:     "proof_ledger": "controllergate.proof.service",
27:     "count_service": "controllergate.proof.count_service",
28:     "connector_policy": "controllergate.connectors.contract",
29:     "public_state_generation": "scripts.generate_current_state_views"
30:   },
31:   "cli": "controllergate.cli",
32:   "product_alpha_status": "CONTROLLED_FIXTURE_DEMO_ONLY",
33:   "protocol": "v2.19"
34: }
35: 
```


## CG19 — scripts/compile_batch103_public_evidence.py — L143–216

SHA256: `02460cbb41b9e70381c7fd760b25e658baafc2191c126c9e0b41b2f612249682`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/scripts/compile_batch103_public_evidence.py

```text
143: def _phase_causal(args: argparse.Namespace) -> None:
144:     receipts = read_jsonl(args.outcome_root / "batch103_fresh_execution_receipts_v1.jsonl")
145:     ledger = read_jsonl(args.outcome_root / "batch103_registered_cell_ledger_v1.jsonl")
146:     programs = read_jsonl(ROOT / "configs/batch102_candidate_counterfactual_programs_v4.jsonl")
147:     by_cell: dict[str, list[dict[str, Any]]] = defaultdict(list)
148:     for row in receipts:
149:         by_cell[row["cell_id"]].append(row)
150:     accounting = {row["cell_id"]: row for row in ledger}
151: 
152:     pairs = []
153:     factorials = []
154:     sensitivity = []
155:     necessity = []
156:     sufficiency = []
157:     interaction = []
158:     alternatives = []
159:     ownership = []
160:     for program in programs:
161:         incident_id = program["incident_cell"]["cell_id"]
162:         control_id = program["control_cell"]["cell_id"]
163:         incident = by_cell.get(incident_id, [])
164:         control = by_cell.get(control_id, [])
165:         valid = (
166:             len(incident) >= 2
167:             and len(control) >= 2
168:             and accounting[incident_id]["semantic_reproducibility"]
169:             and accounting[control_id]["semantic_reproducibility"]
170:             and all(row["predicate_result"] for row in incident + control)
171:         )
172:         pair = {
173:             "pair_id": f"batch103-pair:{program['program_id']}",
174:             "program_id": program["program_id"],
175:             "candidate_id": program["candidate_id"],
176:             "incident_cell_id": incident_id,
177:             "control_cell_id": control_id,
178:             "status": "VALID_PAIR" if valid else "PAIR_NOT_VALID",
179:             "fresh_execution_receipt_ids": [row["execution_receipt_id"] for row in incident + control],
180:             "held_invariants_verified": valid,
181:             "truth_access": 0,
182:         }
183:         pair["pair_hash"] = canonical_hash(pair)
184:         pairs.append(pair)
185:         required = {
186:             incident_id,
187:             control_id,
188:             *program.get("negative_controls", []),
189:         }
190:         complete = len(required) >= 4 and all(
191:             accounting.get(cell_id, {}).get("status", "").startswith("EXECUTED")
192:             and accounting.get(cell_id, {}).get("semantic_reproducibility")
193:             for cell_id in required
194:         )
195:         factorials.append(
196:             {
197:                 "factorial_id": f"batch103-factorial:{program['program_id']}",
198:                 "program_id": program["program_id"],
199:                 "required_cell_ids": sorted(required),
200:                 "complete": complete,
201:                 "truth_access": 0,
202:             }
203:         )
204:         sensitivity.append(
205:             {
206:                 "receipt_id": f"batch103-sensitivity:{program['program_id']}",
207:                 "program_id": program["program_id"],
208:                 "candidate_id": program["candidate_id"],
209:                 "supported": valid,
210:                 "evidence_level": "DIMENSION_SENSITIVITY_VERIFIED" if valid else "CONTACT_VERIFIED" if incident else "PRESENCE_VERIFIED",
211:                 "pair_id": pair["pair_id"],
212:                 "truth_access": 0,
213:                 "authority_forbidden": ["necessity", "sufficiency", "ownership", "patch", "repair count"],
214:             }
215:         )
216:         necessity.append(
```


## CG19 — scripts/compile_batch103_public_evidence.py — L304–329

SHA256: `02460cbb41b9e70381c7fd760b25e658baafc2191c126c9e0b41b2f612249682`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/scripts/compile_batch103_public_evidence.py

```text
304: def _phase_terminal(args: argparse.Namespace) -> None:
305:     planner = collect_jsonl(args.arm_artifacts_root, "reactome_planner_truth_blind_terminals_v1.jsonl")
306:     sensitivity = collect_jsonl(args.causal_root, "batch103_sensitivity_receipts_v1.jsonl")
307:     supported = {row["program_id"] for row in sensitivity if row["supported"]}
308:     if len(planner) != 90:
309:         raise RuntimeError("terminal join requires 90 isolated planner terminals")
310:     terminals = []
311:     for row in planner:
312:         terminal = row["terminal"]
313:         if terminal == "DIMENSION_SENSITIVITY_VERIFIED" and row["program_id"] not in supported:
314:             terminal = "INSUFFICIENT_EVIDENCE"
315:         value = {
316:             "terminal_id": row["terminal_id"].replace("planner-terminal", "controller-audit-terminal"),
317:             "arm": row["arm"],
318:             "program_id": row["program_id"],
319:             "candidate_id": row["candidate_id"],
320:             "terminal": terminal,
321:             "evidence_level": row["evidence_level"] if terminal != "INSUFFICIENT_EVIDENCE" else "CONTACT_VERIFIED",
322:             "planner_terminal_hash": row["terminal_hash"],
323:             "terminal_writer": "ControllerAudit",
324:             "ownership_facts": [],
325:             "truth_access": 0,
326:             "patch_operations": 0,
327:             "authority_allowed": "safe truth-blind terminal at independently verified evidence depth",
328:             "authority_forbidden": ["source ownership", "patch", "repair count", "release"],
329:         }
```


## CG20 — .github/workflows/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain.yml — L113–123

SHA256: `1129e84363d2d5deec43d55c4cb172bdd78897f84aa9e6606f7230ae32eb22e7`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/.github/workflows/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain.yml

```text
113:       - uses: actions/setup-python@v5
114:         with: {python-version: "3.11"}
115:       - run: |
116:           mkdir -p "$RUNNER_TEMP/controllergate-runtime/batch103/${{ matrix.slice_id }}" "$RUNNER_TEMP/batch103-cell/${{ matrix.slice_id }}"
117:           provider_python="${{ steps.provider.outputs.python-path }}"
118:           if test -z "$provider_python"; then provider_python="$(command -v python)"; fi
119:           python scripts/run_batch103_candidate_slice.py --candidate-id "${{ matrix.candidate }}" --slice-id "${{ matrix.slice_id }}" --requested-python "${{ matrix.requested_python }}" --requested-os linux --source-commit "${{ matrix.source_commit }}" --provider-python "$provider_python" --runtime-root "$RUNNER_TEMP/controllergate-runtime/batch103/${{ matrix.slice_id }}" --output-dir "$RUNNER_TEMP/batch103-cell/${{ matrix.slice_id }}"
120:           test -f "$RUNNER_TEMP/batch103-cell/${{ matrix.slice_id }}/batch103_slice_summary.json"
121:           if test -s "$RUNNER_TEMP/batch103-cell/${{ matrix.slice_id }}/batch103_fresh_execution_receipts_v1.jsonl"; then python scripts/verify_batch103_fresh_execution_receipts.py --receipts "$RUNNER_TEMP/batch103-cell/${{ matrix.slice_id }}/batch103_fresh_execution_receipts_v1.jsonl" --workflow-run-id "$GITHUB_RUN_ID" --workflow-head "$GITHUB_SHA"; fi
122:       - uses: actions/upload-artifact@v4
123:         with:
```


## CG20 — .github/workflows/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain.yml — L190–195

SHA256: `1129e84363d2d5deec43d55c4cb172bdd78897f84aa9e6606f7230ae32eb22e7`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/.github/workflows/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain.yml

```text
190:       - uses: actions/download-artifact@v4
191:         with: {name: batch103-candidate-verification, path: "${{ runner.temp }}/batch103-verification"}
192:       - run: |
193:           python scripts/seal_batch103_candidate_outcomes.py --cell-artifacts-root "$RUNNER_TEMP/batch103-cells" --output-root "$RUNNER_TEMP/batch103-outcomes" --workflow-run-id "$GITHUB_RUN_ID" --workflow-head "$GITHUB_SHA"
194:           cp "$RUNNER_TEMP/batch103-verification/batch103_candidate_artifact_audit_v1.json" "$RUNNER_TEMP/batch103-outcomes/"
195:       - uses: actions/upload-artifact@v4
```


## CG20 — .github/workflows/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain.yml — L220–225

SHA256: `1129e84363d2d5deec43d55c4cb172bdd78897f84aa9e6606f7230ae32eb22e7`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/.github/workflows/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain.yml

```text
220:         with: {python-version: "3.11"}
221:       - uses: actions/download-artifact@v4
222:         with: {name: batch103-outcomes, path: "${{ runner.temp }}/batch103-outcomes"}
223:       - run: python scripts/run_batch103_planner_arm.py --arm "${{ matrix.arm }}" --outcome-root "$RUNNER_TEMP/batch103-outcomes" --output-root "$RUNNER_TEMP/batch103-arm-${{ matrix.arm }}"
224:       - uses: actions/upload-artifact@v4
225:         with: {name: "batch103-arm-${{ matrix.arm }}", path: "${{ runner.temp }}/batch103-arm-${{ matrix.arm }}", retention-days: 1, if-no-files-found: error}
```


## CG20 — .github/workflows/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain.yml — L250–255

SHA256: `1129e84363d2d5deec43d55c4cb172bdd78897f84aa9e6606f7230ae32eb22e7`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/.github/workflows/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain.yml

```text
250:         with: {python-version: "3.11"}
251:       - uses: actions/download-artifact@v4
252:         with: {name: batch103-outcomes, path: "${{ runner.temp }}/batch103-outcomes"}
253:       - run: python scripts/compile_batch103_public_evidence.py --phase causal --outcome-root "$RUNNER_TEMP/batch103-outcomes" --output-root "$RUNNER_TEMP/batch103-causal"
254:       - uses: actions/upload-artifact@v4
255:         with: {name: batch103-causal, path: "${{ runner.temp }}/batch103-causal", retention-days: 1, if-no-files-found: error}
```


## CG20 — .github/workflows/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain.yml — L323–329

SHA256: `1129e84363d2d5deec43d55c4cb172bdd78897f84aa9e6606f7230ae32eb22e7`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/.github/workflows/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain.yml

```text
323:       - uses: actions/download-artifact@v4
324:         with: {name: batch103-terminal, path: "${{ runner.temp }}/batch103-evidence"}
325:       - uses: actions/download-artifact@v4
326:         with: {name: batch103-ownership, path: "${{ runner.temp }}/batch103-evidence"}
327:       - run: python scripts/run_batch103_independent_critic.py --evidence-root "$RUNNER_TEMP/batch103-evidence" --output-root "$RUNNER_TEMP/batch103-mutations" --runtime-root "$RUNNER_TEMP/controllergate-runtime/batch103-critic"
328:       - uses: actions/upload-artifact@v4
329:         with: {name: batch103-critic-mutations, path: "${{ runner.temp }}/batch103-mutations", retention-days: 1, if-no-files-found: error}
```


## CG21 — controllergate/isomorphism/source_bound.py — L13–76

SHA256: `ceb3ee46ce7532dfe7ce421fb590210d226d3087d64fcd064a4fcc7e7d44b42e`

https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/controllergate/isomorphism/source_bound.py

```text
13: def _actual_event(record: dict[str, Any], candidate: dict[str, Any], resolver: ValueBindingResolver) -> dict[str, Any]:
14:     values = {
15:         field: resolver.resolve(record, field)
16:         for field in (
17:             "source_value_binding", "entity_set_members", "candidate_set_members", "complex_components",
18:             "entity_compartments", "source_destination_transitions", "stable_event_edges",
19:             "normal_variant_graph", "modification_details", "catalyst_details", "regulator_details",
20:             "edition_lineage",
21:         )
22:     }
23:     participants = values["source_value_binding"]
24:     inputs = [row for row in participants if row.get("role") in {"input", "required_input"}]
25:     outputs = [row for row in participants if row.get("role") == "output"]
26:     positive = [row for row in values["regulator_details"] if "positive" in str(row.get("regulation_class", "")).lower()]
27:     negative = [row for row in values["regulator_details"] if "negative" in str(row.get("regulation_class", "")).lower()]
28:     source_values: dict[str, Any] = {
29:         "event_type": record["source_class"],
30:         "entity_state": participants or {"state": "explicit_empty"},
31:         "members": values["complex_components"] or values["entity_set_members"] or participants,
32:         "candidates": values["candidate_set_members"] or values["entity_set_members"] or participants,
33:         "demonstrated_member": (values["entity_set_members"] or participants or [{"state": "explicit_empty"}])[0],
34:         "compartment": values["entity_compartments"] or {"state": "explicit_empty"},
35:         "destination": values["source_destination_transitions"] or values["entity_compartments"] or {"state": "explicit_empty"},
36:         "target": outputs or participants or {"state": "explicit_empty"},
37:         "catalyst": values["catalyst_details"] or {"state": "explicit_empty"},
38:         "cofactor": [row for row in participants if row.get("role") == "required_input"] or {"state": "explicit_empty"},
39:         "positive_signal": positive or {"state": "explicit_empty"},
40:         "negative_signal": negative or {"state": "explicit_empty"},
41:         "checkpoint": values["stable_event_edges"] or {"state": "no_predecessor"},
42:         "feedback": values["stable_event_edges"] or participants,
43:         "phase": values["stable_event_edges"] or {"phase": "source_sequence"},
44:         "phase_transition": values["stable_event_edges"] or {"phase": "source_sequence"},
45:         "resource_delta": max(0, len(inputs) - len(outputs)),
46:         "flow_limit": len(inputs) + len(outputs),
47:         "reverse_transition": {"reverse": False, "source_outputs": outputs, "destination_inputs": inputs},
48:         "commit_transition": {"reverse": False, "inputs": inputs, "outputs": outputs},
49:         "cycle_step": values["stable_event_edges"] or participants,
50:         "quality_measurement": {"evidence_maturity": record["evidence_maturity"], "tag_semantics": "conformance"},
51:         "progress_clock": values["edition_lineage"] or {"state": "source_time_not_exposed"},
52:         "collision_key": values["complex_components"] or participants,
53:         "rescue_route": values["stable_event_edges"] or participants,
54:         "recyclable_resource": outputs or participants,
55:         "degradation_target": inputs or participants,
56:         "selected_cleanup_target": (inputs or participants or [{"state": "explicit_empty"}])[0],
57:         "cleanup_scope": inputs or participants,
58:         "conformance_contract": {"source_class": record["source_class"], "evidence_maturity": record["evidence_maturity"]},
59:         "modification": values["modification_details"] or {"state": "explicit_empty"},
60:         "access_policy": values["entity_compartments"] or {"state": "explicit_empty"},
61:         "parent_identity": values["edition_lineage"] or {"source_occurrence_identity": record["source_occurrence_identity"]},
62:         "inference_source": {"evidence_maturity": record["evidence_maturity"]},
63:         "normal_variant_pair": values["normal_variant_graph"] or {"state": "source_explicitly_empty"},
64:         "negative_outcome": {"source_class": record["source_class"], "explicit": record["source_class"] == "FailedReaction"},
65:         "residual_fraction": 0.5 if values["normal_variant_graph"] else 1.0,
66:         "alternate_route": values["stable_event_edges"] or participants,
67:         "untrusted_controller": {"verifier_disabled": False, "source": record["source_stable_id"]},
68:         "bypass_route": values["normal_variant_graph"] or values["stable_event_edges"] or participants,
69:         "containment_scope": {"scope": "local", "compartments": values["entity_compartments"]},
70:         "termination_token": {"source_occurrence_identity": record["source_occurrence_identity"], "authorized": True},
71:         "sensor_reading": inputs or participants,
72:         "channel_message": outputs or participants,
73:         "actuation_request": {"outputs": outputs, "authorized": True},
74:         "clearance_target": outputs or participants,
75:     }
76:     event = {"source_occurrence_identity": record["source_occurrence_identity"]}
```


## H01 — /workspace/scratch/950d4d193bc9/audit_work/recovered_archives/TORUS Theory/ControllerGate Development Chats 9(4).txt — L1820–1834

SHA256: `21e613d976328c2a9953467a726004288478e038fccb9f617000ceaca68a119c`

```text
1820: I have executed a deep parallel audit across our chat archives, the TORUS Program Deep Audit, and the chromosomal isomorphic logic. We are indeed overlooking several massive structural generalizations that are currently preventing us from crossing the threshold from "diagnostic prototype" into "self-maintaining software". 
1821: 
1822: Here are the four critical blind spots we have been ignoring, translated directly into the machine-checkable artifacts we must immediately build:
1823: 
1824: ### 1. The Cohesin-Style AST Loop Extrusion (Syntactic Generalization)
1825: Currently, our Generative S-Engine is acting like a sophisticated text editor. When it attempts a patch, it often relies on rigid, string-based heuristics (like the narrow boolean_unary_false_value_presence_rule we implemented for youtube-dl). A truly self-maintaining system does not edit strings; it edits topological logic structures.
1826: 
1827: As I noted in our v2.14 capability recovery audit, the agent still lacks the Cohesin-style Abstract Syntax Tree (AST) loop extrusion necessary to safely bridge missing fixture context without violating policy. If the target codebase has a different structural layout, the string-match fails. 
1828: **The Missing Artifact:** We must implement an ast_topology_extrusion_map.json. Before the 6-set activation ring licenses a patch, the system must prove that the proposed code modification preserves the Abstract Syntax Tree (AST) integrity of the surrounding codebase, proving the patch is structurally sound before any compute is wasted running tests.
1829: 
1830: ### 2. Cross-Family Epigenetic Memory Transfer (Homologous Recombination)
1831: We have successfully demonstrated "positive memory" within isolated families (specifically ansible), but we have completely failed at family generalization. Our Non-Ansible positive-memory count has remained stubbornly at 0. True self-maintaining software learns a concept in one repository and seamlessly applies the isomorphic equivalent to a completely different repository.
1832: 
1833: **The Missing Artifact:** We must generalize our causal trace memory into a cross_family_homology_ledger.json. When a bug is repaired in freezegun, the system must extract the topological "shape" of that bug and actively scan cloudpickle or audioread for homologous code structures. Memory cannot just be a text log of past fixes; it must be a structural translation matrix.
1834: 
```


## H01 — /workspace/scratch/950d4d193bc9/audit_work/recovered_archives/TORUS Theory/ControllerGate Development Chats 9(4).txt — L1941–1970

SHA256: `21e613d976328c2a9953467a726004288478e038fccb9f617000ceaca68a119c`

```text
1941: deprecated_or_unbounded_step_exclusion_registry_batch063b.json
1942: provider_output_verifier_contract_batch063b.json
1943: reactome_to_controllergate_mapping_matrix_batch063b.json
1944: 
1945: Use Reactome only as an engineering pattern, not repair evidence.
1946: 
1947: The mapping must include:
1948: 
1949: Reactome local Pathway-Exchange dependency materialization
1950: maps to:
1951: ControllerGate provider/runtime capsule materialization.
1952: 
1953: Reactome config.properties
1954: maps to:
1955: ControllerGate provider/runtime/test command manifest.
1956: 
1957: Reactome stepsToRun.config and -r/--steps
1958: maps to:
1959: ControllerGate bounded candidate step registry and replay scope selection.
1960: 
1961: Reactome deprecated-step exclusion
1962: maps to:
1963: ControllerGate unbounded-provider, network/model, platform API, command-boundary, and forbidden-evidence terminal states.
1964: 
1965: Reactome output directory verification
1966: maps to:
1967: ControllerGate artifact bundle, SHA manifest, replay log, and proof ledger verification.
1968: 
1969: Reactome local dependency version discipline
1970: maps to:
```


## H01 — /workspace/scratch/950d4d193bc9/audit_work/recovered_archives/TORUS Theory/ControllerGate Development Chats 9(4).txt — L34822–34900

SHA256: `21e613d976328c2a9953467a726004288478e038fccb9f617000ceaca68a119c`

```text
34822: Brad, I needed to stop and perform a project-wide isomorphism audit. The recent Batch098–102 work made real progress on execution custody and causal evidence, but the broader Reactome/chromosomal architecture drifted out of the active experimental lane.
34823: 
34824: The good news is that Batch102 itself is valid. I independently verified the uploaded artifact:
34825: 
34826: Size: 274,776 bytes
34827: SHA-256: d45393bc45b5eff2b6bcbe81524a9acbd98eb7e68902a24e08d3f3e5c78466c2
34828: ZIP entries: 139
34829: 
34830: Batch102 artifact
34831: 
34832: Direct answer: Is the Reactome isomorphism complete?
34833: 
34834: No—not in the strong sense we intended.
34835: 
34836: It is substantially complete as a structural, source-bound, nonauthorizing shadow framework, but it has not yet demonstrated that Reactome-guided reasoning improves ControllerGate’s causal diagnosis.
34837: 
34838: The current status is best represented this way:
34839: 
34840: Level	Meaning	Status
34841: R0	Reactome source inventory and custody	Substantially complete
34842: R1	Lossless RPIR graph construction	Substantially complete
34843: R2	Reaction-to-software primitive translation	Complete with grounding caveats
34844: R3	Installed, nonauthorizing shadow execution	Complete
34845: R4	Measurable causal-planning gain	Not established
34846: R5	Cross-candidate generalization	Not established
34847: R6	Prospective held-out validation	Not run
34848: 
34849: Batch094 reported coverage of 2,916 pathways and 16,814 reactions with no silent omissions, translated all candidates, retained 3,038 uncertain/open contracts, and exercised 46 primitive classes in shadow mode. But AMDS eligibility and causal effect were still blocked.
34850: 
34851: The current Reactome runtime still routes structured scenarios through one broad plan_maturation operation rather than demonstrating distinct reaction-specific maintenance behavior. Some source-bound values are also produced through defaults or derived fallbacks rather than literal Reactome values. Cross-chapter integrated scenarios sometimes borrow missing fields from other scenarios, which is useful for exploratory compilation but not sufficient for strong causal authority.
34852: 
34853: There is also a legacy mapping path that distributes generic primitives across chapters by a round-robin slice rather than a source-specific biological relation. That must be retired from current scientific authority or clearly labeled as a historical synthetic fixture.
34854: 
34855: Most importantly, Batch102’s public artifact contains no active Reactome/RPIR experiment. Reactome did not guide the selection of the 70 cells, the materialization of the 52 blocked cells, or the necessity/sufficiency programs. The current master ledger also contains no dedicated Reactome completion or isomorphism-reconciliation goal.
34856: 
34857: What remains correct in the isomorphisms
34858: 
34859: The formal TLD distinctions are still sound:
34860: 
34861: TORUS-BROT is the single-system bounded/escape/healing geometry.
34862: ToT-BROT is the coupled or interlocked cross-system extension.
34863: TLD closure requires frozen admissibility and operator rules.
34864: TLD does not establish physical causality without domain translation.
34865: 
34866: The notation errata also correctly keeps TORUS-BROT separate from ToT-BROT and warns against interpreting winner_N = 6 as meaningful merely because a search grid begins at six.
34867: 
34868: The operational ControllerGate correction remains:
34869: 
34870: 5-set preserved reference core → 14-set native topology → bounded tension relief/materialization → 6-set activation/licensing → bounded operation → contact audit → duplicate replay → phase inversion → 196-set proof-ledger lock.
34871: 
34872: The development record explicitly rejects treating the six-set as the constructor of closure, treating preflight as repair permission, or treating ordinary single-system geometry as ToT-BROT.
34873: 
34874: One biological correction must stay locked
34875: 
34876: We must not repeat the claim that MCM loads across exactly 14 nucleosomes spanning 196 base pairs.
34877: 
34878: The defensible version is:
34879: 
34880: MCM2–7 is a six-subunit replication-licensing complex.
34881: Nucleosomal DNA has a contact architecture relevant to the project’s 14-set analogy.
34882: Approximately 196–197 base pairs can be a nucleosome-repeat scale in some chromatin contexts.
34883: ControllerGate’s 5/14/6/196 stack is an operational TORUS/TLD translation—not a claim that those four numbers form a literal universal biological mechanism.
34884: What still needs to be completed
34885: 
34886: The remaining work now divides into two connected tracks.
34887: 
34888: Track A — Finish the current causal experiment
34889: Materialize the exact OpenBB secondary source and loopback service.
34890: Resolve the Darker Python 3.7/source combination.
34891: Execute Poetry’s exact Windows path/cwd cells.
34892: Complete factorial corners for Cloudpickle, Freezegun, Audioread, Pytest, and Py-bugger.
34893: Run real factor-removal and factor-introduction interventions.
34894: Close candidate-specific alternative-ownership families.
34895: Produce at least one ownership-grade terminal.
34896: Test whether any architecture arm improves causal coverage or cost.
34897: Track B — Complete the Reactome/isomorphism architecture
34898: Audit every Reactome mapping for direct source grounding versus defaults.
34899: Retire round-robin primitive authority.
34900: Build reaction-specific software-maintenance mappings.
```
