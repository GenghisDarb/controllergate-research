# ControllerGate / Reactome history and current implementation audit

## Main finding

The recovered evidence does **not** establish that incomplete Reactome biology caused ControllerGate's failures. The project deliberately translates selected biological relations into software-maintenance contracts; it is not running a faithful simulation of a crowded living cell. Several demonstrated failures concern exact software providers, missing counterfactual cells, measurement semantics, replay definitions and the integration of later repairs. Those are direct, testable causes.

The latest source also supports a constructive answer: substantial infrastructure and some typed state behavior exist, so this need not be a restart. A concrete fresh-path integration defect was recovered and a locally tested repair candidate now accompanies this audit. Its fixture success is not a new biological result or a revised historical causal-gain score.

## Current-source check

Read-only GitHub retrieval on 23 November 2026 found one branch, `controllergate-v1.7-alpha-real-trace-pilot`, at `38897b79588f3ff4b1b9002eedc299a9bcf05140`. The latest commit is dated 20 July 2026 and records the corrected Batch103 handoff. The releases collection is empty. This checks the connected repository, not Brad's live PC or other unobserved copies.

The 49 selected source files are 537,171 bytes; every local file matches the Git blob SHA returned by the connector. The five key semantic-path files were also checked at execution HEAD `3aa1a749be0a1e13bd735623c812335af9795f76` and have identical bytes. The current Actions artifacts listing for run `29753821142` is empty; no fresh raw-vault replay was possible from that listing. Official outcome counts below are recorded results inspected in the current handoff/completion documents, not newly executed providers.

## What is implemented

**The current 5/14/6/196 stack is an engineering translation.** It keeps a five-part reference core, bounded fourteen-slot contact ledger, materialization/tension relief, six-part licensing, bounded action, post-action audit, duplicate replay, return constraint and 14×14 proof ledger. Missing and non-applicable contact slots remain explicit. Current errata reject exact loading across fourteen nucleosomes, an exact universal 196-base-pair mechanism, and the inference that six gates create closure. See CG03–CG04 in the excerpt ledger.

**Reactome relations are represented explicitly.** The source-grounded compiler recognizes wrapped source-value states for entity/candidate sets, complex membership, compartments, catalysts, regulators, variants, failed reactions, event ordering, stoichiometry, timing and lineage. Relations determine primitive IDs and operation families. It does not assign primitives by chapter position on this path; the older round-robin mapping is retired from scientific authority. Recorded coverage is 2,916 pathway occurrences, 16,814 reaction occurrences, 46 primitive classes and 29 indexing families. These are coverage counts, not independent biological experiments. CG02, CG05 and CG06.

**There are two different execution scopes that must not be conflated.**

1. The retained typed simulation runtime actually applies primitives, tests missing required fields and forbidden authority, and records simulation stages in SQLite. Some primitives implement real software-state rules: resource balance and underflow, source-compartment checks, irreversible transition checks, one-use actuators and authorized phase reset. This is positive implementation evidence. It remains a bounded software simulation through the generic `plan_maturation` stage, not a cellular dynamics model. CG08–CG09.
2. The specifically inspected **Batch103 source-grounded R3 generator** creates a hash chain over operation-family labels and emits lineage/verification receipts in that same generator. It proves deterministic source-linked bookkeeping and an explicit nonauthorizing boundary on that path. It does not execute an acquisition, consume a measured resource, or independently validate a reaction-state trajectory merely by adding the label to the chain. CG07. The audit does not generalize this narrow limitation to all code in the repository.

**The current planner is bounded and source-linked, but its selection rule is limited.** It collects missing prerequisites, blocked reactions and alternative pathways into a decision record. Actual ranking sorts already-legal, affordable actions by supplied expected-information-gain score, cost and identifier. Those relation fields do not themselves enter the ranking key. Its action inventory and scores therefore matter more than the biological labels alone. CG10. The separate bridge experiment tests an explicitly declared conditional policy against competent controls; it does not silently redefine the historical planner.

**The inspected repair modules are modest.** The AST synthesizer parses Python but proposes a small list of string replacements; the external-agent adapter returns disabled/not-implemented. This does not mean Codex or other external assistants never produced repairs. The current canonical component registry describes the product alpha as `CONTROLLED_FIXTURE_DEMO_ONLY`; the latest handoff retains six issue-derived and four native external repairs, with zero historical repairs. Batch103 itself prohibited patches and counted no new repair. CG18A–CG18C and the current handoff.

## Later repairs are real, but their integration needs checking

| Stage | Genuine correction or result | What still did not follow |
|---|---|---|
| Earlier Reactome release engineering | Explicit dependency, provider, output and step contracts; source custody instead of invented dependencies | A biological analogy did not itself demonstrate repair effectiveness |
| Batches 092–094 | Structured RPIR, typed primitives, explicit missing/source-format states, source-linked shadow execution | Full causal-planning gain or biological completeness |
| Batch099 | Reclassified 504 admissions as contact evidence; all 432 apparent contradictions were false mutual exclusions caused by equating contact with ownership | No ownership facts or nonbaseline causal coverage |
| Batch100 | Eight immutable source-capsule identities, thirteen provider-capsule identities and nine candidate programs | Exact-provider/counterfactual coverage remained incomplete; repeated official runs gave 15 and 16 reproducible cells |
| Batch101 | Corrected declarative predicates and semantic projection; bounded Py-bugger sensitivity on inherited raw evidence | These were re-projections of Batch100 operations, not fresh Batch101 target execution or ownership proof |
| Batch102 | Required current-workflow execution receipts and separated inherited execution from fresh operations | Necessity/sufficiency/exclusion and ownership remained unestablished |
| Batch103 | Retired current round-robin authority and defaults/fallbacks as claim evidence; froze ten equal-budget arms and 90 program/arm plans; recorded 15/70 freshly executed cells | 55 cells remained unmaterialized; R4/R5 gain was not established and R6 was not run |
| This audit | Traced the actual fresh path and recovered a disconnected semantic repair; supplied a reviewed local integration candidate | No remote installation, provider rerun, new causal ownership result or biological validation |

In the recorded Batch103 post-artifact truth join, A–I each had 1/6 coverage, zero causal accuracy and one false attribution; J abstained on all six scoreable cases. Reactome arms B–F contributed five false attributions in aggregate. The 90 public terminals comprised 72 insufficient-evidence, nine dimension-sensitivity and nine safe-abstention terminals. These correlated arm outcomes are not nine independent demonstrations about biology. No candidate improved the preregistered public metric; unsafe authority and leakage remained zero. Current R4 and R5 are `NOT_ESTABLISHED`, R6 `NOT_RUN`. CG01–CG02.

## New direct failure mechanism: the newer semantic registry is not the evaluator on the fresh path

The exact current chain is:

1. The Batch103 workflow calls `run_batch103_candidate_slice.py`, which delegates to the Batch102 slice.
2. The Batch102 slice calls `run_batch100_candidate_program.py`.
3. The Batch100 runner computes a candidate-specific predicate and stores the complete semantic observation, including raw output digests.
4. The Batch102 slice copies that legacy boolean, hashes the entire observation and labels the receipt with the newer predicate-registry digest/projection ID.
5. The Batch103 seal compares those fingerprints and booleans. The planner and public causal compiler consume them.
6. The fresh attestation verifier checks origin/custody/hash fields, not a recomputed predicate. The inspected Batch103 mutation critic checks a baseline state digest and mutation flags; it is not a raw-observation re-evaluator.

This is why the existence of a corrected declarative module and a v4 registry is insufficient evidence that the later fresh pipeline uses it. The Py-bugger legacy equality test contradicts the v4 inflation test. Missing Audioread structured data can satisfy the old control predicate. These are concrete software-semantic issues, not evidence that the Reactome database omitted an essential cellular pathway. CG11–CG17. The source-path finding was independently checked by the bridge reviewer.

## Implemented local advance and its honest limit

The repair candidate evaluates the exact frozen v4 predicate, binds its input/output identities, keeps unresolved data explicit, and re-verifies the binding at both fresh-wrapper and seal boundaries. A separately declared projection compares all operand fields and fixed software invariants while retaining raw custody. A concrete four-file integration diff and full review copies are included. Both the source snapshots and historical outputs remain unchanged.

Final local validation is **33 methods passing**, including execution of the inserted wrapper/seal helpers and checks that they are called on the patched main paths. An independent reviewer reproduced the checks and rejected forged/re-signed booleans and insufficient replay objects. Fixture records have source-derived shapes with synthetic values. The data-schema mismatch for nested Audioread and Poetry fields remains unresolved pending an explicit adapter; no alias was invented. The candidate does not authenticate distinct real provider executions or establish causal gain.

## Concrete next research opportunity

The strongest next step is a small fully materialized software incident/control experiment with reviewed raw-to-observable semantics, complete declared interventions, equal budgets and a competent non-Reactome baseline. Measure correct causal discrimination, unresolved fraction, false attribution and acquisition cost. Retain a label-permutation control to test whether structural relations, rather than nomenclature, do useful work.

A later biology experiment would require an independently specified observation map, cell/context/time information, perturbation protocol, uncertainty model and held-out predictions. A Reactome relation can guide a hypothesis; it cannot supply unmeasured concentrations, rates, cellular context or an absent intervention. Nothing recovered here selects fourteen as a unique physical layer count or establishes a cell model from a software analogy.

## Evidence files

`SOURCE_MANIFEST.json` pins every recovered current-source file. `SOURCE_EXCERPTS.json` and `SOURCE_EXCERPTS.md` provide exact source ranges; `R3_CAPABILITY_AUDIT.json`, `SEMANTIC_PATH_AUDIT.json` and `CHRONOLOGY.json` provide machine-readable findings. `remote_inventory.json` and `remote_execution_check.json` record the fresh branch/artifact checks. The local candidate is under `repair_candidate/`; its final verification is `results_v2/verification.json`. No live-PC or Command Center status is asserted.
