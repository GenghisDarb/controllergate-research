"""Proposed fresh-wrapper/seal integration. No external execution is performed here."""
from __future__ import annotations
import copy
import hashlib
import json
from typing import Any
import registry_bound_semantics as semantics

PINNED_REGISTRY_SHA256 = "5ee513622558fcceeaeffb7889cbd765194feec1a38e9a5b46e25c9ac7c1ceb9"
SEMANTIC_VERSION = "fresh-registry-binding-local-candidate-v1"


def record_hash(value: dict[str, Any]) -> str:
    # Match the existing fresh-receipt canonicalization, including ASCII escaping.
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"),
                                    allow_nan=False).encode()).hexdigest()


def context_from_receipt(row: dict[str, Any]) -> dict[str, Any]:
    return {key: row.get(key) for key in semantics.CONTEXT_FIELDS}


def bind_fresh_receipt(row: dict[str, Any], observation: dict[str, Any],
                       cell: dict[str, Any], registry_bytes: bytes) -> dict[str, Any]:
    for key in ("cell_id", "candidate_id", "program_id"):
        if key not in cell or row.get(key) != cell[key]:
            raise ValueError("fresh_cell_contract_mismatch:" + key)
    result = semantics.evaluate_bound_outcome(registry_bytes,
        expected_registry_sha256=PINNED_REGISTRY_SHA256,
        candidate_id=cell["candidate_id"], program_id=cell["program_id"],
        role=cell.get("cell_role", "UNDECLARED"), observation=observation,
        context=context_from_receipt(row))
    out = copy.deepcopy(row)
    out.update(
        semantic_contract_version=SEMANTIC_VERSION,
        legacy_predicate_result_diagnostic=row.get("predicate_result"),
        legacy_semantic_fingerprint_diagnostic=row.get("semantic_fingerprint"),
        raw_semantic_observation=copy.deepcopy(observation),
        bound_outcome_receipt=result, semantic_status=result["status"],
        predicate_result=result["satisfied"],
        predicate_registry_hash=result["registry_sha256"],
        semantic_projection_id=result["projection_id"],
        semantic_fingerprint=result["semantic_projection_hash"],
    )
    out["record_hash"] = record_hash({k: v for k, v in out.items() if k != "record_hash"})
    return out


def verify_fresh_semantics(row: dict[str, Any], cell: dict[str, Any],
                           registry_bytes: bytes) -> list[str]:
    errors = []
    try:
        if row.get("record_hash") != record_hash({k: v for k, v in row.items() if k != "record_hash"}):
            errors.append("outer_record_hash_mismatch")
        if row.get("semantic_contract_version") != SEMANTIC_VERSION:
            errors.append("bound_semantic_contract_missing")
        if any(row.get(key) != cell.get(key) or key not in cell for key in ("cell_id", "candidate_id", "program_id")):
            errors.append("fresh_cell_contract_mismatch")
        bound = row.get("bound_outcome_receipt")
        raw = row.get("raw_semantic_observation")
        if not isinstance(bound, dict) or not isinstance(raw, dict):
            return errors + ["raw_observation_or_binding_missing"]
        check = semantics.verify_bound_receipt(bound, registry_bytes,
            expected_registry_sha256=PINNED_REGISTRY_SHA256,
            candidate_id=cell.get("candidate_id", ""), program_id=cell.get("program_id", ""),
            role=cell.get("cell_role", "UNDECLARED"), observation=raw,
            context=context_from_receipt(row))
        if not check["receipt_matches_recomputation"]:
            errors.append("predicate_or_projection_not_reproduced")
        linked = {"semantic_status": bound.get("status"), "predicate_result": bound.get("satisfied"),
                  "predicate_registry_hash": bound.get("registry_sha256"),
                  "semantic_projection_id": bound.get("projection_id"),
                  "semantic_fingerprint": bound.get("semantic_projection_hash")}
        actual = {key: row.get(key) for key in linked}
        if semantics.canonical_hash(actual) != semantics.canonical_hash(linked):
            errors.append("outer_semantic_fields_disagree")
    except (ValueError, TypeError, KeyError) as exc:
        errors.append("semantic_verification_error:" + type(exc).__name__)
    return errors


def cell_status_after_verification(rows: list[dict[str, Any]]) -> str:
    if not rows or any(row.get("semantic_status") != "EVALUATED" for row in rows):
        return "EXECUTED_SEMANTICS_UNRESOLVED"
    return "EXECUTED_VERIFIED" if all(row.get("predicate_result") is True for row in rows) else "EXECUTED_PREDICATE_FALSE"


def semantic_pair_consistent(rows: list[dict[str, Any]], cell: dict[str, Any],
                             registry_bytes: bytes) -> bool:
    if len(rows) < 2 or any(verify_fresh_semantics(row, cell, registry_bytes) for row in rows):
        return False
    first = rows[0]
    for other in rows[1:]:
        comparison = semantics.compare_scoped_replay(
            first["bound_outcome_receipt"], other["bound_outcome_receipt"],
            registry_bytes=registry_bytes, expected_registry_sha256=PINNED_REGISTRY_SHA256,
            candidate_id=cell["candidate_id"], program_id=cell["program_id"],
            role=cell.get("cell_role", "UNDECLARED"),
            left_observation=first["raw_semantic_observation"],
            right_observation=other["raw_semantic_observation"],
            left_context=context_from_receipt(first), right_context=context_from_receipt(other))
        if comparison["status"] != "SAME_DECLARED_OUTCOME":
            return False
    return True
