"""Focused regressions using source-shaped synthetic observations, not provider reruns."""
from __future__ import annotations
import ast
import copy
import hashlib
import json
from pathlib import Path
import unittest

import registry_bound_semantics as r

HERE = Path(__file__).resolve().parent
REGISTRY = (HERE / "predicate_registry_v4.jsonl").read_bytes()
DIGEST = hashlib.sha256(REGISTRY).hexdigest()
CANDIDATE = "py_bugger_issue_65"
PROGRAM = "batch100-py-bugger-65-accounting"
CONTEXT = {key: "fixture:" + key for key in r.CONTEXT_FIELDS}
INFLATED = {
    "requested_mutation_count": 10, "attempted_mutation_count": 62,
    "successful_mutation_count": 7, "persisted_source_diff_mutation_count": 1,
    "cli_reported_inserted_count": 10, "return_code": 0,
    "stdout_sha256": "a" * 64, "stderr_sha256": "b" * 64,
}


def outcome(observation=None, *, role="incident", context=None, registry=REGISTRY,
            digest=DIGEST, candidate=CANDIDATE, program=PROGRAM):
    return r.evaluate_bound_outcome(registry, expected_registry_sha256=digest,
        candidate_id=candidate, program_id=program, role=role,
        observation=copy.deepcopy(INFLATED if observation is None else observation),
        context=copy.deepcopy(CONTEXT if context is None else context))


def verified(receipt, observation=None, *, role="incident", context=None,
             registry=REGISTRY, digest=DIGEST, candidate=CANDIDATE, program=PROGRAM):
    return r.verify_bound_receipt(receipt, registry, expected_registry_sha256=digest,
        candidate_id=candidate, program_id=program, role=role,
        observation=copy.deepcopy(INFLATED if observation is None else observation),
        context=copy.deepcopy(CONTEXT if context is None else context))


def legacy_predicate():
    tree = ast.parse((HERE / "legacy_predicate_excerpt.py").read_text())
    namespace = {}
    exec(compile(tree, "archived-legacy-predicate", "exec"), namespace)
    return namespace["predicate_satisfied"]


def replay(left, right, *, right_observation=None, right_context=None):
    return r.compare_scoped_replay(left, right, registry_bytes=REGISTRY,
        expected_registry_sha256=DIGEST, candidate_id=CANDIDATE, program_id=PROGRAM,
        role="incident", left_observation=INFLATED,
        right_observation=INFLATED if right_observation is None else right_observation,
        left_context=CONTEXT, right_context=CONTEXT if right_context is None else right_context)


class RepairTests(unittest.TestCase):
    def test_count_inflation_corrected_registry_true_legacy_false(self):
        self.assertFalse(legacy_predicate()(CANDIDATE, {"cell_name": "incident"}, INFLATED))
        got = outcome()
        self.assertEqual(got["status"], "EVALUATED")
        self.assertIs(got["satisfied"], True)
        self.assertEqual(verified(got)["status"], "VERIFIED_OUTCOME_ONLY")

    def test_legitimate_noninflated_incident_is_false_not_unresolved(self):
        obs = dict(INFLATED, attempted_mutation_count=10, cli_reported_inserted_count=7)
        self.assertTrue(legacy_predicate()(CANDIDATE, {"cell_name": "incident"}, obs))
        got = outcome(obs)
        self.assertEqual(got["verdict"], "NOT_SATISFIED")
        self.assertEqual(verified(got, obs)["status"], "VERIFIED_OUTCOME_ONLY")

    def test_legitimate_accounting_control_passes(self):
        got = outcome(role="control")
        self.assertIs(got["satisfied"], True)
        self.assertEqual(verified(got, role="control")["status"], "VERIFIED_OUTCOME_ONLY")

    def test_missing_operand_unresolved(self):
        obs = dict(INFLATED)
        del obs["successful_mutation_count"]
        got = outcome(obs)
        self.assertEqual(got["status"], "UNRESOLVED")
        self.assertIsNone(got["satisfied"])
        self.assertIn("unobserved_operand", got["unresolved_reason"])

    def test_missing_audioread_is_not_control_success(self):
        candidate = "audioread_144_py313_aifc_removed"
        program = "batch100-audioread-144-aifc"
        obs = {"structured_observation_missing": True, "return_code": 1}
        self.assertTrue(legacy_predicate()(candidate, {"cell_name": "python312-control"}, obs))
        got = outcome(obs, candidate=candidate, program=program, role="control")
        self.assertEqual(got["verdict"], "UNRESOLVED")

    def test_observed_audioread_negative_differs_from_missing(self):
        obs = {"exception_type": None, "module": "aifc", "rawread_import": "failed"}
        got = outcome(obs, candidate="audioread_144_py313_aifc_removed",
                      program="batch100-audioread-144-aifc", role="control")
        self.assertEqual(got["verdict"], "NOT_SATISFIED")

    def test_nested_audioread_shape_not_silently_aliased(self):
        obs = {"aifc": {"exception_type": "ModuleNotFoundError"}, "return_code": 0}
        got = outcome(obs, candidate="audioread_144_py313_aifc_removed",
                      program="batch100-audioread-144-aifc")
        self.assertEqual(got["status"], "UNRESOLVED")

    def test_poetry_legacy_names_require_explicit_schema_adapter(self):
        obs = {"return_code": 0, "raw_project_name": "my project with spaces",
               "normalized_project_name": "my-project-with-spaces", "generated_pyproject_present": True}
        got = outcome(obs, candidate="incident_poetry_10974_init_duplicate_name",
                      program="batch100-poetry-10974-path-name")
        self.assertEqual(got["status"], "UNRESOLVED")

    def test_volatile_raw_bytes_differ_but_declared_projection_agrees(self):
        obs = dict(INFLATED, stdout_sha256="c" * 64, stderr_sha256="d" * 64,
                   duration=39.2, timestamp="synthetic-later-time")
        a, b = outcome(), outcome(obs)
        self.assertNotEqual(a["raw_observation_hash"], b["raw_observation_hash"])
        self.assertNotEqual(INFLATED, obs)  # historical whole-dictionary rule rejects
        got = replay(a, b, right_observation=obs)
        self.assertEqual(got["status"], "SAME_DECLARED_OUTCOME")
        self.assertFalse(got["raw_custody_equal"])

    def test_same_verdict_changed_measurement_not_same_projection(self):
        obs = dict(INFLATED, attempted_mutation_count=63)
        got = replay(outcome(), outcome(obs), right_observation=obs)
        self.assertEqual(got["status"], "DIFFERENT_DECLARED_OUTCOME")

    def test_changed_provider_or_source_or_command_detected(self):
        for key in ("provider_capsule_hash", "source_commit", "exact_argv_hash"):
            with self.subTest(key=key):
                other = dict(CONTEXT, **{key: "changed"})
                self.assertEqual(replay(outcome(), outcome(context=other), right_context=other)["status"], "DIFFERENT_DECLARED_OUTCOME")

    def test_missing_replay_invariant_unresolved(self):
        context = dict(CONTEXT)
        del context["fixture_hash"]
        self.assertEqual(outcome(context=context)["status"], "UNRESOLVED")

    def test_boolean_and_nonfinite_numeric_measurements_do_not_pass(self):
        for value in (True, float("nan"), float("inf"), "7"):
            with self.subTest(value=str(value)):
                got = outcome(dict(INFLATED, successful_mutation_count=value))
                self.assertEqual(got["status"], "UNRESOLVED")
                self.assertIsNone(got["satisfied"])

    def test_role_contract_must_exist(self):
        self.assertEqual(outcome(role="factorial_corner")["status"], "UNRESOLVED")

    def test_registry_bytes_must_match_external_anchor(self):
        got = outcome(registry=REGISTRY + b"\n")
        self.assertEqual(got["unresolved_reason"], "registry_digest_mismatch")

    def test_ambiguous_duplicate_registry_entry_unresolved(self):
        row = next(line for line in REGISTRY.splitlines() if b'"candidate_id":"py_bugger_issue_65"' in line)
        registry = REGISTRY + row + b"\n"
        got = outcome(registry=registry, digest=hashlib.sha256(registry).hexdigest())
        self.assertEqual(got["unresolved_reason"], "registry_entry_not_unique:2")

    def test_forged_resigned_predicate_result_rejected(self):
        got = outcome()
        got.update(satisfied=False, verdict="NOT_SATISFIED")
        got["record_hash"] = r.canonical_hash({k: v for k, v in got.items() if k != "record_hash"})
        self.assertEqual(verified(got)["status"], "REJECTED")

    def test_changed_observation_rejected_by_independent_verifier(self):
        self.assertEqual(verified(outcome(), dict(INFLATED, successful_mutation_count=10))["status"], "REJECTED")

    def test_receipt_cannot_change_expected_role(self):
        self.assertEqual(verified(outcome(role="control"), role="incident")["status"], "REJECTED")

    def test_unknown_role_cannot_be_made_positive_by_receipt_hash(self):
        got = outcome(role="unknown")
        self.assertFalse(verified(got, role="unknown")["classification_established"])

    def test_receipt_exposes_no_causal_or_patch_authority(self):
        got = outcome()
        self.assertIn("causal ownership", got["authority_forbidden"])
        self.assertFalse(verified(got)["causal_or_patch_authority"])

    def test_boolean_to_integer_receipt_mutation_is_rejected(self):
        got = outcome()
        got["satisfied"] = 1
        self.assertEqual(verified(got)["status"], "REJECTED")
        got["record_hash"] = r.canonical_hash({k: v for k, v in got.items() if k != "record_hash"})
        self.assertEqual(verified(got)["status"], "REJECTED")

    def test_minimal_positive_looking_dicts_cannot_pass_replay(self):
        fake = {"status": "EVALUATED", "raw_observation_hash": "x"}
        self.assertEqual(replay(fake, fake)["status"], "UNRESOLVED")


if __name__ == "__main__":
    unittest.main()
