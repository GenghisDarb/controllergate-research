"""Create a reviewable patch against inspected source; never modify the source snapshot."""
from pathlib import Path
import difflib
import hashlib
import json

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / "source"
OUT = HERE / "integration_candidate"


def one(text, old, new):
    if text.count(old) != 1:
        raise RuntimeError("integration anchor not unique: " + old[:100])
    return text.replace(old, new, 1)


def main():
    outputs = {}
    anchors = {}
    for path, blob in {
        "scripts/run_batch102_candidate_slice.py": "502d7ea67af7af22a10f576e0017b876561f713a",
        "scripts/seal_batch103_candidate_outcomes.py": "f766e037b814ee3dd502fbc6d1a33d4d0e0170be",
    }.items():
        data = (SOURCE / path).read_bytes()
        actual = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if actual != blob:
            raise RuntimeError("inspected source anchor changed: " + path)
        anchors[path] = {"git_blob_sha": blob, "sha256": hashlib.sha256(data).hexdigest()}

    path = "scripts/run_batch102_candidate_slice.py"
    text = (SOURCE / path).read_text()
    text = one(text, "def main()->int:",
        "from controllergate.evidence.registry_bound_semantic_seam_candidate import (bind_fresh_receipt, verify_fresh_semantics, cell_status_after_verification)\n\n"
        "def bind_current_semantics(out, semantic, cell, registry_bytes):\n"
        "    return bind_fresh_receipt(out, semantic, cell, registry_bytes)\n\n"
        "def verify_current_fresh_semantics(row, cell, registry_bytes):\n"
        "    return verify_fresh_semantics(row, cell, registry_bytes)\n\n"
        "def current_cell_status(rows, verification):\n"
        "    checks = {item['id']: item.get('blockers') for item in verification}\n"
        "    if any(not isinstance(checks.get(row['execution_receipt_id']), list) or checks[row['execution_receipt_id']] for row in rows):\n"
        "        return 'EXECUTED_RECEIPT_UNVERIFIED'\n"
        "    return cell_status_after_verification(rows)\n\n"
        "def main()->int:")
    text = one(text,
        'pred_hash=sha((ROOT/"configs/batch102_outcome_semantic_registry_v4.jsonl").read_bytes()); fresh=[]',
        'registry_bytes=(ROOT/"configs/batch102_outcome_semantic_registry_v4.jsonl").read_bytes(); pred_hash=sha(registry_bytes); fresh=[]')
    text = one(text, ").record(); fresh.append(out)",
        ").record(); out=bind_current_semantics(out, semantic, cell, registry_bytes); fresh.append(out)")
    text = one(text,
        '"blockers":verifier(r,current_workflow_run_id=current_run,current_workflow_head=current_head)',
        '"blockers":verifier(r,current_workflow_run_id=current_run,current_workflow_head=current_head)+verify_current_fresh_semantics(r,cells[r["cell_id"]],registry_bytes)')
    text = one(text,
        'status="EXECUTED_VERIFIED" if all(r["predicate_result"] for r in fresh if r["cell_id"]==cell["cell_id"]) else "EXECUTED_PREDICATE_FALSE"',
        'status=current_cell_status([r for r in fresh if r["cell_id"]==cell["cell_id"]],verification)')
    outputs[path] = text

    path = "scripts/seal_batch103_candidate_outcomes.py"
    text = (SOURCE / path).read_text()
    text = one(text, "def canonical_hash(value: object) -> str:",
        "from controllergate.evidence.registry_bound_semantic_seam_candidate import (\n"
        "    verify_fresh_semantics, semantic_pair_consistent, cell_status_after_verification,\n)\n\n"
        "def verify_current_semantics(row, cell, registry_bytes):\n"
        "    return verify_fresh_semantics(row, cell, registry_bytes)\n\n"
        "def canonical_hash(value: object) -> str:")
    cell_lines = '    cells = read_jsonl(ROOT / "configs/batch102_counterfactual_cell_registry_v4.jsonl")\n    cell_by_id = {row["cell_id"]: row for row in cells}\n'
    text = one(text, cell_lines, "")
    text = one(text, '    submitted = collect_jsonl(args.cell_artifacts_root, "batch103_fresh_execution_receipts_v1.jsonl")',
        cell_lines + '    registry_bytes = (ROOT / "configs/batch102_outcome_semantic_registry_v4.jsonl").read_bytes()\n'
        '    submitted = collect_jsonl(args.cell_artifacts_root, "batch103_fresh_execution_receipts_v1.jsonl")')
    text = one(text, '                current_workflow_head=args.workflow_head,\n            ),',
        '                current_workflow_head=args.workflow_head,\n            ) + verify_current_semantics(row, cell_by_id.get(row.get("cell_id"), {}), registry_bytes),')
    text = one(text,
        '            status = (\n                "EXECUTED_VERIFIED"\n                if all(row["predicate_result"] for row in receipts)\n                else "EXECUTED_PREDICATE_FALSE"\n            )',
        '            status = cell_status_after_verification(receipts)')
    text = one(text,
        '"semantic_reproducibility": len(receipts) >= 2\n            and len({(r["semantic_fingerprint"], r["predicate_result"]) for r in receipts}) == 1,',
        '"semantic_reproducibility": semantic_pair_consistent(receipts, cell, registry_bytes),')
    text = one(text,
        '"semantic_reproducibility": len(outcomes) >= 2\n            and len({(r["semantic_fingerprint"], r["predicate_result"]) for r in outcomes}) == 1,',
        '"semantic_reproducibility": semantic_pair_consistent(receipts, cell_by_id[cell_id], registry_bytes),')
    text = text.replace('"predicate_result": row["predicate_result"],',
                        '"predicate_result": row["predicate_result"],\n            "semantic_status": row["semantic_status"],')
    outputs[path] = text
    outputs["controllergate/evidence/registry_bound_semantics_candidate.py"] = (HERE / "registry_bound_semantics.py").read_text().replace(
        "import archived_declarative_predicate_v1 as original", "from . import declarative_predicate_v1 as original")
    outputs["controllergate/evidence/registry_bound_semantic_seam_candidate.py"] = (HERE / "fresh_semantic_seam.py").read_text().replace(
        "import registry_bound_semantics as semantics", "from . import registry_bound_semantics_candidate as semantics")
    patch = []
    for path, content in outputs.items():
        destination = OUT / path
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_text(content)
        compile(content, path, "exec")
        original = (SOURCE / path).read_text() if (SOURCE / path).exists() else ""
        patch.extend(difflib.unified_diff(original.splitlines(True), content.splitlines(True),
            fromfile="a/" + path if original else "/dev/null", tofile="b/" + path))
    (HERE / "INTEGRATION_CANDIDATE.patch").write_text("".join(patch))
    (HERE / "INTEGRATION_SOURCE_ANCHORS.json").write_text(json.dumps({
        "base_head": "38897b79588f3ff4b1b9002eedc299a9bcf05140",
        "official_execution_head": "3aa1a749be0a1e13bd735623c812335af9795f76",
        "source_anchors": anchors,
        "scope": "Reviewable isolated patch; not applied to remote repository or old source snapshot. Provider execution not rerun.",
        "schema_change": "New semantic_status and nullable predicate_result; old boolean retained only as diagnostic. Updated seal required.",
    }, indent=2) + "\n")
    print("Built isolated candidate and unified diff for", len(outputs), "files")


if __name__ == "__main__":
    main()
