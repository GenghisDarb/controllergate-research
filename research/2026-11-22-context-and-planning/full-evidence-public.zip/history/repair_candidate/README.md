# Registry-bound outcome repair candidate

This is a **local, uninstalled repair proposal** against ControllerGate HEAD `38897b79588f3ff4b1b9002eedc299a9bcf05140`. It changes neither the original snapshots nor any remote repository. It does not rerun the historical providers or revise Batch103's recorded causal results.

## What was wrong

The fresh Batch103 path invokes the Batch102 slice, which invokes the Batch100 candidate runner. That runner still decides outcomes with candidate-specific predicates. The fresh wrapper copies its boolean and the full observation hash while attaching the newer v4 registry hash. The seal and causal compiler consume those values. A registry digest does not demonstrate that its predicate was evaluated.

For example, the legacy Py-bugger rule requires count equality and exactly ten attempts; the frozen v4 incident predicate instead detects reported counts exceeding successful and persisted mutations. The legacy Audioread control can treat an absent structured observation as success. The whole-observation fingerprint also includes stdout/stderr digests, making custody changes affect semantic replay.

## What the candidate changes

- Evaluates the exact frozen v4 predicate and binds registry bytes, selected entry, predicate, raw observation and execution context.
- Keeps the original full observation for custody while computing a **new, explicitly named** outcome projection from the program's incident/control operand fields and declared software invariants.
- Returns `UNRESOLVED` for missing or incompatible observations and unsupported role mappings. A legitimate measured negative result remains `NOT_SATISFIED`.
- Independently recomputes the receipt at the fresh wrapper and Batch103 seal. Hashing or re-signing an invented result does not make it valid.
- Retains legacy values only as diagnostics. Wrapper accounting and seal accounting preserve `EXECUTED_SEMANTICS_UNRESOLVED` rather than classifying it as predicate-false.
- Requires independently supplied registry/observation/context inputs before comparing two outcome receipts. Python's `True == 1` does not allow a type-mutated receipt through.

`INTEGRATION_CANDIDATE.patch` contains two modified existing files and two proposed evidence modules. Full review copies are in `integration_candidate/`. `INTEGRATION_SOURCE_ANCHORS.json` pins the original wrapper and seal. The same originals were verified byte-identical at official execution HEAD `3aa1a749be0a1e13bd735623c812335af9795f76`.

**Schema migration is explicit:** `predicate_result` may now be null only with unresolved semantics, and receipts carry `semantic_status`, a bound outcome receipt and the raw observation. Apply the wrapper and seal changes together. The diff is provided for review, not automatically applied. Other consumers and schema tools need compatibility review before deployment.

## Evidence and reproduction

`results_v2/verification.json` records **33 test methods, zero failures and zero errors**. Tests execute the actual inserted wrapper/seal helper functions from the integration copies; an AST check confirms those helpers are called by the patched main paths. No provider process is launched. `results_v1/` is retained as an earlier development check before the final wrapper-accounting correction.

Run from this directory:

```sh
python run_checks.py --output my_new_checks
```

The destination must be new or empty. Python's standard library is sufficient. To regenerate the review copies and patch from the included parent `source/` snapshot:

```sh
python build_integration_candidate.py
```

The builder refuses source anchors that differ from the inspected Git blobs. It writes only the integration candidate and diff. It does not modify the source snapshot.

The original evaluator and v4 registry are copied unchanged. `legacy_predicate_excerpt.py` contains the actual two legacy functions used in the regression comparison. Fixture values are **synthetic observations in archived field shapes**, not recovered official runtime observations. The first check encountered a missing fixture caused by the extraction working directory; its correction is recorded in `INITIAL_RUN_NOTE.json`. Independent review then found a Python boolean/integer equality defect and an unverified replay boundary in the first candidate; both were fixed and regression-tested. The final independent review is in the sibling `bridge/repair_review_final.json` evidence supplied with the broader report.

## Limits and next real integration check

The new projection establishes equality of **declared outcome measurements and software invariants**. It is not equivalence of every possible scientific observable. Some raw observation shapes do not match the current predicate registry: nested Audioread data and Poetry's field names need an explicit, reviewed schema adapter. This candidate leaves them unresolved instead of guessing an alias. Factorial/necessity/sufficiency roles without a declared predicate also remain unresolved.

The layer classifies supplied observations; it does not independently extract those observations from unavailable raw stdout, authenticate distinct external executions, establish biological dynamics, prove causal ownership, authorize a patch, or demonstrate Reactome/TLD superiority. The decisive next check is one preregistered, fully materialized incident/control program with exact provider/source/context, captured raw outputs, a reviewed schema adapter, and independent re-extraction and replay through the integrated path.

## Repair playbook

| Root cause | Fix | Detection | Other places to inspect |
|---|---|---|---|
| A newer registry hash labels an older predicate result | Evaluate the frozen registry on the actual observation and bind both | Contrasting count-inflation and count-equality fixtures | Other source adapters and inherited-result reprojections |
| Missing structured evidence becomes a successful negative/control | Explicit unresolved state and field/role contract | Missing Audioread and unmapped Poetry fixtures | Negative regulation, exception absence, optional fields |
| Raw custody changes redefine semantic replay | Keep raw hashes; compare a separately declared scientific projection | Same counts with different stdout/stderr hashes, then genuinely changed counts | Timing, paths, process IDs, raw trace digests |
| Re-signed output labels bypass semantic verification | Recompute from independent inputs, compare type-sensitive canonical content | Forged/re-signed result and `True` to `1` mutation | Summaries, sidecars, terminal writers and verifier return codes |
| An unresolved result is collapsed again downstream | Update wrapper and seal status accounting together | Inserted-helper tests keep unresolved status and require verification | Dashboards, counts, causal compilers and legacy boolean consumers |
