"""Portable bounded verification; writes only into a new output directory."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
from pathlib import Path
import unittest

import registry_bound_semantics as core
import fresh_semantic_seam as seam
import test_repair as fixtures
from test_integration_seam import wrapped, sealed

HERE = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    if args.output.exists() and any(args.output.iterdir()):
        raise SystemExit("Refusing to overwrite a nonempty output directory")
    args.output.mkdir(parents=True, exist_ok=True)
    stream = io.StringIO()
    suite = unittest.defaultTestLoader.discover(str(HERE), pattern="test_*.py")
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    (args.output / "test_log.txt").write_text(stream.getvalue())
    examples = []
    for name, obs, role in (
        ("count_inflation", dict(fixtures.INFLATED), "incident"),
        ("noninflated_incident", dict(fixtures.INFLATED, attempted_mutation_count=10, cli_reported_inserted_count=7), "incident"),
        ("legitimate_accounting_control", dict(fixtures.INFLATED), "control"),
        ("missing_measurement", {k: v for k, v in fixtures.INFLATED.items() if k != "successful_mutation_count"}, "incident"),
    ):
        legacy = fixtures.legacy_predicate()(fixtures.CANDIDATE, {"cell_name": role}, obs)
        row, cell = wrapped(obs, role=role, legacy=legacy)
        examples.append({"name": name, "provenance": "synthetic values in archived observation shape; not an official provider replay",
            "observation": obs, "role": role, "legacy_boolean": legacy,
            "new_verdict": row["bound_outcome_receipt"]["verdict"],
            "new_receipt": row, "seal_errors": sealed(row, cell)})
    (args.output / "regression_examples.json").write_text(json.dumps(examples, indent=2) + "\n")
    manifest = []
    for path in sorted(HERE.rglob("*")):
        if path.is_file() and "__pycache__" not in path.parts and path.suffix in {".py", ".jsonl", ".patch", ".md"} and not path.is_relative_to(args.output):
            manifest.append({"path": str(path.relative_to(HERE)), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(), "bytes": path.stat().st_size})
    receipt = {"run_at_utc": datetime.now(timezone.utc).isoformat(), "test_methods": result.testsRun,
        "failures": len(result.failures), "errors": len(result.errors), "passed": result.wasSuccessful(),
        "registry_sha256": fixtures.DIGEST, "specification": json.loads((HERE / "SPECIFICATION_FREEZE.json").read_text()),
        "scope": "Unit and inserted-seam tests on source-shaped synthetic observations only; no external provider or historical causal-gain rerun.",
        "source_and_candidate_files": manifest}
    (args.output / "verification.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({key: receipt[key] for key in ("test_methods", "failures", "errors", "passed", "scope")}, indent=2))
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
