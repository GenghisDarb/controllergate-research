"""Execute the actual inserted wrapper/seal helpers without launching providers."""
from __future__ import annotations
import ast
import copy
from pathlib import Path
import unittest

import fresh_semantic_seam as seam
from test_repair import CANDIDATE, PROGRAM, CONTEXT, INFLATED, REGISTRY

HERE = Path(__file__).resolve().parent


def inserted_helper(path, name, bindings):
    text = (HERE / "integration_candidate" / path).read_text()
    tree = ast.parse(text)
    function = next(node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name == name)
    module = ast.Module(body=[function], type_ignores=[])
    namespace = dict(bindings)
    exec(compile(ast.fix_missing_locations(module), path, "exec"), namespace)
    return namespace[name]


def wrapped(observation=None, *, candidate=CANDIDATE, program=PROGRAM, role="incident", legacy=False):
    observation = copy.deepcopy(INFLATED if observation is None else observation)
    cell = {"cell_id": CONTEXT["cell_id"], "candidate_id": candidate, "program_id": program, "cell_role": role}
    row = {**CONTEXT, "candidate_id": candidate, "program_id": program,
           "execution_receipt_id": "synthetic-fresh-receipt",
           "predicate_result": legacy, "semantic_fingerprint": "legacy-whole-dictionary",
           "semantic_projection_id": "controllergate-semantic-projection-v2",
           "predicate_registry_hash": seam.PINNED_REGISTRY_SHA256}
    function = inserted_helper("scripts/run_batch102_candidate_slice.py", "bind_current_semantics",
                               {"bind_fresh_receipt": seam.bind_fresh_receipt})
    return function(row, observation, cell, REGISTRY), cell


def sealed(row, cell):
    function = inserted_helper("scripts/seal_batch103_candidate_outcomes.py", "verify_current_semantics",
                               {"verify_fresh_semantics": seam.verify_fresh_semantics})
    return function(row, cell, REGISTRY)


class IntegrationTests(unittest.TestCase):
    def test_inserted_wrapper_replaces_legacy_false_using_actual_registry(self):
        row, cell = wrapped(legacy=False)
        self.assertIs(row["legacy_predicate_result_diagnostic"], False)
        self.assertIs(row["predicate_result"], True)
        self.assertEqual(sealed(row, cell), [])
        self.assertEqual(seam.cell_status_after_verification([row]), "EXECUTED_VERIFIED")

    def test_inserted_wrapper_and_seal_preserve_unknown_not_legacy_pass(self):
        row, cell = wrapped({"structured_observation_missing": True, "return_code": 1},
            candidate="audioread_144_py313_aifc_removed", program="batch100-audioread-144-aifc",
            role="control", legacy=True)
        self.assertIs(row["legacy_predicate_result_diagnostic"], True)
        self.assertIsNone(row["predicate_result"])
        self.assertEqual(sealed(row, cell), [])
        self.assertEqual(seam.cell_status_after_verification([row]), "EXECUTED_SEMANTICS_UNRESOLVED")
        self.assertFalse(seam.semantic_pair_consistent([row, row], cell, REGISTRY))

    def test_seal_rejects_resigned_outer_predicate_override(self):
        row, cell = wrapped()
        row["predicate_result"] = False
        row["record_hash"] = seam.record_hash({k: v for k, v in row.items() if k != "record_hash"})
        self.assertIn("outer_semantic_fields_disagree", sealed(row, cell))

    def test_seal_rejects_integer_for_boolean_even_after_resigning(self):
        row, cell = wrapped()
        row["predicate_result"] = 1
        row["record_hash"] = seam.record_hash({k: v for k, v in row.items() if k != "record_hash"})
        self.assertIn("outer_semantic_fields_disagree", sealed(row, cell))

    def test_seal_rejects_registry_hash_without_actual_binding(self):
        row, cell = wrapped()
        del row["bound_outcome_receipt"]
        row["record_hash"] = seam.record_hash({k: v for k, v in row.items() if k != "record_hash"})
        self.assertIn("raw_observation_or_binding_missing", sealed(row, cell))

    def test_seam_replays_scoped_outcome_not_volatile_custody(self):
        first, cell = wrapped()
        second, _ = wrapped(dict(INFLATED, stdout_sha256="e" * 64, stderr_sha256="f" * 64))
        self.assertTrue(seam.semantic_pair_consistent([first, second], cell, REGISTRY))
        self.assertNotEqual(first["bound_outcome_receipt"]["raw_observation_hash"], second["bound_outcome_receipt"]["raw_observation_hash"])

    def test_seam_does_not_confuse_negative_with_unknown(self):
        row, cell = wrapped(dict(INFLATED, cli_reported_inserted_count=7), legacy=True)
        self.assertEqual(sealed(row, cell), [])
        self.assertIs(row["predicate_result"], False)
        self.assertEqual(seam.cell_status_after_verification([row]), "EXECUTED_PREDICATE_FALSE")

    def test_inserted_helpers_are_on_actual_main_call_paths(self):
        for filename, helper in (("run_batch102_candidate_slice.py", "bind_current_semantics"),
                                 ("run_batch102_candidate_slice.py", "verify_current_fresh_semantics"),
                                 ("run_batch102_candidate_slice.py", "current_cell_status"),
                                 ("seal_batch103_candidate_outcomes.py", "verify_current_semantics")):
            with self.subTest(filename=filename):
                tree = ast.parse((HERE / "integration_candidate/scripts" / filename).read_text())
                main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == "main")
                self.assertTrue(any(isinstance(n, ast.Call) and isinstance(n.func, ast.Name) and n.func.id == helper for n in ast.walk(main)))

    def test_wrapper_accounting_preserves_unresolved_and_requires_verification(self):
        status = inserted_helper("scripts/run_batch102_candidate_slice.py", "current_cell_status",
                                 {"cell_status_after_verification": seam.cell_status_after_verification})
        row, cell = wrapped({"structured_observation_missing": True, "return_code": 1},
            candidate="audioread_144_py313_aifc_removed", program="batch100-audioread-144-aifc", role="control", legacy=True)
        checks = [{"id": row["execution_receipt_id"], "blockers": sealed(row, cell)}]
        self.assertEqual(status([row], checks), "EXECUTED_SEMANTICS_UNRESOLVED")
        self.assertEqual(status([row], []), "EXECUTED_RECEIPT_UNVERIFIED")
        self.assertEqual(status([row], [{"id": row["execution_receipt_id"], "blockers": ["failed"]}]), "EXECUTED_RECEIPT_UNVERIFIED")

    def test_wrapper_verifier_rejects_the_same_forgery_as_seal(self):
        verify = inserted_helper("scripts/run_batch102_candidate_slice.py", "verify_current_fresh_semantics",
                                 {"verify_fresh_semantics": seam.verify_fresh_semantics})
        row, cell = wrapped()
        row["predicate_result"] = False
        row["record_hash"] = seam.record_hash({k: v for k, v in row.items() if k != "record_hash"})
        self.assertIn("outer_semantic_fields_disagree", verify(row, cell, REGISTRY))


if __name__ == "__main__":
    unittest.main()
