from __future__ import annotations

from typing import Any

def predicate_satisfied(candidate: str, cell: dict[str, Any], observation: dict[str, Any]) -> bool:
    name = cell["cell_name"]
    if candidate == "darker_issue_112_relative_git_dir":
        return bool(observation["not_a_git_repository"]) if name == "relative-git-dir" else not bool(observation["not_a_git_repository"])
    if candidate == "py_bugger_issue_65":
        return observation["attempted_mutation_count"] == 10 and observation["cli_reported_inserted_count"] == observation["successful_mutation_count"]
    if candidate == "cloudpickle_507_py313_typevar_distutils":
        if "typevar" in cell["program_id"]:
            return observation["typevar_weakref_error"] if name == "python312-typevar" else result_pass(observation)
        return observation["distutils_import_error"] if name == "python312-no-setuptools" else result_pass(observation)
    if candidate == "freezegun_547_py313_datetimes_assertion":
        return observation["failed_node_count"] == 3 if name == "python3130b1" else result_pass(observation)
    if candidate == "audioread_144_py313_aifc_removed":
        failed = observation.get("aifc", {}).get("exception_type") == "ModuleNotFoundError"
        return failed if name.startswith("python313") else not failed
    if candidate == "pytest_13480_wdefault_unraisable_threadexception":
        return observation["outer_pytest_exit_code"] not in {0, 4} if name == "wdefault" else observation["outer_pytest_exit_code"] == 0
    if candidate == "incident_poetry_10974_init_duplicate_name":
        if name == "windows-spaces-inferred":
            return observation.get("raw_project_name") == "my project with spaces"
        return observation.get("normalized_project_name") == "my-project-with-spaces"
    return False

def result_pass(observation: dict[str, Any]) -> bool:
    return observation.get("return_code") == 0
