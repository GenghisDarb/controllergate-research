# Isolated semantic repair specification

Frozen before executing this candidate's regression fixtures. This is a local repair proposal, not a repository change, provider run, revised historical count, or causal-gain result.

## Verified path to address
At current HEAD 38897b79588f3ff4b1b9002eedc299a9bcf05140, the Batch103 workflow invokes the Batch102 slice through the Batch103 wrapper. The slice runs the Batch100 candidate runner, copies its candidate-specific predicate boolean, labels a hash of the full observation a v2 semantic fingerprint, and attaches the v4 registry hash. The Batch103 outcome seal and public causal compiler consume those fields. The relevant files are byte-identical at official execution HEAD 3aa1a749be0a1e13bd735623c812335af9795f76. The declared v4 registry contains a corrected Py-bugger inflation predicate, whereas the invoked legacy function demands count equality.

## Repair contract
1. Read the exact frozen v4 predicate registry; select exactly one candidate/program entry and an explicitly defined incident or control predicate. No inferred role or fallback predicate.
2. Evaluate that predicate on the supplied observation using the archived declarative evaluator. Bind the result to registry-byte SHA256, selected row, selected predicate, complete raw observation and explicit software execution-context hashes. A registry hash alone does not prove evaluation.
3. Missing required operand fields, unsupported roles, malformed predicates, incompatible operands, nonfinite numbers, and incomplete declared replay invariants yield UNRESOLVED, never scientific false, success, or a negative-regulation assertion. Boolean values are not accepted as numeric measurements.
4. Add a separately named outcome projection: the union of operand fields referenced by this program's incident/control predicates, plus fixed software-context invariants. Preserve the complete raw-observation hash separately. This is a new projection contract, not an assertion that the historical v2 projection already did this, and not full equivalence of all scientific observables.
5. The required replay invariants are cell_id, source_commit, source_capsule_hash, provider_capsule_hash, exact_argv_hash, environment_hash and fixture_hash. They must match across a replay pair. A shared verdict without matching measured values is insufficient. Missing evidence remains unresolved.
6. Provide an independent receipt verifier that requires externally supplied raw observation, context and expected registry digest and recomputes actual predicate/projection results. Re-signing a forged PASS must not suffice.
7. This layer cannot infer necessity, sufficiency, ownership, repair authorization, fresh external execution, biological dynamics or a gain from Reactome/TLD.

## Frozen focused regression cases
Use observation shapes and predicates recovered from the source, with invented fixture values clearly labeled, not alleged replays of unavailable official observations:
- Py-bugger count inflation: the legacy equality rule rejects an observation satisfying the current registry.
- A legitimate non-inflated incident-negative and a valid accounting control.
- Missing structured/operand data remains unresolved.
- True observed negative evidence remains distinguishable from missing.
- Same declared observable values with differing raw stdout/stderr digests: distinct custody, equal outcome projection.
- Changed measured counts or provider/source/command invariants: replay differs.
- Boolean and nonfinite numeric values, ambiguous registry entries, unsupported roles, altered registry bytes, forged/re-signed outcome receipts, and changed raw observations must not pass verification.
- Stable legitimate passing and negative receipts must verify.

No external provider is rerun. Test success establishes the candidate layer's behavior on these fixtures only. Historical Batch103 values and private truth joins remain unchanged.

