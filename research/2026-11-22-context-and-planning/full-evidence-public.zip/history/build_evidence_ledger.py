"""Create source-linked audit receipts from the read-only selected snapshots."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
HEAD = "38897b79588f3ff4b1b9002eedc299a9bcf05140"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    manifest = json.loads((HERE / "SOURCE_MANIFEST.json").read_text())
    by_path = {row["path"]: row for row in manifest}
    defs = [
        ("CG01", "docs/CURRENT_CONTROLLERGATE_HANDOFF.md", [(3, 11), (13, 59), (63, 77)]),
        ("CG02", "docs/REACTOME_CONTROLLERGATE_COMPLETION_STATUS.md", [(1, 44)]),
        ("CG03", "configs/controllergate_5_14_6_196_stack_v3.json", [(1, 65)]),
        ("CG04", "configs/controllergate_isomorphism_errata_v3.json", [(1, 45)]),
        ("CG05", "controllergate/isomorphism/reactome_source_grounded_scenarios_v2.py", [(14, 65), (84, 175)]),
        ("CG06", "outputs/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain_exact_materialization/reactome_mapping_completeness_v2.json", [(1, 92)]),
        ("CG07", "scripts/build_batch103_reactome_closure.py", [(430, 537)]),
        ("CG08", "controllergate/isomorphism/runtime.py", [(25, 105)]),
        ("CG09", "controllergate/isomorphism/primitives.py", [(101, 173)]),
        ("CG10", "controllergate/amds/reactome_planner_v1.py", [(58, 169)]),
        ("CG11", "scripts/run_batch102_candidate_slice.py", [(33, 70)]),
        ("CG12", "scripts/run_batch100_candidate_program.py", [(214, 270), (330, 367)]),
        ("CG13", "scripts/seal_batch103_candidate_outcomes.py", [(70, 161)]),
        ("CG14", "configs/batch102_outcome_semantic_registry_v4.jsonl", [(2, 2), (6, 6), (9, 9)]),
        ("CG15", "controllergate/evidence/declarative_predicate_v1.py", [(13, 120)]),
        ("CG16", "controllergate/evidence/batch103_fresh_execution_attestation_v1.py", [(81, 120)]),
        ("CG17", "scripts/run_batch103_independent_critic.py", [(95, 126)]),
        ("CG18A", "controllergate/repair/ast_synthesizer.py", [(1, 40)]),
        ("CG18B", "controllergate/repair/external_agent_adapter.py", [(1, 30)]),
        ("CG18C", "configs/controllergate_canonical_component_registry.json", [(1, 50)]),
        ("CG19", "scripts/compile_batch103_public_evidence.py", [(143, 216), (304, 329)]),
        ("CG20", ".github/workflows/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain.yml", [(113, 123), (190, 195), (220, 225), (250, 255), (323, 329)]),
        ("CG21", "controllergate/isomorphism/source_bound.py", [(13, 76)]),
    ]
    excerpts = []
    for alias, path, spans in defs:
        src = HERE / "source" / path
        lines = src.read_bytes().decode("utf-8").split("\n")
        for start, stop in spans:
            end = min(stop, len(lines))
            excerpts.append({"alias": alias, "source_path": path, "sha256": sha(src),
                "git_blob_sha": by_path[path]["git_blob_sha"], "url": by_path[path]["url"],
                "first_line": start, "last_line": end, "line_scheme": "physical newline-delimited lines, one-based",
                "text": "\n".join(line.rstrip("\r") for line in lines[start-1:end])})
    historical = HERE.parents[1] / "recovered_archives/TORUS Theory/ControllerGate Development Chats 9(4).txt"
    if historical.exists():
        lines = historical.read_bytes().decode("utf-8").split("\n")
        for start, end in [(1820, 1834), (1941, 1970), (34822, 34900)]:
            excerpts.append({"alias": "H01", "source_path": str(historical), "sha256": sha(historical),
                "first_line": start, "last_line": end, "line_scheme": "physical newline-delimited lines, one-based",
                "text": "\n".join(x.rstrip("\r") for x in lines[start-1:end])})
    (HERE / "SOURCE_EXCERPTS.json").write_text(json.dumps(excerpts, indent=2, ensure_ascii=False) + "\n")
    text = ["# Selected exact source excerpts\n\nLine numbers are physical newline-delimited lines, not notebook cell indices or Unicode splitlines indices.\n"]
    for e in excerpts:
        text.append(f"\n## {e['alias']} — {e['source_path']} — L{e['first_line']}–{e['last_line']}\n\nSHA256: `{e['sha256']}`\n")
        if e.get("url"):
            text.append(e["url"] + "\n")
        text.append("```text\n" + "\n".join(f"{e['first_line']+i}: {line}" for i, line in enumerate(e["text"].split("\n"))) + "\n```\n")
    (HERE / "SOURCE_EXCERPTS.md").write_text("\n".join(text))
    def ref(alias, path, first, last):
        row = by_path[path]
        return {"alias": alias, "source_path": path, "sha256": row["sha256"], "git_blob_sha": row["git_blob_sha"], "first_line": first, "last_line": last, "url": row["url"]}
    r3 = {
        "audit_type": "read-only source capability audit", "head": HEAD,
        "source": ref("CG07", "scripts/build_batch103_reactome_closure.py", 473, 537),
        "achieved": ["reaction-specific operation-family selection from explicit source relations", "deterministic chained hashes binding source/scenario/operation order", "explicit nonauthorizing receipts"],
        "not_established_by_this_path": ["executed dependency acquisition", "resource or cellular state transition", "independent recomputation of a reaction-state trajectory", "causal-planning gain", "biological completeness or validation"],
        "mechanism": "output_hash=canonical_hash([prior,family,index]); the same generator emits verification PASS from those local values",
        "positive_other_runtime": [ref("CG08", "controllergate/isomorphism/runtime.py", 25, 105), ref("CG09", "controllergate/isomorphism/primitives.py", 101, 173)],
        "other_runtime_credit": "Earlier typed simulation applies bounded software resource/compartment/authority rules and records canonical simulation stages; not absent from the repository.",
        "supersession_scope": "The reviewed current Batch103 generator imports the source-grounded compiler, not the earlier simulation runtime. No newer branch/release was exposed by the current repository inventory.",
        "execution_today": "source inspection only; no 16814-reaction regeneration or full simulation replay"}
    (HERE / "R3_CAPABILITY_AUDIT.json").write_text(json.dumps(r3, indent=2) + "\n")
    semantic = {
        "head": HEAD, "official_execution_head": "3aa1a749be0a1e13bd735623c812335af9795f76",
        "execution_head_file_equality_receipt": "remote_execution_check.json",
        "finding": "The frozen v4 registry is labeled on fresh receipts while the inspected fresh path copies legacy predicate outcomes and whole-observation fingerprints.",
        "source_chain": [ref("CG11", "scripts/run_batch102_candidate_slice.py", 39, 64), ref("CG12", "scripts/run_batch100_candidate_program.py", 245, 270), ref("CG12", "scripts/run_batch100_candidate_program.py", 338, 365), ref("CG13", "scripts/seal_batch103_candidate_outcomes.py", 110, 160), ref("CG16", "controllergate/evidence/batch103_fresh_execution_attestation_v1.py", 81, 111), ref("CG19", "scripts/compile_batch103_public_evidence.py", 162, 215)],
        "corrected_registry": ref("CG14", "configs/batch102_outcome_semantic_registry_v4.jsonl", 2, 2),
        "independent_source_check": "bridge reviewer confirmed no later declarative re-evaluation in inspected seal/planner/causal compiler; attestation verifier checked here too",
        "earlier_repair_credit": "Batch101 declarative re-projection remains a real earlier improvement; it was not automatically integrated into this later fresh path.",
        "local_candidate": "repair_candidate/INTEGRATION_CANDIDATE.patch",
        "local_validation": "repair_candidate/results_v2/verification.json",
        "scope": "33 methods on synthetic source-shaped records and inserted helpers; no external provider execution, remote write or revised historical causal score"}
    (HERE / "SEMANTIC_PATH_AUDIT.json").write_text(json.dumps(semantic, indent=2) + "\n")
    chronology = [
        {"stage": "Batch099", "resolved": "contact evidence separated from ownership; 432 apparent contradictions corrected;504 contact admissions", "remaining": "zero ownership", "source": "CG01 L5"},
        {"stage": "Batch100", "resolved": "source/provider capsules and immutable programs", "remaining": "incomplete exact materialization; repeated counts15/16; no ownership", "source": "CG01 L7–9"},
        {"stage": "Batch101", "resolved": "declarative predicates and replay reprojection; bounded Py-bugger sensitivity", "remaining": "inherited Batch100 operations, not fresh execution; no ownership", "source": "CG01 L13–59;L63"},
        {"stage": "Batch102", "resolved": "current-workflow fresh execution origin required", "remaining": "counterfactual completion and semantic integration", "source": "CG01 L63–69;CG11–CG16"},
        {"stage": "Batch103", "resolved": "reaction-specific source mapping; retired round-robin authority; equal-budget frozen arms;15freshcells", "remaining": "55unmaterialized;A–I false attribution;R4/R5notestablished;R6notrun", "source": "CG01 L73–77;CG02"},
        {"stage": "2026-11-23 local audit", "resolved": "fresh-path regression isolated; local registry-bound integration candidate;33 tests passing", "remaining": "unmapped observation schemas; reviewed full-workflow integration; fresh independent causal experiment", "source": "SEMANTIC_PATH_AUDIT.json;repair_candidate/results_v2/verification.json"},
    ]
    (HERE / "CHRONOLOGY.json").write_text(json.dumps({"status": "versioned source chronology, not proof of universal completeness", "stages": chronology}, indent=2) + "\n")
    print(json.dumps({"current_source_files": len(manifest), "excerpt_blocks": len(excerpts), "all_git_blobs_verified": all(x["git_blob_verified"] for x in manifest)}))


if __name__ == "__main__":
    main()
