"""Apply this pass's integration edits to the isolated prior candidate checkout."""
from pathlib import Path

ROOT = Path(__file__).resolve().parent / "checkout"


def one(text, old, new):
    if text.count(old) != 1:
        raise RuntimeError("anchor not unique: " + old[:120])
    return text.replace(old, new, 1)


p = ROOT / "scripts/run_batch100_candidate_program.py"
t = p.read_text()
t = one(t, "from controllergate.runtime.runtime_root_attestation import attest_runtime_root",
        "from controllergate.runtime.runtime_root_attestation import attest_runtime_root\n"
        "from controllergate.evidence.execution_contract_binding_candidate import make_execution_binding, PRODUCER_PATH")
t = one(t, '    cells = [row for row in read_jsonl(ROOT / "configs/batch100_counterfactual_cell_registry_v2.jsonl") if row["candidate_id"] == candidate]',
        '    producer_registry_bytes = (ROOT / PRODUCER_PATH).read_bytes()\n'
        '    cells = [row for row in read_jsonl(ROOT / PRODUCER_PATH) if row["candidate_id"] == candidate]')
t = one(t, 'semantic = semantic_observation(candidate, cell_row, result, consumer, ledger)',
        'semantic = semantic_observation(candidate, cell_row, result, consumer, ledger)\n'
        '                if candidate == "incident_poetry_10974_init_duplicate_name":\n'
        '                    semantic["actual_cwd_basename"] = cwd.name')
t = one(t, '                    "operation_id": broker.records[-1]["operation_id"], "semantic_observation": semantic,',
        '                    "execution_contract_binding": make_execution_binding(cell_row, registry_bytes=producer_registry_bytes, provider=providers[cell_row["provider_capsule_id"]], source_commit=contracts[candidate]["source_commit"], observed_argv=sanitize(argv,args.runtime_root), observed_cwd=sanitize(str(cwd.resolve()),args.runtime_root)),\n'
        '                    "operation_id": broker.records[-1]["operation_id"], "semantic_observation": semantic,')
p.write_text(t)

p = ROOT / "scripts/run_batch102_candidate_slice.py"
t = p.read_text()
t = one(t, 'def bind_current_semantics(out, semantic, cell, registry_bytes):\n    return bind_fresh_receipt(out, semantic, cell, registry_bytes)',
        'from controllergate.evidence.execution_contract_binding_candidate import inventory_preflight\n\n'
        'def bind_current_semantics(out, semantic, cell, registry_bytes, execution_binding=None):\n'
        '    return bind_fresh_receipt(out, semantic, cell, registry_bytes, execution_binding=execution_binding)')
t = one(t, ' old_out=a.output_dir/"raw_candidate_execution";',
        ' inventory = inventory_preflight(a.candidate_id, readj(ROOT/"configs/batch102_counterfactual_cell_registry_v4.jsonl"))\n'
        ' writej(a.output_dir/"producer_inventory_preflight.json",inventory)\n'
        ' if inventory["status"] == "BLOCK": raise RuntimeError("producer/current cell contract mismatch: "+str(inventory["mismatches"]))\n'
        ' old_out=a.output_dir/"raw_candidate_execution";')
t = one(t, 'out=bind_current_semantics(out, semantic, cell, registry_bytes); fresh.append(out)',
        'out=bind_current_semantics(out, semantic, cell, registry_bytes, rr.get("execution_contract_binding")); fresh.append(out)')
p.write_text(t)

for name in ("batch103_fresh_execution_attestation_v1.py", "fresh_execution_attestation_v1.py"):
    p = ROOT / "controllergate/evidence" / name
    t = p.read_text()
    t = one(t, "predicate_result: bool", "predicate_result: bool | None")
    anchor = '    expected = canonical_hash({key: value for key, value in row.items() if key != "record_hash"})'
    if anchor in t:
        t = one(t, anchor,
            '    if row.get("predicate_result") is not None and type(row.get("predicate_result")) is not bool:\n'
            '        blockers.append("predicate_result_not_boolean_or_null")\n' + anchor)
    p.write_text(t)

p = ROOT / "scripts/seal_batch103_candidate_outcomes.py"
t = p.read_text()
t = one(t, '    verification = [',
        '    ids = [row.get("execution_receipt_id") for row in submitted]\n'
        '    if len(ids) != len(set(ids)):\n'
        '        raise RuntimeError("duplicate execution receipt IDs cannot establish replay")\n'
        '    verification = [')
t = one(t, '            allowed = [row for row in proposed if row in STATUS_PRIORITY]',
        '            allowed = [row for row in proposed if row in STATUS_PRIORITY and not row.startswith("EXECUTED")]')
p.write_text(t)

p = ROOT / "scripts/compile_batch103_public_evidence.py"
t = p.read_text()
t = one(t, 'import json\n', 'import json\nimport sys\n')
t = one(t, 'ROOT = Path(__file__).resolve().parents[1]',
        'ROOT = Path(__file__).resolve().parents[1]\n'
        'if str(ROOT) not in sys.path: sys.path.insert(0,str(ROOT))\n'
        'from controllergate.evidence.registry_bound_semantic_seam_candidate import verify_fresh_semantics, measured_pair_contrast')
t = one(t, '    by_cell: dict[str, list[dict[str, Any]]] = defaultdict(list)',
        '    cells = {row["cell_id"]:row for row in read_jsonl(ROOT / "configs/batch102_counterfactual_cell_registry_v4.jsonl")}\n'
        '    registry_bytes = (ROOT / "configs/batch102_outcome_semantic_registry_v4.jsonl").read_bytes()\n'
        '    for row in receipts:\n'
        '        errors = verify_fresh_semantics(row,cells.get(row.get("cell_id"),{}),registry_bytes)\n'
        '        if errors: raise RuntimeError("unverified semantics at compiler: "+str(errors))\n'
        '    by_cell: dict[str, list[dict[str, Any]]] = defaultdict(list)')
t = one(t, '            and all(row["predicate_result"] for row in incident + control)',
        '            and all(row.get("semantic_status") == "EVALUATED" and row.get("predicate_result") is True for row in incident + control)')
t = one(t, '        pair = {', '        contrast = measured_pair_contrast(incident, control)\n        pair = {')
t = one(t, '            "held_invariants_verified": valid,',
        '            "held_invariants_verified": False,\n'
        '            "held_invariants_status": "UNRESOLVED_INDEPENDENT_MEASUREMENTS",\n'
        '            "required_held_invariants": program.get("held_invariants", []),\n'
        '            "pair_scope": "reproducible role classification only",\n'
        '            "measured_predicate_contrast": contrast,')
t = one(t, '                "supported": valid,\n                "evidence_level": "DIMENSION_SENSITIVITY_VERIFIED" if valid else "CONTACT_VERIFIED" if incident else "PRESENCE_VERIFIED",',
        '                "supported": False,\n'
        '                "evidence_level": "ROLE_CLASSIFICATION_PAIR_OBSERVED" if valid else "CONTACT_VERIFIED" if incident else "PRESENCE_VERIFIED",\n'
        '                "descriptive_contrast": contrast,\n'
        '                "exact_blocker": "held invariants have no independently verified measurement receipt at this boundary",')
t = one(t, '        "valid_pair_count": sum(row["status"] == "VALID_PAIR" for row in pairs),',
        '        "valid_pair_count": sum(row["status"] == "VALID_PAIR" for row in pairs),\n'
        '        "valid_pair_scope": "role classification; not sensitivity or invariant verification",')
p.write_text(t)

p = ROOT / "scripts/run_batch103_planner_arm.py"
t = p.read_text()
t = one(t, 'return bool(envelope["outcomes"]) and all(row["predicate_result"] for row in envelope["outcomes"])',
        'return bool(envelope["outcomes"]) and all(row.get("semantic_status") == "EVALUATED" and row.get("predicate_result") is True for row in envelope["outcomes"])')
t = one(t, '                evidence_level = "DIMENSION_SENSITIVITY_VERIFIED"\n                first_sensitivity_step = step\n                break',
        '                evidence_level = "ROLE_CLASSIFICATION_PAIR_OBSERVED"\n'
        '                # Classification does not verify the program\'s held invariants.\n'
        '                # Do not count a sensitivity gain or terminate on overlapping predicates.\n'
        '                continue')
p.write_text(t)

for path in ROOT.rglob("*.py"):
    compile(path.read_text(),str(path),"exec")
print("Patched real producer, wrapper, attestations, seal, compiler and planner; all Python syntax compiled.")
