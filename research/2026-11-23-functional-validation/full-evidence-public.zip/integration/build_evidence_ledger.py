"""Write exact source/role inventories and the reviewable diff; no execution."""
from pathlib import Path
import collections
import difflib
import hashlib
import json
import re

BASE=Path(__file__).resolve().parent
SOURCE=BASE/"source"
CHECKOUT=BASE/"checkout"
HEAD="38897b79588f3ff4b1b9002eedc299a9bcf05140"


def write(name,value):
    (BASE/name).write_text(json.dumps(value,indent=2,sort_keys=True)+"\n")


def rows(path):
    return [json.loads(l) for l in (SOURCE/path).read_text().splitlines() if l.strip()]


def digest(data): return hashlib.sha256(data).hexdigest()


metadata={}
for name in ("PRIOR_SOURCE_MANIFEST.json","FETCHED_SOURCE_METADATA.json"):
    for r in json.loads((BASE/name).read_text()):metadata[r["path"]]=r
manifest=[]
for rel,r in sorted(metadata.items()):
    data=(SOURCE/rel).read_bytes()
    blob=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
    expected=r["git_blob_sha"]
    manifest.append({"path":rel,"bytes":len(data),"sha256":digest(data),"git_blob_sha":blob,
        "expected_git_blob_sha":expected,"git_blob_verified":blob==expected,
        "url":f"https://github.com/GenghisDarb/controllergate-research/blob/{HEAD}/{rel}"})
assert all(r["git_blob_verified"] for r in manifest),"source materialization mismatch"
write("SOURCE_MANIFEST.json",manifest)

vendor=[]
for r in json.loads((BASE/"VENDOR_SOURCE_METADATA.json").read_text()):
    data=(BASE/"vendor_source/audioread_577f8e2"/r["path"]).read_bytes()
    blob=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
    vendor.append({**r,"bytes":len(data),"sha256":digest(data),"git_blob_verified":blob==r["git_blob_sha"]})
assert all(r["git_blob_verified"] for r in vendor)
write("VENDOR_SOURCE_MANIFEST.json",vendor)

programs={r["program_id"]:r for r in rows("configs/batch102_candidate_counterfactual_programs_v4.jsonl")}
registry={r["program_id"]:r for r in rows("configs/batch102_outcome_semantic_registry_v4.jsonl")}
old={r["cell_id"]:r for r in rows("configs/batch100_counterfactual_cell_registry_v2.jsonl")}
cells=rows("configs/batch102_counterfactual_cell_registry_v4.jsonl")
intervention_path="outputs/post_v2_37_hardening_batch103_reactome_isomorphism_causal_planning_gain_exact_materialization/batch103_candidate_intervention_registry_v1.jsonl"
interventions={r["intervention_id"]:r for r in rows(intervention_path)}


def fields(p):
    if isinstance(p,dict):
        if set(p)=={"field"}:return {p["field"]}
        return set().union(*(fields(v) for v in p.values())) if p else set()
    if isinstance(p,list):return set().union(*(fields(v) for v in p)) if p else set()
    return set()


program_notes={
 "batch100-darker-112-git-dir":("direct not_a_git_repository boolean produced", "The marker is text-derived; absence means no matching text, not proof Git completed the intended work."),
 "batch100-py-bugger-65-accounting":("all four count operands present in producer", "persisted_source_diff_mutation_count is int(bool(git diff --numstat)), a 0/1 change indicator; incident and control predicates overlap."),
 "batch100-cloudpickle-507-typevar":("typevar_weakref_error and failed_node_count produced", "Text-count failure tally alone does not establish successful collection/execution of all intended nodes."),
 "batch100-cloudpickle-507-distutils":("exception_type and distutils_import_error produced", "Legacy candidate logic and v4 role predicates are distinct; control absence of this error is narrow."),
 "batch100-freezegun-547-three-nodes":("failed_node_count and fake_date_mismatch produced", "Control zero FAILED tokens alone does not establish the test suite ran successfully."),
 "batch100-audioread-144-aifc":("nested aifc and route_import mapped by explicit import status and route", "Unrelated backend import never stands in for rawread; missing structured observations remain unresolved."),
 "batch100-pytest-13480-warning-mode":("outer_pytest_exit_code and collection_return_code_4 produced", "Frozen incident is exact outer exit 1, narrower than the legacy not-in-{0,4} boolean."),
 "batch100-openbb-7585-topology":("return_code can map to exit_code; no command_count/parse_status/equivalence producer branch", "Source explicitly blocks missing secondary-source/service fixture; no missing measurement is inferred."),
 "batch100-poetry-10974-path-name":("return_code and raw_project_name aliases; new producer captures actual executed cwd.name", "Batch101 explicitly noted old actual cwd was missing. Expected directory name cannot replace an observation."),
}
program_ledger=[]
for i,(pid,r) in enumerate(registry.items(),1):
    program_ledger.append({"program_id":pid,"candidate_id":r["candidate_id"],
        "incident_predicate":r["incident_predicate"],"control_predicate":r["control_predicate"],
        "incident_operand_fields":sorted(fields(r["incident_predicate"])),
        "control_operand_fields":sorted(fields(r["control_predicate"])),
        "source_defined_translation":program_notes[pid][0],"measurement_limit":program_notes[pid][1],
        "required_held_invariants":programs[pid].get("held_invariants",[]),
        "changed_dimensions":programs[pid].get("changed_dimensions",[]),
        "source_reference":{"path":"configs/batch102_outcome_semantic_registry_v4.jsonl","line":i}})
write("PROGRAM_OBSERVATION_LEDGER.json",program_ledger)

role_ledger=[]
for i,c in enumerate(cells,1):
    pid=c["program_id"];role=c["cell_role"];p=programs[pid];inter=interventions[c["cell_id"]]
    declared=role in {"incident","control"}
    memberships=[key for key in ("negative_controls","additional_exclusion_cells") if c["cell_id"] in p.get(key,[])]
    if role=="intervention":
        obligation="Explicit before/after factor removal or introduction, observed incident disappearance/appearance, invariant measurements, replay and direct contact; existing causal_intervention_v12 supplies these gates but not per-cell measurement extractors."
    elif role=="factorial":
        obligation="Executed unique corners, replay and held invariants, plus predeclared non-additive estimand; the existing InteractionReceiptV3 requires all. No single generic control label substitutes."
    elif role in {"exclusion","negative","secondary","diagnostic"}:
        obligation="Record both frozen incident/control predicate diagnostics and the specified route/factor; acceptance and each excluded alternative require a cell-specific measured relation, absent from inspected later v4 and Batch103 intervention registries."
    else:
        obligation="Evaluate exactly the program's "+role+" predicate on measured operands; classification alone does not verify causal invariants."
    missing=[f for f in ("provider_capsule_id","resource_budget","platform") if f not in c]
    flag_issues=[]
    argv=c["exact_argv"]
    if "${AUDIOREAD_HARNESS}" in argv:
        if "--route" in argv and argv[argv.index("--route")+1]=="unrelated":flag_issues.append("source harness accepts unrelated_backend, not unrelated")
        if "--compatibility-provider" in argv:flag_issues.append("source harness has no --compatibility-provider argument")
    role_ledger.append({"cell_id":c["cell_id"],"program_id":pid,"candidate_id":c["candidate_id"],"role":role,
        "implemented_by_current_producer":c["cell_id"] in old,"explicit_role_predicate":declared,
        "role_acceptance_status":"EVALUATE_FROZEN_ROLE_IF_MEASURED" if declared else "UNRESOLVED_NO_FROZEN_CELL_ROLE_PREDICATE",
        "older_program_memberships":memberships,"measurement_obligation":obligation,
        "exact_argv":argv,"factor_values":inter.get("factor_values"),
        "program_level_provider_capsule_ids":inter.get("provider_capsule_ids",[]),
        "cell_specific_materialization_fields_missing":missing,"harness_contract_issues":flag_issues,
        "source_reference":{"path":"configs/batch102_counterfactual_cell_registry_v4.jsonl","line":i},
        "later_intervention_reference":{"path":intervention_path,"line":i},
        "legacy_boolean_reference":{"path":"scripts/run_batch100_candidate_program.py","lines":[246,267],"status":"candidate/name branch retained as diagnostic only; not used as current v4 semantic authority"}})
write("CELL_ROLE_AND_MATERIALIZATION_LEDGER.json",role_ledger)
write("INVENTORY_SUMMARY.json",{"current_remote_head":HEAD,"source_files":len(manifest),"verified_source_blobs":sum(r['git_blob_verified'] for r in manifest),
    "vendor_files":len(vendor),"programs":len(programs),"registered_cells":len(cells),"producer_cells":len(old),
    "new_cells_not_executed_by_producer":sum(c['cell_id'] not in old for c in cells),
    "roles":dict(collections.Counter(c['cell_role'] for c in cells)),
    "role_predicates_available":sum(r['explicit_role_predicate'] for r in role_ledger),
    "other_role_measurement_obligations":sum(not r['explicit_role_predicate'] for r in role_ledger),
    "missing_cell_specific_provider_id":sum('provider_capsule_id' not in c for c in cells),
    "missing_cell_resource_budget":sum('resource_budget' not in c for c in cells),
    "missing_cell_platform":sum('platform' not in c for c in cells),
    "program_level_provider_ids_retained":True,"harness_flag_incompatibility_cells":sum(bool(r['harness_contract_issues']) for r in role_ledger)})

selections=[
 ("original_raw_extractor","scripts/run_batch100_candidate_program.py",215,267),
 ("original_producer_inventory","scripts/run_batch100_candidate_program.py",278,310),
 ("original_execution_and_raw_receipt","scripts/run_batch100_candidate_program.py",315,369),
 ("original_wrapper_relabelling","scripts/run_batch102_candidate_slice.py",30,65),
 ("prior_Batch101_measurement_repair","scripts/finalize_batch101_public_evidence.py",58,104),
 ("v4_cell_extension_generator","scripts/build_batch102_counterfactual_contracts.py",9,65),
 ("v4_copy_semantics_generator","scripts/build_batch102_counterfactual_contracts.py",75,103),
 ("original_compiler_classification_as_sensitivity","scripts/compile_batch103_public_evidence.py",145,235),
 ("existing_intervention_gates","controllergate/amds/causal_intervention_v12.py",14,65),
 ("actual_audioread_harness","scripts/batch100_audioread_harness.py",1,120),
 ("actual_source_capsule_v2_schema","controllergate/evidence/source_capsule_v2.py",27,77),
]
excerpts=[]
for alias,path,start,end in selections:
    data=(SOURCE/path).read_bytes();lines=data.decode().splitlines();end=min(end,len(lines))
    excerpts.append({"alias":alias,"path":path,"sha256":digest(data),"physical_line_start":start,"physical_line_end":end,
        "numbered_excerpt":"\n".join(f"{i}: {lines[i-1]}" for i in range(start,end+1)),
        "url":f"https://github.com/GenghisDarb/controllergate-research/blob/{HEAD}/{path}"})
write("SOURCE_EXCERPTS.json",excerpts)
(BASE/"SOURCE_EXCERPTS.md").write_text("# Selected original source evidence\n\n"+"\n\n".join(
    f"## {r['alias']}\n\nPath: `{r['path']}`; SHA256 `{r['sha256']}`; physical lines {r['physical_line_start']}–{r['physical_line_end']}.\n\n```text\n{r['numbered_excerpt']}\n```" for r in excerpts)+"\n")

changes=[];patch=[]
for path in sorted(CHECKOUT.rglob("*.py")):
    relative=path.relative_to(CHECKOUT);after=path.read_text();before=(SOURCE/relative).read_text() if (SOURCE/relative).exists() else ""
    if before==after:continue
    changes.append({"path":str(relative),"base_sha256":digest(before.encode()) if before else None,"candidate_sha256":digest(after.encode())})
    patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile="a/"+str(relative) if before else "/dev/null",tofile="b/"+str(relative)))
(BASE/"CONTROLLERGATE_INTEGRATION_CANDIDATE.patch").write_text("".join(patch))
write("PATCH_SOURCE_BINDINGS.json",{"base_head":HEAD,"changes":changes,"remote_applied":False,
    "prior_evidence_modified":False,"tests":"run_integration_checks.py; latest result selected in FINAL_VERIFICATION.json"})
print(json.dumps({"source_files":len(manifest),"vendor_files":len(vendor),"changed_code_files":len(changes),"role_records":len(role_ledger)},indent=2))
