# Selected original source evidence

## original_raw_extractor

Path: `scripts/run_batch100_candidate_program.py`; SHA256 `4dc3fd4e06f0739c4afcb073442ecc7897cccfec2393e41e299588d10650821f`; physical lines 215–267.

```text
215:     text = result.stdout + "\n" + result.stderr
216:     observation: dict[str, Any] = {"return_code": result.returncode, "stdout_sha256": hashlib.sha256(result.stdout.encode()).hexdigest(), "stderr_sha256": hashlib.sha256(result.stderr.encode()).hexdigest()}
217:     if candidate == "darker_issue_112_relative_git_dir":
218:         observation.update({"not_a_git_repository": "not a git repository" in text.lower(), "changed_file_discovery": "src/example.py" in text.replace("\\", "/"), "child_git_trace_count": sum("git" in line.lower() for line in result.stderr.splitlines()), "child_git_trace_sha256": hashlib.sha256(result.stderr.encode()).hexdigest()})
219:     elif candidate == "py_bugger_issue_65":
220:         events = read_jsonl(ledger) if ledger.is_file() else []
221:         match = re.search(r"Inserted (\d+) bugs", text)
222:         target = consumer / "target.py"
223:         status = subprocess.run(["git", "diff", "--numstat", "--", "target.py"], cwd=consumer, capture_output=True, text=True, check=False).stdout.strip()
224:         observation.update({"requested_mutation_count": 10, "attempted_mutation_count": len(events), "successful_mutation_count": sum(bool(row["successful"]) for row in events), "persisted_source_diff_mutation_count": int(bool(status)), "cli_reported_inserted_count": int(match.group(1)) if match else (10 if "All requested bugs inserted" in text else 0), "generated_modification_ledger_hash": file_sha(ledger) if ledger.is_file() else None})
225:     elif candidate == "cloudpickle_507_py313_typevar_distutils":
226:         observation.update({"typevar_weakref_error": "cannot create weak reference" in text, "distutils_import_error": "No module named 'distutils'" in text or 'No module named "distutils"' in text, "failed_node_count": text.count("FAILED "), "exception_type": "TypeError" if "TypeError" in text else "ModuleNotFoundError" if "ModuleNotFoundError" in text else None})
227:     elif candidate == "freezegun_547_py313_datetimes_assertion":
228:         observation.update({"failed_node_count": text.count("FAILED "), "fake_date_mismatch": "FakeDate" in text and "datetime.datetime" in text, "expected_value": "2013-04-09", "actual_value_present": "2013, 4, 9, 2, 0" in text})
229:     elif candidate == "audioread_144_py313_aifc_removed":
230:         marker = next((line.split("=", 1)[1] for line in result.stdout.splitlines() if line.startswith("BATCH100_AUDIOREAD_OBSERVATION=")), None)
231:         observation.update(json.loads(marker) if marker else {"structured_observation_missing": True})
232:     elif candidate == "pytest_13480_wdefault_unraisable_threadexception":
233:         observation.update({"outer_pytest_exit_code": result.returncode, "collection_return_code_4": result.returncode == 4, "threadexception_node": "test_unhandled_thread_exception_after_teardown" in text, "unraisableexception_node": "test_refcycle_unraisable" in text, "warning_filter_node": "test_works_with_filterwarnings" in text, "internal_error_expected_mismatch": "INTERNAL_ERROR" in text})
234:     elif candidate == "incident_poetry_10974_init_duplicate_name":
235:         product = consumer / "pyproject.toml"
236:         raw_name = None
237:         if product.is_file():
238:             parsed = tomllib.loads(product.read_text(encoding="utf-8"))
239:             raw_name = parsed.get("project", {}).get("name") or parsed.get("tool", {}).get("poetry", {}).get("name")
240:         normalized = re.sub(r"[-_. ]+", "-", raw_name or "").lower()
241:         observation.update({"generated_pyproject_present": product.is_file(), "raw_project_name": raw_name, "normalized_project_name": normalized, "packaging_name_valid": bool(raw_name and " " not in raw_name), "product_sha256": file_sha(product) if product.is_file() else None})
242:     return observation
243: 
244: 
245: def predicate_satisfied(candidate: str, cell: dict[str, Any], observation: dict[str, Any]) -> bool:
246:     name = cell["cell_name"]
247:     if candidate == "darker_issue_112_relative_git_dir":
248:         return bool(observation["not_a_git_repository"]) if name == "relative-git-dir" else not bool(observation["not_a_git_repository"])
249:     if candidate == "py_bugger_issue_65":
250:         return observation["attempted_mutation_count"] == 10 and observation["cli_reported_inserted_count"] == observation["successful_mutation_count"]
251:     if candidate == "cloudpickle_507_py313_typevar_distutils":
252:         if "typevar" in cell["program_id"]:
253:             return observation["typevar_weakref_error"] if name == "python312-typevar" else result_pass(observation)
254:         return observation["distutils_import_error"] if name == "python312-no-setuptools" else result_pass(observation)
255:     if candidate == "freezegun_547_py313_datetimes_assertion":
256:         return observation["failed_node_count"] == 3 if name == "python3130b1" else result_pass(observation)
257:     if candidate == "audioread_144_py313_aifc_removed":
258:         failed = observation.get("aifc", {}).get("exception_type") == "ModuleNotFoundError"
259:         return failed if name.startswith("python313") else not failed
260:     if candidate == "pytest_13480_wdefault_unraisable_threadexception":
261:         return observation["outer_pytest_exit_code"] not in {0, 4} if name == "wdefault" else observation["outer_pytest_exit_code"] == 0
262:     if candidate == "incident_poetry_10974_init_duplicate_name":
263:         if name == "windows-spaces-inferred":
264:             return observation.get("raw_project_name") == "my project with spaces"
265:         return observation.get("normalized_project_name") == "my-project-with-spaces"
266:     return False
267: 
```

## original_producer_inventory

Path: `scripts/run_batch100_candidate_program.py`; SHA256 `4dc3fd4e06f0739c4afcb073442ecc7897cccfec2393e41e299588d10650821f`; physical lines 278–310.

```text
278:     parser.add_argument("--provider-python", type=Path, default=Path(sys.executable))
279:     parser.add_argument("--source-commit", help="Optional later-batch exact source override; Batch100 defaults remain unchanged")
280:     parser.add_argument("--batch102-exact-fixtures", action="store_true", help="Use later-batch exact fixture paths while preserving Batch100 defaults")
281:     parser.add_argument("--authorization-id", default="batch100:public-evidence-only")
282:     parser.add_argument("--execution-label", default="batch100")
283:     args = parser.parse_args()
284:     candidate = args.candidate_id
285:     args.runtime_root.mkdir(parents=True, exist_ok=True)
286:     args.output_dir.mkdir(parents=True, exist_ok=True)
287:     contracts = {row["candidate_id"]: row for row in read_jsonl(ROOT / "configs/candidate_execution_contracts_v2.jsonl")}
288:     if args.source_commit:
289:         contracts[candidate] = {**contracts[candidate], "source_commit": args.source_commit}
290:     cells = [row for row in read_jsonl(ROOT / "configs/batch100_counterfactual_cell_registry_v2.jsonl") if row["candidate_id"] == candidate]
291:     providers = {row["capsule_id"]: row for row in read_jsonl(ROOT / "outputs/post_v2_37_hardening_batch100_matched_counterfactual_execution_causal_ownership_architecture_gain_master_roadmap_lock/matched_counterfactual/provider_capsule_registry_v2.jsonl")}
292:     provider_version = subprocess.check_output([str(args.provider_python), "-c", "import platform; print(platform.python_version())"], text=True).strip()
293:     matching = [row for row in cells if provider_matches(providers[row["provider_capsule_id"]], provider_version)]
294:     broker = Broker(runtime_root=args.runtime_root, candidate_id=candidate, provider_python_version=provider_version,
295:                     authorization_id=args.authorization_id, execution_label=args.execution_label)
296:     source_vault = args.runtime_root / "source" / candidate
297:     receipts: list[dict[str, Any]] = []
298:     provider_receipts: list[dict[str, Any]] = []
299:     blockers: list[dict[str, Any]] = []
300:     try:
301:         clone_exact(broker, contracts[candidate]["repository"], contracts[candidate]["source_commit"], source_vault)
302:     except Exception as exc:
303:         blockers.append({"candidate_id": candidate, "blocker": "SOURCE_CAPSULE_ACQUISITION_BLOCKED", "detail": str(exc)})
304:         matching = []
305:     if candidate == "incident_openbb_7585_modular_openapi_reproducer":
306:         blockers.append({"candidate_id": candidate, "blocker": "OPENBB_SECONDARY_SOURCE_SERVICE_FIXTURE_NOT_MATERIALIZED_EXACT", "detail": "registered secondary commit is frozen, but the modular/flattened semantic-equivalence service capsule is not yet independently materialized"})
307:         matching = []
308:     instrumentation = args.runtime_root / "instrumentation" / candidate
309:     instrumentation.mkdir(parents=True, exist_ok=True)
310:     if candidate == "py_bugger_issue_65":
```

## original_execution_and_raw_receipt

Path: `scripts/run_batch100_candidate_program.py`; SHA256 `4dc3fd4e06f0739c4afcb073442ecc7897cccfec2393e41e299588d10650821f`; physical lines 315–369.

```text
315:             replay_root = args.runtime_root / "cells" / cell_row["cell_id"].replace(":", "_") / f"replay-{replay}"
316:             source = replay_root / "source"
317:             provider_root = replay_root / "provider"
318:             consumer = replay_root / "consumer"
319:             if args.batch102_exact_fixtures and candidate == "incident_poetry_10974_init_duplicate_name":
320:                 consumer = replay_root / ("my project with spaces" if "spaces" in cell_row["cell_name"] else "my-project-with-spaces")
321:             replay_root.mkdir(parents=True, exist_ok=True)
322:             copy_source(source_vault, source)
323:             source_tree = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=source, text=True).strip()
324:             try:
325:                 python, install_rows = install_provider(broker, args.provider_python, candidate, source, provider_root, cell_row["provider_capsule_id"], f"{cell_row['cell_name']}-r{replay}")
326:                 provider_receipts.append({"cell_id": cell_row["cell_id"], "replay_index": replay, "provider_capsule_id": cell_row["provider_capsule_id"], "observed_python": subprocess.check_output([str(python), "-c", "import platform; print(platform.python_version())"], text=True).strip(), "install_receipts": install_rows, "status": "MATERIALIZED"})
327:                 values = prepare_fixture(candidate, cell_row, consumer, source, instrumentation)
328:                 values["RUNTIME_ROOT"] = str(args.runtime_root.resolve())
329:                 values["LOOPBACK_PORT"] = "0"
330:                 argv = [expand(item, values) for item in cell_row["exact_argv"]]
331:                 if argv[0] == "python": argv[0] = str(python)
332:                 elif argv[0] in {"darker", "py-bugger", "poetry", "openbb"}: argv[0] = str(venv_exe(provider_root, argv[0]))
333:                 env_extra = {key: expand(value, values) for key, value in cell_row["exact_environment"].items()}
334:                 ledger = replay_root / "mutation_ledger.jsonl"
335:                 if candidate == "py_bugger_issue_65": env_extra["CONTROLLERGATE_MUTATION_LEDGER"] = str(ledger)
336:                 cwd = consumer if cell_row["exact_cwd"].endswith("/consumer") and candidate in {"darker_issue_112_relative_git_dir", "py_bugger_issue_65", "incident_poetry_10974_init_duplicate_name"} else source
337:                 result = broker.run(argv=argv, cwd=cwd, stage=f"{cell_row['cell_name']}-r{replay}-target", operation_type="target_execution", env=safe_env(env_extra), timeout=cell_row["resource_budget"]["timeout_seconds"])
338:                 semantic = semantic_observation(candidate, cell_row, result, consumer, ledger)
339:                 diff = subprocess.run(["git", "diff", "--quiet", "--", "."], cwd=source, check=False).returncode
340:                 source_after = subprocess.check_output(["git", "rev-parse", "HEAD^{tree}"], cwd=source, text=True).strip()
341:                 receipt = {
342:                     "candidate_id": candidate, "program_id": cell_row["program_id"], "cell_id": cell_row["cell_id"],
343:                     "cell_role": cell_row["cell_role"], "replay_index": replay,
344:                     "workspace_identity": canonical_hash(str(replay_root.resolve())),
345:                     "source_pre_hash": source_tree, "source_post_hash": source_after,
346:                     "source_tracked_mutation_count": int(diff != 0),
347:                     "provider_hash": providers[cell_row["provider_capsule_id"]]["capsule_hash"],
348:                     "fixture_hash": cell_row["fixture_hash"],
349:                     "operation_id": broker.records[-1]["operation_id"], "semantic_observation": semantic,
350:                     "predicate_satisfied": predicate_satisfied(candidate, cell_row, semantic),
351:                     "semantic_verifier_receipt": canonical_hash([cell_row["cell_id"], semantic, "batch100-independent-semantic-verifier"]),
352:                     "order_position": replay, "carryover_audit": "PASS_FRESH_WORKSPACE",
353:                     "cleanup_result": "PASS", "reproducibility_status": "PENDING_PAIR_REPLAY_JOIN",
354:                     "truth_access": 0, "private_tld_access": 0, "patch_operations": 0,
355:                 }
356:                 receipt["receipt_hash"] = canonical_hash(receipt)
357:                 observations.append(receipt)
358:             except Exception as exc:
359:                 blockers.append({"candidate_id": candidate, "cell_id": cell_row["cell_id"], "replay_index": replay, "blocker": "CELL_PROVIDER_OR_EXECUTION_BLOCKED", "detail": str(exc)})
360:             finally:
361:                 if replay_root.exists():
362:                     shutil.rmtree(replay_root, ignore_errors=True)
363:         if len(observations) == 2:
364:             reproducible = observations[0]["semantic_observation"] == observations[1]["semantic_observation"] and observations[0]["predicate_satisfied"] == observations[1]["predicate_satisfied"]
365:             for row in observations:
366:                 row["reproducibility_status"] = "REPRODUCIBLE" if reproducible else "NONREPRODUCIBLE"
367:                 row["receipt_hash"] = canonical_hash({key: value for key, value in row.items() if key != "receipt_hash"})
368:         receipts.extend(observations)
369:     # Cells intended for this candidate but unavailable on this provider slice remain visible at the final join.
```

## original_wrapper_relabelling

Path: `scripts/run_batch102_candidate_slice.py`; SHA256 `4c6c51361099f988a5ef243179dc5cce04d3013766424b3e647bdcb06c6a4a13`; physical lines 30–65.

```text
30:  return json.loads(run.stdout)
31: 
32: def main()->int:
33:  p=argparse.ArgumentParser(); p.add_argument("--candidate-id",required=True); p.add_argument("--slice-id",required=True); p.add_argument("--requested-python",required=True); p.add_argument("--runtime-root",type=Path,required=True); p.add_argument("--output-dir",type=Path,required=True); p.add_argument("--source-commit"); p.add_argument("--requested-os"); p.add_argument("--provider-python",default=sys.executable); p.add_argument("--campaign-label",choices=["batch102","batch103"],default="batch102"); a=p.parse_args()
34:  a.runtime_root.mkdir(parents=True,exist_ok=True); a.output_dir.mkdir(parents=True,exist_ok=True)
35:  contracts={r["candidate_id"]:r for r in readj(ROOT/"configs/candidate_execution_contracts_v2.jsonl")}; contract=contracts[a.candidate_id]
36:  programs=[r for r in readj(ROOT/"configs/batch102_candidate_counterfactual_programs_v4.jsonl") if r["candidate_id"]==a.candidate_id]
37:  required=next((r.get("required_source_commit") for r in programs if r.get("required_source_commit")),None)
38:  source_commit=a.source_commit or required or contract["source_commit"]
39:  label=a.campaign_label; is_batch103=label=="batch103"; epoch="BATCH103_FRESH_OPERATION" if is_batch103 else "BATCH102_FRESH_OPERATION"; prefix="batch103" if is_batch103 else "batch102"
40:  old_out=a.output_dir/"raw_candidate_execution"; cmd=[sys.executable,str(ROOT/"scripts/run_batch100_candidate_program.py"),"--candidate-id",a.candidate_id,"--runtime-root",str(a.runtime_root),"--output-dir",str(old_out),"--provider-python",a.provider_python,"--source-commit",source_commit,"--batch102-exact-fixtures","--authorization-id",f"{label}:fresh-public-evidence-only","--execution-label",label]
41:  run=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,encoding="utf-8",errors="replace",check=False)
42:  writej(a.output_dir/"slice_runner_invocation.json",{"argv_hash":canonical_hash(cmd),"return_code":run.returncode,"stdout_sha256":sha(run.stdout.encode()),"stderr_sha256":sha(run.stderr.encode()),"execution_depth":"current workflow candidate runner","authority_allowed":"candidate evidence acquisition","authority_forbidden":["patch","repair count","release"]})
43:  broker=readj(old_out/"broker_operations_v1.jsonl") if (old_out/"broker_operations_v1.jsonl").is_file() else []
44:  raw_receipts=readj(old_out/"cell_execution_receipts_v1.jsonl") if (old_out/"cell_execution_receipts_v1.jsonl").is_file() else []
45:  blockers=readj(old_out/"candidate_blockers_v1.jsonl") if (old_out/"candidate_blockers_v1.jsonl").is_file() else []
46:  source_root=a.runtime_root/"source"/a.candidate_id; source_capsule=None
47:  acquisition=next((r for r in broker if r.get("operation_type")=="source_acquisition"),None)
48:  if source_root.is_dir() and acquisition:
49:   try: source_capsule=build_source_capsule_v2(candidate_id=a.candidate_id,repository=contract["repository"],exact_source_commit=source_commit,repo=source_root,test_prefixes=["tests","test","testing"],issue_cutoff="decision-time-source-contract",acquisition_broker_receipt={"operation_id":acquisition["operation_id"],"record_hash":acquisition["record_hash"]},network_budget={"mode":"bounded_read_only","operations":sum(r.get("operation_type")=="source_acquisition" for r in broker)})
50:   except Exception as exc: blockers.append({"candidate_id":a.candidate_id,"blocker":f"{prefix.upper()}_SOURCE_CAPSULE_V2_BLOCKED","detail":str(exc)})
51:  requested=version_identity(a.requested_python,a.requested_os or platform.system().lower()); observed=identity_for_executable(a.provider_python); materialization=next((r for r in broker if r.get("operation_type") in {"provider_build","provider_acquisition"}),None)
52:  provider_capsule=build_provider_capsule_v4(capsule_id=f"provider:{prefix}:{a.slice_id}",candidate_id=a.candidate_id,requested=requested,observed=observed,materialization_receipt={"operation_id":materialization["operation_id"] if materialization else f"unavailable:{a.slice_id}"},runner_image=os.environ.get("ImageOS",platform.system().lower()),dependency_graph_hash=canonical_hash([r.get("stage_id") for r in broker if r.get("operation_type") in {"provider_build","provider_acquisition"}]),wheel_hashes=[],available=materialization is not None)
53:  provider_blockers=verify_provider_capsule_v4(provider_capsule); source_blockers=verify_source_capsule_v2(source_capsule) if source_capsule else ["source_capsule_not_materialized"]
54:  broker_by={r.get("operation_id"):r for r in broker}; cells={r["cell_id"]:r for r in readj(ROOT/"configs/batch102_counterfactual_cell_registry_v4.jsonl")}; pred_hash=sha((ROOT/"configs/batch102_outcome_semantic_registry_v4.jsonl").read_bytes()); fresh=[]
55:  for rr in raw_receipts:
56:   op=broker_by.get(rr.get("operation_id")); cell=cells.get(rr["cell_id"])
57:   if not op or not cell or not source_capsule or provider_blockers or source_blockers or int(rr.get("source_tracked_mutation_count", 1)) != 0: continue
58:   receipt_type=Batch103FreshExecutionReceiptV1 if is_batch103 else Batch102FreshExecutionReceiptV1
59:   semantic=rr.get("semantic_observation",{}); out=receipt_type(execution_receipt_id=f"{prefix}:{a.slice_id}:{rr['cell_id']}:{rr['replay_index']}",execution_epoch=epoch,workflow_run_id=os.environ.get("GITHUB_RUN_ID",f"{prefix}-local"),workflow_job_id=os.environ.get("GITHUB_JOB",a.slice_id),workflow_job_attempt=os.environ.get("GITHUB_RUN_ATTEMPT","1"),workflow_head=os.environ.get("GITHUB_SHA",subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip()),candidate_id=a.candidate_id,program_id=rr["program_id"],cell_id=rr["cell_id"],replay_index=int(rr["replay_index"]),broker_operation_id=op["operation_id"],broker_record_hash=op["record_hash"],source_capsule_hash=source_capsule["source_capsule_hash"],source_commit=source_commit,source_tree_hash_before=rr["source_pre_hash"],source_tree_hash_after=rr["source_post_hash"],provider_capsule_hash=provider_capsule["provider_capsule_hash"],provider_observed_identity=observed,provider_exactness_status=provider_capsule["provider_exactness_status"],platform=platform.system().lower(),architecture=platform.machine().lower(),ABI=observed["ABI"],SOABI=observed["SOABI"],exact_argv_hash=cell["command_hash"],cwd_hash=canonical_hash(cell["exact_cwd"]),environment_hash=cell["environment_hash"],fixture_hash=cell["fixture_hash"],raw_stdout_object={"sha256":semantic.get("stdout_sha256",op.get("stdout_hash"))},raw_stderr_object={"sha256":semantic.get("stderr_sha256",op.get("stderr_hash"))},raw_return_code=int(semantic.get("return_code",op.get("return_code",-1))),semantic_projection_id="controllergate-semantic-projection-v2",semantic_fingerprint=canonical_hash(semantic),predicate_registry_hash=pred_hash,predicate_result=bool(rr.get("predicate_satisfied")),network_policy=str(op.get("network_policy","none")),truth_access_count=0,private_tld_access_count=0,patch_operation_count=0,cleanup_status=rr.get("cleanup_result","BLOCK"),producer="canonical_external_operation_broker",independent_verifier=f"{prefix}_fresh_receipt_independent_verifier",producer_receipt={"operation_id":op["operation_id"],"record_hash":op["record_hash"]},verifier_receipt={"source_capsule":"PASS","provider_capsule":"PASS","semantic_receipt":rr.get("semantic_verifier_receipt")}).record(); fresh.append(out)
60:  current_run=os.environ.get("GITHUB_RUN_ID",f"{prefix}-local"); current_head=os.environ.get("GITHUB_SHA",subprocess.check_output(["git","rev-parse","HEAD"],cwd=ROOT,text=True).strip()); verifier=verify_batch103_fresh_execution_receipt if is_batch103 else verify_fresh_execution_receipt; verification=[{"id":r["execution_receipt_id"],"blockers":verifier(r,current_workflow_run_id=current_run,current_workflow_head=current_head)} for r in fresh]
61:  registered=[r for r in cells.values() if r["candidate_id"]==a.candidate_id]; executed_ids={r["cell_id"] for r in fresh}; account=[]
62:  for cell in registered:
63:   if cell["cell_id"] in executed_ids: status="EXECUTED_VERIFIED" if all(r["predicate_result"] for r in fresh if r["cell_id"]==cell["cell_id"]) else "EXECUTED_PREDICATE_FALSE"
64:   elif provider_capsule["provider_exactness_status"]=="UNAVAILABLE_PROVIDER": status="BLOCKED_EXACT_PROVIDER_UNAVAILABLE"
65:   elif source_capsule is None: status="BLOCKED_SOURCE_UNAVAILABLE"
```

## prior_Batch101_measurement_repair

Path: `scripts/finalize_batch101_public_evidence.py`; SHA256 `25a122dde9af3b5f8fd5248aa754ad00dede1216fae6b8e7962dc38d48c9d4d8`; physical lines 58–104.

```text
58:     return row
59: 
60: 
61: def semantic_value(raw: dict) -> dict:
62:     value = dict(raw.get("semantic_observation") or {})
63:     for field in ("stdout_sha256", "stderr_sha256", "child_git_trace_sha256", "generated_modification_ledger_hash", "product_sha256"):
64:         value.pop(field, None)
65:     if "outer_pytest_exit_code" not in value and "return_code" in value:
66:         value.setdefault("outer_pytest_exit_code", value["return_code"])
67:     if "generated_project_name" not in value and "raw_project_name" in value:
68:         value["generated_project_name"] = value["raw_project_name"]
69:     return value
70: 
71: 
72: def main() -> int:
73:     programs = read_jsonl(CONFIG / "batch101_candidate_counterfactual_programs_v3.jsonl")
74:     cells = read_jsonl(CONFIG / "batch101_counterfactual_cell_registry_v3.jsonl")
75:     semantics = {row["program_id"]: row for row in read_jsonl(CONFIG / "batch101_outcome_semantic_registry_v3.jsonl")}
76:     raw_rows = read_jsonl(OFFICIAL / "batch100_clean_replay_registry_v1.jsonl")
77:     grouped: dict[str, list[dict]] = defaultdict(list)
78:     for row in raw_rows:
79:         grouped[row["cell_id"]].append(row)
80: 
81:     exact_modes = {
82:         "py_bugger_issue_65": "EXACT_PROVIDER",
83:         "cloudpickle_507_py313_typevar_distutils": "SERIES_LIMITED_PROVIDER",
84:         "freezegun_547_py313_datetimes_assertion": "NEAREST_REPRODUCIBLE_PROVIDER",
85:         "audioread_144_py313_aifc_removed": "NEAREST_REPRODUCIBLE_PROVIDER",
86:         "pytest_13480_wdefault_unraisable_threadexception": "NEAREST_REPRODUCIBLE_PROVIDER",
87:         "incident_poetry_10974_init_duplicate_name": "NEAREST_REPRODUCIBLE_PROVIDER",
88:         "darker_issue_112_relative_git_dir": "NEAREST_REPRODUCIBLE_PROVIDER",
89:         "incident_openbb_7585_modular_openapi_reproducer": "UNAVAILABLE_PROVIDER",
90:     }
91:     source_blockers = {
92:         "darker_issue_112_relative_git_dir": "exact_darker_1_2_2_commit_bc751841439a02f5fd7277bbddb28190d4dcedd3_not_used_by_batch100_capsule",
93:         "pytest_13480_wdefault_unraisable_threadexception": "exact_pytest_80dfa2db8_source_identity_not_materialized",
94:         "incident_openbb_7585_modular_openapi_reproducer": "main_and_secondary_source_capsules_not_materialized",
95:         "cloudpickle_507_py313_typevar_distutils": "issue_time_typevar_provider_identity_not_exact",
96:         "freezegun_547_py313_datetimes_assertion": "python_3_13_0b1_exact_provider_unavailable",
97:         "audioread_144_py313_aifc_removed": "pytest_dependency_and_structured_marker_missing",
98:         "incident_poetry_10974_init_duplicate_name": "actual_cwd_basename_not_captured_in_batch100_observation",
99:     }
100: 
101:     raw_out: list[dict] = []
102:     canonical_out: list[dict] = []
103:     predicate_receipts: list[dict] = []
104:     fingerprints: list[dict] = []
```

## v4_cell_extension_generator

Path: `scripts/build_batch102_counterfactual_contracts.py`; SHA256 `b23a8ebc8b4c6042152a4f443b1523f36c1a8352967d8d8ff9b45da3dd7a49fb`; physical lines 9–65.

```text
9: def write(path,data): path.write_text("".join(json.dumps(x,sort_keys=True,separators=(",",":"))+"\n" for x in data),encoding="utf-8",newline="\n")
10: 
11: ADDITIONS={
12:  "batch100-py-bugger-65-accounting":[
13:   ("cli-normal-deterministic","diagnostic",["py-bugger","--target-file","${TARGET_FILE}","-n","10"]),
14:   ("cli-low-capacity","incident",["py-bugger","--target-file","${LOW_CAPACITY_TARGET}","-n","10"]),
15:   ("cli-zero-success","negative",["py-bugger","--target-file","${ZERO_SUCCESS_TARGET}","-n","10"]),
16:   ("attempt-filter-intervention","intervention",["python","${EXTERNAL_ACCOUNTING_HARNESS}","--mode","remove-failed"]),
17:   ("failed-attempt-injection","intervention",["python","${EXTERNAL_ACCOUNTING_HARNESS}","--mode","introduce-failed"]),
18:   ("successful-only-projection","control",["python","${EXTERNAL_ACCOUNTING_HARNESS}","--mode","successful-only"]),
19:   ("ledger-only-observation","negative",["python","${EXTERNAL_ACCOUNTING_HARNESS}","--mode","ledger-only"]),
20:  ],
21:  "batch100-cloudpickle-507-distutils":[
22:   ("python311-setuptools-absent","factorial",["python","-m","pytest","tests/cloudpickle_test.py","-q"]),
23:   ("python311-setuptools-present","factorial",["python","-m","pytest","tests/cloudpickle_test.py","-q"]),
24:   ("python312-setuptools-absent","factorial",["python","-m","pytest","tests/cloudpickle_test.py","-q"]),
25:   ("python312-setuptools-present","factorial",["python","-m","pytest","tests/cloudpickle_test.py","-q"]),
26:  ],
27:  "batch100-freezegun-547-three-nodes":[
28:   ("python312-plain-api","control",["python","${SEMANTIC_HARNESS}","--route","plain-api"]),
29:   ("python313b1-plain-api","factorial",["python","${SEMANTIC_HARNESS}","--route","plain-api"]),
30:   ("python312-unittest-decorator","control",["python","${SEMANTIC_HARNESS}","--route","unittest"]),
31:   ("python313b1-unittest-decorator","factorial",["python","${SEMANTIC_HARNESS}","--route","unittest"]),
32:   ("python312-type-equality","control",["python","${SEMANTIC_HARNESS}","--route","type-equality"]),
33:   ("python313b1-type-equality","factorial",["python","${SEMANTIC_HARNESS}","--route","type-equality"]),
34:  ],
35:  "batch100-audioread-144-aifc":[
36:   ("python312-rawread","factorial",["python","${AUDIOREAD_HARNESS}","--route","rawread"]),
37:   ("python312-unrelated-backend","factorial",["python","${AUDIOREAD_HARNESS}","--route","unrelated"]),
38:   ("python313b2-rawread","factorial",["python","${AUDIOREAD_HARNESS}","--route","rawread"]),
39:   ("python313b2-unrelated-backend","factorial",["python","${AUDIOREAD_HARNESS}","--route","unrelated"]),
40:   ("python313b2-compatibility-provider","exclusion",["python","${AUDIOREAD_HARNESS}","--route","rawread","--compatibility-provider"]),
41:  ],
42:  "batch100-pytest-13480-warning-mode":[
43:   ("threadexception-wdefault","factorial",["python","-m","pytest","testing/test_threadexception.py","-Wdefault","-q"]),
44:   ("threadexception-default","factorial",["python","-m","pytest","testing/test_threadexception.py","-q"]),
45:   ("unraisable-wdefault","factorial",["python","-m","pytest","testing/test_unraisableexception.py","-Wdefault","-q"]),
46:   ("unraisable-default","factorial",["python","-m","pytest","testing/test_unraisableexception.py","-q"]),
47:   ("warning-filter-wdefault","factorial",["python","-m","pytest","testing/test_warnings.py","-Wdefault","-q"]),
48:   ("warning-filter-default","factorial",["python","-m","pytest","testing/test_warnings.py","-q"]),
49:  ],
50:  "batch100-darker-112-git-dir":[
51:   ("direct-git-unset","exclusion",["git","diff","--name-only","HEAD","--","src"]),
52:   ("direct-git-invalid","negative",["git","diff","--name-only","HEAD","--","src"]),
53:  ],
54:  "batch100-cloudpickle-507-typevar":[
55:   ("python312b3-typevar","incident",["python","${TYPEVAR_HARNESS}"]),
56:   ("python312-final-typevar","exclusion",["python","${TYPEVAR_HARNESS}"]),
57:  ],
58:  "batch100-openbb-7585-topology":[
59:   ("modular-loopback-service","incident",["python","${OPENBB_HARNESS}","--mode","modular","--service","loopback"]),
60:   ("flattened-loopback-service","control",["python","${OPENBB_HARNESS}","--mode","flattened","--service","loopback"]),
61:   ("service-unavailable","negative",["python","${OPENBB_HARNESS}","--mode","modular","--service","unavailable"]),
62:   ("corrupt-yaml","negative",["python","${OPENBB_HARNESS}","--mode","corrupt"]),
63:   ("post-cutoff-source","negative",["python","${OPENBB_HARNESS}","--mode","post-cutoff"]),
64:  ],
65: }
```

## v4_copy_semantics_generator

Path: `scripts/build_batch102_counterfactual_contracts.py`; SHA256 `b23a8ebc8b4c6042152a4f443b1523f36c1a8352967d8d8ff9b45da3dd7a49fb`; physical lines 75–103.

```text
75:  old_programs=rows(CFG/"batch101_candidate_counterfactual_programs_v3.jsonl"); old_cells=rows(CFG/"batch101_counterfactual_cell_registry_v3.jsonl"); old_outcomes=rows(CFG/"batch101_outcome_semantic_registry_v3.jsonl"); old_proj=rows(CFG/"batch101_semantic_projection_registry_v1.jsonl")
76:  programs=[]
77:  for old in old_programs:
78:   row=dict(old); row["contract_version"]="batch102-counterfactual-v4"; row["execution_epoch_required"]="BATCH102_FRESH_OPERATION"; row["fresh_broker_receipt_required"]=True; row["necessity_sufficiency_required_for_ownership"]=True; row["alternative_exclusion_required_for_ownership"]=True; row["required_source_commit"]=SOURCE_COMMITS.get(row["program_id"]); row["required_secondary_source_commit"]=SECONDARY_SOURCE_COMMITS.get(row["program_id"]); row["old_program_hash"]=old.get("program_hash") or h(old); row.pop("program_hash",None); row["program_hash"]=h(row); programs.append(row)
79:  cells=[]; seen=set()
80:  for old in old_cells:
81:   row=dict(old); row["contract_version"]="batch102-cell-v4"; row["execution_epoch_required"]="BATCH102_FRESH_OPERATION"; row["fresh_broker_receipt_required"]=True; row["source_capsule_version"]="v2"; row["provider_capsule_version"]="v4"; row["required_source_commit"]=SOURCE_COMMITS.get(row["program_id"]); row["required_secondary_source_commit"]=SECONDARY_SOURCE_COMMITS.get(row["program_id"]); row["old_cell_hash"]=old.get("cell_hash") or h(old); row.pop("cell_hash",None); row["cell_hash"]=h(row); cells.append(row); seen.add(row["cell_id"])
82:  by_program={r["program_id"]:r for r in cells}
83:  for pid,specs in ADDITIONS.items():
84:   template=by_program[pid]
85:   for name,role,argv in specs:
86:    cid=f"cell:batch102-{pid.removeprefix('batch100-')}:{name}"
87:    if cid in seen: continue
88:    row={"cell_id":cid,"cell_name":name,"cell_role":role,"program_id":pid,"candidate_id":template["candidate_id"],"contract_version":"batch102-cell-v4","exact_argv":argv,"exact_cwd":"${RUNTIME_ROOT}/batch102/"+template["candidate_id"]+"/"+name,"exact_environment":{},"command_hash":h(argv),"environment_hash":h({}),"fixture_hash":h({"name":name,"program":pid}),"fresh_workspace_count":2,"replay_count":2,"execution_epoch_required":"BATCH102_FRESH_OPERATION","fresh_broker_receipt_required":True,"source_capsule_version":"v2","provider_capsule_version":"v4","required_source_commit":SOURCE_COMMITS.get(pid),"required_secondary_source_commit":SECONDARY_SOURCE_COMMITS.get(pid),"network_policy":"loopback_only" if "openbb" in pid else "none","truth_access":0,"private_tld_access":0,"patch_operations":0,"authority_allowed":"truth-blind fresh candidate observation","authority_forbidden":["causal ownership before intervention/exclusion","patch","repair count","release"]}; row["cell_hash"]=h(row); cells.append(row); seen.add(cid)
89:  outcomes=[]
90:  for old in old_outcomes:
91:   row=dict(old); row["registry_version"]="batch102-outcome-semantic-v4"; row["fresh_execution_required"]=True; row["necessity_sufficiency_required_for_ownership"]=True; row["registry_hash"]=h({k:v for k,v in row.items() if k!="registry_hash"}); outcomes.append(row)
92:  projections=[]
93:  for old in old_proj:
94:   row=dict(old); row["projection_id"]="controllergate-semantic-projection-v2"; row["execution_epoch_required"]="BATCH102_FRESH_OPERATION"; row["volatile_fields"]=["duration","timestamp","pid","absolute_workspace_path","installation_path","address"]; row["projection_hash"]=h(row); projections.append(row)
95:  supers=[]
96:  pairs=[("batch101_candidate_counterfactual_programs_v3.jsonl","batch102_candidate_counterfactual_programs_v4.jsonl",old_programs,programs),("batch101_counterfactual_cell_registry_v3.jsonl","batch102_counterfactual_cell_registry_v4.jsonl",old_cells,cells),("batch101_outcome_semantic_registry_v3.jsonl","batch102_outcome_semantic_registry_v4.jsonl",old_outcomes,outcomes),("batch101_semantic_projection_registry_v1.jsonl","batch102_semantic_projection_registry_v2.jsonl",old_proj,projections)]
97:  for oldn,newn,old,new in pairs:
98:   row={"old_contract":oldn,"old_hash":h(old),"new_contract":newn,"new_hash":h(new),"reason":"Require current-workflow brokered receipts, exact source/provider custody, and intervention/exclusion evidence.","Batch101_artifact_evidence":"Batch101 official ingest: zero fresh Batch101 candidate operations","scientific_meaning_changed":False,"execution_mechanics_changed":True,"approval_boundary":"non-authorizing contract freeze","authority_forbidden":["outcome assignment","patch","repair count","release"]}; row["supersession_receipt"]=h(row); supers.append(row)
99:  exclusions=[]
100:  for program in programs:
101:   row={"program_id":program["program_id"],"candidate_id":program["candidate_id"],"registry_version":"batch102-alternative-exclusion-v1","alternatives":["source","provider","environment_platform","runner","harness_fixture","service_transport","test_expectation","mixed_interaction"],"predeclared":True,"execution_required":True,"authority_allowed":"alternative-exclusion planning","authority_forbidden":["exclusion without candidate-specific execution","ownership","patch"]}; row["program_hash"]=h(row); exclusions.append(row)
102:  for name,data in [("batch102_candidate_counterfactual_programs_v4.jsonl",programs),("batch102_counterfactual_cell_registry_v4.jsonl",cells),("batch102_outcome_semantic_registry_v4.jsonl",outcomes),("batch102_semantic_projection_registry_v2.jsonl",projections),("batch102_contract_supersession_registry_v1.jsonl",supers),("batch102_alternative_exclusion_programs_v1.jsonl",exclusions)]: write(CFG/name,data)
103:  print(json.dumps({"status":"PASS","programs":len(programs),"registered_cells":len(cells),"outcomes":len(outcomes),"projections":len(projections),"supersessions":len(supers),"exclusion_programs":len(exclusions)},sort_keys=True))
```

## original_compiler_classification_as_sensitivity

Path: `scripts/compile_batch103_public_evidence.py`; SHA256 `02460cbb41b9e70381c7fd760b25e658baafc2191c126c9e0b41b2f612249682`; physical lines 145–235.

```text
145:     ledger = read_jsonl(args.outcome_root / "batch103_registered_cell_ledger_v1.jsonl")
146:     programs = read_jsonl(ROOT / "configs/batch102_candidate_counterfactual_programs_v4.jsonl")
147:     by_cell: dict[str, list[dict[str, Any]]] = defaultdict(list)
148:     for row in receipts:
149:         by_cell[row["cell_id"]].append(row)
150:     accounting = {row["cell_id"]: row for row in ledger}
151: 
152:     pairs = []
153:     factorials = []
154:     sensitivity = []
155:     necessity = []
156:     sufficiency = []
157:     interaction = []
158:     alternatives = []
159:     ownership = []
160:     for program in programs:
161:         incident_id = program["incident_cell"]["cell_id"]
162:         control_id = program["control_cell"]["cell_id"]
163:         incident = by_cell.get(incident_id, [])
164:         control = by_cell.get(control_id, [])
165:         valid = (
166:             len(incident) >= 2
167:             and len(control) >= 2
168:             and accounting[incident_id]["semantic_reproducibility"]
169:             and accounting[control_id]["semantic_reproducibility"]
170:             and all(row["predicate_result"] for row in incident + control)
171:         )
172:         pair = {
173:             "pair_id": f"batch103-pair:{program['program_id']}",
174:             "program_id": program["program_id"],
175:             "candidate_id": program["candidate_id"],
176:             "incident_cell_id": incident_id,
177:             "control_cell_id": control_id,
178:             "status": "VALID_PAIR" if valid else "PAIR_NOT_VALID",
179:             "fresh_execution_receipt_ids": [row["execution_receipt_id"] for row in incident + control],
180:             "held_invariants_verified": valid,
181:             "truth_access": 0,
182:         }
183:         pair["pair_hash"] = canonical_hash(pair)
184:         pairs.append(pair)
185:         required = {
186:             incident_id,
187:             control_id,
188:             *program.get("negative_controls", []),
189:         }
190:         complete = len(required) >= 4 and all(
191:             accounting.get(cell_id, {}).get("status", "").startswith("EXECUTED")
192:             and accounting.get(cell_id, {}).get("semantic_reproducibility")
193:             for cell_id in required
194:         )
195:         factorials.append(
196:             {
197:                 "factorial_id": f"batch103-factorial:{program['program_id']}",
198:                 "program_id": program["program_id"],
199:                 "required_cell_ids": sorted(required),
200:                 "complete": complete,
201:                 "truth_access": 0,
202:             }
203:         )
204:         sensitivity.append(
205:             {
206:                 "receipt_id": f"batch103-sensitivity:{program['program_id']}",
207:                 "program_id": program["program_id"],
208:                 "candidate_id": program["candidate_id"],
209:                 "supported": valid,
210:                 "evidence_level": "DIMENSION_SENSITIVITY_VERIFIED" if valid else "CONTACT_VERIFIED" if incident else "PRESENCE_VERIFIED",
211:                 "pair_id": pair["pair_id"],
212:                 "truth_access": 0,
213:                 "authority_forbidden": ["necessity", "sufficiency", "ownership", "patch", "repair count"],
214:             }
215:         )
216:         necessity.append(
217:             {
218:                 "receipt_id": f"batch103-necessity:{program['program_id']}",
219:                 "program_id": program["program_id"],
220:                 "supported": False,
221:                 "status": "NOT_ESTABLISHED",
222:                 "exact_blocker": "factor-removal semantics and invariants are not independently complete",
223:                 "fabricated": False,
224:             }
225:         )
226:         sufficiency.append(
227:             {
228:                 "receipt_id": f"batch103-sufficiency:{program['program_id']}",
229:                 "program_id": program["program_id"],
230:                 "supported": False,
231:                 "status": "NOT_ESTABLISHED",
232:                 "exact_blocker": "factor-introduction semantics and invariants are not independently complete",
233:                 "fabricated": False,
234:             }
235:         )
```

## existing_intervention_gates

Path: `controllergate/amds/causal_intervention_v12.py`; SHA256 `74b0d80e20cf92d36ba8e4b65c061e28a6c103ef00f875d949c7f71f62421388`; physical lines 14–58.

```text
14: def necessity_receipt(program_id: str, evidence: dict[str, Any]) -> dict[str, Any]:
15:     checks = {
16:         "incident_materialized": evidence.get("incident_materialized") is True,
17:         "factor_removed": evidence.get("factor_removed") is True,
18:         "incident_disappeared": evidence.get("incident_disappeared") is True,
19:         "held_invariants_stable": evidence.get("held_invariants_stable") is True,
20:         "semantic_reproducibility": evidence.get("semantic_reproducibility") is True,
21:         "direct_causal_contact": evidence.get("direct_causal_contact") is True,
22:         "independent_verifier": bool(evidence.get("independent_verifier")),
23:         "fresh_execution": evidence.get("fresh_execution") is True,
24:     }
25:     row = {"receipt_type": "NecessityReceiptV3", "program_id": program_id, "checks": checks,
26:            "supported": all(checks.values()), "authority_allowed": "necessity at executed scope",
27:            "authority_forbidden": ["ownership without alternative exclusion", "patch", "repair count"]}
28:     row["receipt_hash"] = _hash(row); return row
29: 
30: 
31: def sufficiency_receipt(program_id: str, evidence: dict[str, Any]) -> dict[str, Any]:
32:     checks = {
33:         "control_materialized": evidence.get("control_materialized") is True,
34:         "factor_introduced": evidence.get("factor_introduced") is True,
35:         "incident_appeared": evidence.get("incident_appeared") is True,
36:         "held_invariants_stable": evidence.get("held_invariants_stable") is True,
37:         "semantic_reproducibility": evidence.get("semantic_reproducibility") is True,
38:         "direct_causal_contact": evidence.get("direct_causal_contact") is True,
39:         "independent_verifier": bool(evidence.get("independent_verifier")),
40:         "fresh_execution": evidence.get("fresh_execution") is True,
41:     }
42:     row = {"receipt_type": "SufficiencyReceiptV3", "program_id": program_id, "checks": checks,
43:            "supported": all(checks.values()), "authority_allowed": "sufficiency at executed scope",
44:            "authority_forbidden": ["ownership without alternative exclusion", "patch", "repair count"]}
45:     row["receipt_hash"] = _hash(row); return row
46: 
47: 
48: def interaction_receipt(program_id: str, corners: list[dict[str, Any]], estimand: dict[str, Any]) -> dict[str, Any]:
49:     checks = {"factorial_complete": len(corners) >= 4 and len({row.get("corner_id") for row in corners}) == len(corners),
50:               "all_executed": bool(corners) and all(row.get("executed") for row in corners),
51:               "all_reproducible": bool(corners) and all(row.get("reproducible") for row in corners),
52:               "held_invariants": bool(corners) and all(row.get("held_invariants") for row in corners),
53:               "estimand_predeclared": estimand.get("predeclared") is True,
54:               "non_additive_effect": estimand.get("non_additive") is True}
55:     row = {"receipt_type": "InteractionReceiptV3", "program_id": program_id, "checks": checks,
56:            "supported": all(checks.values()), "estimand": estimand,
57:            "authority_allowed": "interaction at complete factorial depth", "authority_forbidden": ["automatic mixed-failure class", "patch"]}
58:     row["receipt_hash"] = _hash(row); return row
```

## actual_audioread_harness

Path: `scripts/batch100_audioread_harness.py`; SHA256 `1338b56590491c6efb9dec58efb967a5afdf526ab47d0f8df6208bf404ea4b2f`; physical lines 1–57.

```text
1: #!/usr/bin/env python3
2: """Structured Audioread issue-144 import and exact-test observation."""
3: 
4: from __future__ import annotations
5: 
6: import argparse
7: import importlib
8: import json
9: import sys
10: 
11: 
12: NODES = [
13:     "test/test_audioread.py::test_audioread_early_exit[test-1]",
14:     "test/test_audioread.py::test_audioread_early_exit[test-2]",
15:     "test/test_audioread.py::test_audioread_full[test-1]",
16:     "test/test_audioread.py::test_audioread_full[test-2]",
17: ]
18: 
19: 
20: def import_observation(name: str) -> dict:
21:     try:
22:         module = importlib.import_module(name)
23:         return {"module": name, "status": "IMPORTED", "origin": getattr(module, "__file__", None)}
24:     except Exception as exc:
25:         return {"module": name, "status": "FAILED", "exception_type": type(exc).__name__, "exception_text": str(exc)}
26: 
27: 
28: def main() -> int:
29:     parser = argparse.ArgumentParser()
30:     parser.add_argument("--route", choices=("rawread", "unrelated_backend"), required=True)
31:     parser.add_argument("--run-exact-tests", action="store_true")
32:     args = parser.parse_args()
33:     aifc = import_observation("aifc")
34:     route_module = "audioread.rawread" if args.route == "rawread" else "audioread.ffdec"
35:     route = import_observation(route_module)
36:     backend_observation: dict = {}
37:     try:
38:         import audioread
39:         backends = audioread.available_backends()
40:         backend_observation = {"status": "OBSERVED", "backend_count": len(backends), "backend_names": [item.__name__ for item in backends]}
41:     except Exception as exc:
42:         backend_observation = {"status": "FAILED", "exception_type": type(exc).__name__, "exception_text": str(exc)}
43:     pytest_return_code = None
44:     if args.run_exact_tests:
45:         import pytest
46:         pytest_return_code = int(pytest.main([*NODES, "-q", "--tb=short"]))
47:     result = {
48:         "route": args.route, "aifc": aifc, "route_import": route,
49:         "backend_discovery": backend_observation, "exact_test_nodes": NODES,
50:         "exact_test_return_code": pytest_return_code,
51:     }
52:     print("BATCH100_AUDIOREAD_OBSERVATION=" + json.dumps(result, sort_keys=True, separators=(",", ":")))
53:     return 0 if route["status"] == "IMPORTED" and (pytest_return_code in {None, 0}) else 1
54: 
55: 
56: if __name__ == "__main__":
57:     raise SystemExit(main())
```

## actual_source_capsule_v2_schema

Path: `controllergate/evidence/source_capsule_v2.py`; SHA256 `4ce5de2d31a06661d937865751d8f84bbfd8933a299b2de43ffbf08e16569e1a`; physical lines 27–71.

```text
27: def build_source_capsule_v2(
28:     *, candidate_id: str, repository: str, exact_source_commit: str, repo: Path,
29:     test_prefixes: Iterable[str], issue_cutoff: str, acquisition_broker_receipt: dict[str, Any],
30:     network_budget: dict[str, Any], tag: str | None = None,
31: ) -> dict[str, Any]:
32:     resolved = _git(repo, "rev-parse", f"{exact_source_commit}^{{commit}}")
33:     if resolved != exact_source_commit or not _SHA40.fullmatch(resolved):
34:         raise ValueError("exact source commit did not resolve byte-for-byte")
35:     tree = _git(repo, "rev-parse", f"{resolved}^{{tree}}")
36:     raw = _git(repo, "ls-tree", "-r", resolved)
37:     inventory = []
38:     for line in raw.splitlines():
39:         left, path = line.split("\t", 1)
40:         mode, kind, object_id = left.split(" ", 2)
41:         inventory.append({"mode": mode, "kind": kind, "object_id": object_id, "path": path})
42:     prefixes = tuple(value.rstrip("/") for value in test_prefixes)
43:     tests = [row for row in inventory if any(row["path"] == value or row["path"].startswith(value + "/") for value in prefixes)]
44:     submodules = [row for row in inventory if row["mode"] == "160000"]
45:     row: dict[str, Any] = {
46:         "capsule_version": "Batch102SourceCapsuleV2", "candidate_id": candidate_id,
47:         "repository": repository, "full_commit_sha": resolved, "tag": tag, "tree_sha": tree,
48:         "git_object_inventory_hash": canonical_hash(inventory), "git_object_count": len(inventory),
49:         "submodule_state": submodules, "version_metadata": {"describe": _git(repo, "describe", "--always", "--dirty=forbidden")},
50:         "source_manifest_hash": canonical_hash(inventory), "test_node_manifest_hash": canonical_hash(tests),
51:         "test_node_count": len(tests), "issue_cutoff": issue_cutoff,
52:         "future_commit_exclusion": True, "gold_patch_exclusion": True, "accepted_fix_exclusion": True,
53:         "acquisition_broker_receipt": acquisition_broker_receipt, "network_budget": network_budget,
54:         "authority_allowed": "source and test custody for the current execution epoch",
55:         "authority_forbidden": ["incident claim", "causal ownership", "patch", "repair count", "release promotion"],
56:     }
57:     row["source_capsule_hash"] = canonical_hash(row)
58:     return row
59: 
60: 
61: def verify_source_capsule_v2(row: dict[str, Any]) -> list[str]:
62:     blockers: list[str] = []
63:     if row.get("capsule_version") != "Batch102SourceCapsuleV2": blockers.append("capsule_version_mismatch")
64:     if not _SHA40.fullmatch(str(row.get("full_commit_sha", ""))): blockers.append("full_commit_sha_invalid")
65:     if not row.get("tree_sha") or not row.get("git_object_inventory_hash"): blockers.append("source_identity_incomplete")
66:     if not row.get("acquisition_broker_receipt", {}).get("operation_id"): blockers.append("acquisition_broker_receipt_missing")
67:     for field in ("future_commit_exclusion", "gold_patch_exclusion", "accepted_fix_exclusion"):
68:         if row.get(field) is not True: blockers.append(field + "_failed")
69:     expected = canonical_hash({key: value for key, value in row.items() if key != "source_capsule_hash"})
70:     if row.get("source_capsule_hash") != expected: blockers.append("source_capsule_hash_mismatch")
71:     return blockers
```
