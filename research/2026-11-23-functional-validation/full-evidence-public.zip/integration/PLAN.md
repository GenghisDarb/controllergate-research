# Functional integration pass: frozen scope and evaluation plan

This work extends the prior local semantic candidate while preserving the entire previous package. It does not alter the live repository, publish a branch, run a historical provider under invented provenance, or revise historical causal results.

1. Recheck the active repository head. Recover exact current cell/program registries, raw observation producers, semantic projection/adapters, fresh attestation, seal/public compiler, schemas and relevant tests. Audit every program's incident/control/extra role and raw field shape.
2. Add only explicit adapters justified by producer code or recovered prior semantic normalization. Preserve unavailable/unmapped fields and undeclared role semantics as UNRESOLVED. Do not infer missing evidence from absence alone.
3. Resolve nullable-schema compatibility at all inspected consumers. Independent verification must recompute observations/predicates/projections from the supplied independent inputs, not trust labels or self-hashes.
4. Materialize a local source checkout sufficient to import and execute real wrapper, attestation, seal and public compiler functions. Test the whole local chain using clearly labeled source-shaped fixtures, including actual raw-output parsing where supported. AST assertions alone are insufficient.
5. Include legitimate positive and negative observations, unresolved schemas/roles, replay-volatility changes, real semantic/context changes and forged/re-signed evidence. Record every failure and its correction. Run recovered original tests when their dependencies can be materialized; do not claim unavailable test suites passed.
6. Produce a complete reviewable diff against the inspected head, exact source manifests, executable integration tests and outputs, and a root-cause/fix/detection/remaining-limit memo. No claim of biological equivalence or new real-world causal gain follows merely from fixture success.

The evaluation families and constraints are fixed before this pass's integration outcomes. Adapter rules must cite source paths and ranges; any departure from the old scientific projection is a named version change.
