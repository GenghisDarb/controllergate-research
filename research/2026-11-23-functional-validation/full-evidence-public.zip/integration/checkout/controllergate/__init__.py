"""ControllerGate research harness package."""
