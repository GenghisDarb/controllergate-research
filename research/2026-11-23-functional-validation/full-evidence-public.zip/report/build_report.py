from pathlib import Path
import json
from html import escape
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'deliverables'
OUT.mkdir(exist_ok=True)
FONT = Path('/usr/share/fonts/truetype/dejavu')
for name, filename in [('DejaVu','DejaVuSans.ttf'),('DejaVu-Bold','DejaVuSans-Bold.ttf'),('DejaVu-Oblique','DejaVuSans-Oblique.ttf')]:
    pdfmetrics.registerFont(TTFont(name, str(FONT / filename)))
pdfmetrics.registerFontFamily('DejaVu', normal='DejaVu', bold='DejaVu-Bold', italic='DejaVu-Oblique')
INK = colors.HexColor('#172a3c')
TEAL = colors.HexColor('#12656b')
MUTED = colors.HexColor('#53616d')
PALE = colors.HexColor('#edf3f6')
styles = getSampleStyleSheet()
for key, settings in {
    'TitleR': dict(fontName='DejaVu-Bold',fontSize=25,leading=31,textColor=INK,spaceAfter=17),
    'SubR': dict(fontName='DejaVu',fontSize=12,leading=18,textColor=MUTED,spaceAfter=14),
    'H': dict(fontName='DejaVu-Bold',fontSize=16,leading=21,textColor=TEAL,spaceBefore=7,spaceAfter=11,keepWithNext=True),
    'H2': dict(fontName='DejaVu-Bold',fontSize=11,leading=15,textColor=INK,spaceBefore=10,spaceAfter=6,keepWithNext=True),
    'B': dict(fontName='DejaVu',fontSize=9.4,leading=14,textColor=INK,spaceAfter=9),
    'Small': dict(fontName='DejaVu',fontSize=8,leading=11.2,textColor=MUTED,spaceAfter=7),
    'Cell': dict(fontName='DejaVu',fontSize=8.2,leading=11.5,textColor=INK),
    'CellH': dict(fontName='DejaVu-Bold',fontSize=8.2,leading=11.5,textColor=colors.white),
    'Eq': dict(fontName='DejaVu',fontSize=10.5,leading=17,textColor=TEAL,leftIndent=10,spaceBefore=5,spaceAfter=11),
}.items():
    styles.add(ParagraphStyle(name=key, **settings))
story, plain = [], []
def p(text, style='B'):
    story.append(Paragraph(text, styles[style])); plain.append(text)
def h(text): p(text,'H')
def sub(text): p(text,'H2')
def page(): story.append(PageBreak()); plain.append('\n\n')
def tab(headers, rows, widths):
    data = [[Paragraph(escape(str(x)),styles['CellH']) for x in headers]]
    data += [[Paragraph(escape(str(x)),styles['Cell']) for x in row] for row in rows]
    table = Table(data,colWidths=widths,hAlign='LEFT',repeatRows=1)
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('VALIGN',(0,0),(-1,-1),'TOP'),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,PALE]),('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7)]))
    story.extend([table,Spacer(1,9)])
    plain.append(' | '.join(headers)); plain.extend(' | '.join(map(str,row)) for row in rows)
def link(label,url):
    return '<link href="'+escape(url,{'"':'&quot;'})+'" color="#12656b">'+escape(label)+'</link>'

p('Preserving function from<br/>Reactome to ControllerGate','TitleR')
p('Executed semantic tests, an integration repair, and a limited analysis of real molecular tracking data','SubR')
p('Prepared for Brad by Halcyon • 23 November 2026, Las Vegas<br/>Research supplement to the preceding Reactome / ControllerGate review.','Small')
h('The result')
p('Brad’s hypothesis concerns preservation of biological designs, dynamics and functional relationships. A label-invariance experiment does not test that stronger hypothesis. This pass supplies an explicit transition contract, working code, finite exhaustive controls within a declared domain, independent checks, and a small real-data observation-model analysis.')
tab(['Completed work','Finding and boundary'],[
 ('Functional translation','Six source-grounded Reactome directions; 12,150 event-local inventory cases. Faithful translation and an equally informed generic interpreter both have zero discrepancies.'),
 ('Shared-resource interlock','108 ordered two-action batches. Both atomic implementations agree with the reference; separate initial-snapshot approval overcommits resources in 16 cases.'),
 ('Exact local mathematics','The NAD/NADH/H+ projection returns after a coupled reaction pair while the complete material state changes. A separate information-loss calculation identifies distinctions a predictor must retain.'),
 ('Actual biological observations','A two-component descriptive model predicts two selected CTCF records better than fitted single-Gaussian alternatives, including a stronger post-result sensitivity.'),
 ('Evidence integration','Actual imported pipeline functions and CLIs were exercised locally; semantic binding, role interpretation and causal-claim boundaries were repaired. Detailed final counts follow.'),
], [121,374])
p('<b>Assessment:</b> this is substantive implementation and verification progress. It establishes a bounded functional correspondence and makes the broader hypothesis more testable. It does not establish whole-cell equivalence, new biological laws, superior real repair performance, or a unique fourteen-layer architecture.')
p('All newly generated evidence is retained with specifications, source identities, test receipts and local review. The previous report and its negative findings remain preserved. No remote deployment or external provider replication is claimed.','Small')

page(); h('1. What “one-to-one” must preserve')
p('A useful correspondence must map a state and an allowed action to the same consequences on both sides. Calling two objects by similar names is insufficient; matching an unlabelled interaction graph is also insufficient when amounts, prerequisites, location or action order change the outcome.')
p('Let x be a state of the selected source model, Fₐ its transition for event a, φ the state encoding and Gₐ the corresponding software transition. The test is:','B')
p('φ(Fₐ(x)) = Gₐ(φ(x)), with the same enabled / blocked decisions.','Eq')
p('If the software merges source states that need different predictions, no downstream deterministic decision rule can recover the distinction from that merged representation alone. This is an elementary information constraint, not a new physical principle. The formal notes give the proof and finite counterexamples [L1].')
tab(['Property','What this pass preserves','What remains outside the result'],[
 ('Participants and identity','Distinct compartment-qualified resources; separate curated event directions','All molecular variants and every Reactome annotation'),
 ('Functional prerequisites','All required inputs jointly; a separately asserted active catalyst role','Measurement of actual enzyme activity or assembly'),
 ('State changes','Exact consumed and produced amounts; nonconsumed catalytic guards','Concentrations, continuous kinetics and thermodynamics'),
 ('Composition','Shared resource identities; declared sequential atomic commits','True concurrent database transactions or whole-cell coupling'),
 ('Environment','Local versus extracellular pools and explicit transport','Crowding, pH, temperature, geometry and diffusion rates'),
 ('Observation','Unknown evidence retained as unresolved; real-data model check separately','A complete biological observation or intervention model'),
], [104,190,201])
p('The exact transfer theorem applies to the selected untimed contract within the implementation’s supported exact-integer range. A stochastic or timed correspondence would additionally need transition probabilities or rate laws and a specified time map. A source reference does not supply those quantities [S7–S9].')
sub('Development continuity retained')
p('The accessible source is controllergate-research at commit 38897b79588f3ff4b1b9002eedc299a9bcf05140. Its canonical stack contains real stage services and the five-set → fourteen-set → materialization → six-set licensing → action → fourteen-contact audit → duplicate replay → phase/seed → 196-obligation order. Earlier resource and compartment guards are credited. The code itself does not establish universal biological meanings for those counts [C1–C3].')
p('The newest accessible Systems Guide was inspected after its 23 November 08:10:39 UTC modification. This does not establish live Windows-PC, working-tree or Command Center status. The TLD lexicon and notation errata were consulted to avoid treating a projected chemical return as a completed TLD notebook result.','Small')

page(); h('2. The source-grounded biological contract')
p('The model was transcribed from six official rendered Reactome records. The source transcription is retained unchanged and was checked independently. It is not an exact SBML export; the direct export route was not available in this session. All displayed coefficients used here are one [S1–S6].')
tab(['Event','Inputs → outputs','Reusable catalytic role'],[
 ('71849, LDH forward','PYR + NADH + H+ → LACT + NAD+','Active LDH alternative'),
 ('70510, LDH reverse','LACT + NAD+ → PYR + NADH + H+','Active LDH alternative'),
 ('373875, export','LACT(c) + H+(c) → LACT(e) + H+(e)','Active membrane BSG:MCT complex'),
 ('373867, import','LACT(e) + H+(e) → LACT(c) + H+(c)','Active membrane BSG:MCT complex'),
 ('70449, GAPDH forward','GA3P + Pi + NAD+ → 1,3BPG + NADH + H+','Active GAPDH alternative'),
 ('70482, GAPDH reverse','1,3BPG + NADH + H+ → GA3P + Pi + NAD+','Active GAPDH alternative'),
], [111,252,132])
p('Unmarked metabolites are cytosolic; c and e denote cytosolic and extracellular pools. The selected contract contains ten metabolite places and three aggregate active-catalyst assertions. Its thirteen places are not a TLD layer count.','Small')
sub('Specific corrections made during source interpretation')
p('Forward and reverse chemistry are separate curated directions. This resolves the apparent conflict between reversible chemistry and a single directional record. LDH and GAPDH catalyst sets contain alternatives; they are not an AND requirement that all listed isoforms be present. The BSG:MCT entry is a membrane complex, whose assembly is outside this model.')
p('The LDH source also records negative regulation by PolyUb-LDHA. No quantitative rate law was recovered. It would be unjustified to turn that annotation into an absolute off-switch. The compact model therefore assumes an externally supplied active catalytic role and explicitly excludes that quantitative regulation. An annotated catalytic channel is not a proof that every uncatalyzed or alternate physical route is impossible.')
sub('Why this is more informative than a diagram')
p('A proton outside the cell is not interchangeable with one at the cytosolic reaction site. A catalyst can be used repeatedly without being consumed. Two reactions cannot both spend the same scarce resource merely because each passed a check against an earlier snapshot. These are testable differences in allowed transitions and successor states, not naming choices.')
p('Reactome already represents compartments, complexes, catalytic activities and regulation. The problem identified here concerns what a particular software path executes from those records, not a claim that Reactome’s data model lacks those concepts [S10].')

page(); h('3. Where the inspected execution path loses function')
p('The existing value-bound compiler preserves content-addressed source references and nonauthorizing status. The canonical runtime invokes real primitives. The finding is narrower: its source-conformance path does not supply the complete inventory-conditioned transition needed for the proposed stronger correspondence [C1–C3; L2].')
tab(['Inspected or executed finding','Consequence'],[
 ('Normal value_bound._primitives selection omits RESOURCE_FLUX.','Having a resource guard in the repository does not mean this path engages it.'),
 ('The nominal resource_delta in _actual_event is max(0, number of inputs − number of outputs).','A row-count difference does not specify which material changed, its quantity, or its compartment.'),
 ('The executed integrated fallback supplies entity_state, a list, as resource_delta.','The nonempty list passes generic presence conformance without entering the numeric balance branch.'),
 ('The numeric negative control spends one unit from zero and correctly blocks.','The original primitive contains a useful guard; the payload/selection boundary is the problem.'),
 ('The canonical verifier checks stage, source/result hashes, PASS status and authority.','Those custody checks cannot reconstruct an inventory never supplied to the primitive.'),
], [263,232])
sub('Paired-world witness')
p('The same LDH event metadata and source hash describe two constructed states with the same total proton count. In one, the proton is cytosolic; in the other, it is extracellular. The declared source model permits the reaction only in the first. The old metadata representation is identical. This exposes missing information for the stronger prediction; it does not retroactively reinterpret an old source-conformance PASS as a false claim of physical reaction enabledness.')
sub('The local repair')
p('The new module compiles typed consumed/produced resource maps, preserves compartments and separate directions, requires all inputs jointly, and reads catalytic activity without consuming it. It uses the archived numeric RESOURCE_FLUX primitive separately for each resource in a private working state, publishing only a fully successful transition. Blocked or unresolved operations leave the original state unchanged.')
p('Unknown state or rates remain UNRESOLVED unless a known missing prerequisite already proves BLOCK. Because the archived primitive uses floating-point numbers, exact count steps are conservatively restricted to the supported range through 2⁵³. This result is not an unbounded integer implementation theorem. The local module is complete and tested; it has not replaced the live ControllerGate state service.')

page(); h('4. What the new execution tests found')
p('The source transcription, code, compiled contract and experiment specification were locally sealed before outcomes were generated. The local seal records execution order and hashes; it is not an external preregistration or independently trusted timestamp. The domain enumerates local input, output and catalyst counts 0, 1 and 2, with prescribed remote-compartment cases. It does not enumerate every global state of a cell [L2].')
tab(['Implementation / diagnostic ablation','Cases','False enabled','Wrong successor'],[
 ('Faithful atomic translation','12,150','0','0'),
 ('Equally informed generic interpreter','12,150','0','0'),
 ('Any input suffices instead of all inputs','12,150','5,112','0*'),
 ('Consume catalyst as an input','12,150','0','2,592'),
 ('Pool identical chemicals across compartments','12,150','508','0*'),
], [265,70,80,80])
p('*Successor discrepancies here count states where both source and tested arm enable the action. False-enabled states are counted in their own column. The source enables 2,592 cases. The three weakened variants are deliberately constructed mechanism ablations, not competent generic baselines.','Small')
p('The equal-information generic interpreter ties exactly with the faithful translation. This is the correct control for a semantic-preservation claim: two correct implementations of the same supplied model should agree. These results establish what breaks when the tested relation is removed, not that biological inspiration alone outperforms generic mathematics.')
sub('Composition and resource interlocks')
p('Every ordered pair of the six actions was tested under three specified inventory regimes: 6 × 6 × 3 = 108 batches. The faithful and generic implementations each agree with the sequential reference in every batch. Approving both actions independently against an unchanged initial snapshot yields 16 resource overcommitments and negative diagnostic inventories. This is a deterministic composition test, not a threaded or database-concurrency test.')
p('Six composed traces include cofactor recycling, omission of a required regeneration step, forward/reverse returns, repeated use of one catalyst, and source-defined cotransport. Removing the second GAPDH step from the cofactor-recycling sequence gives PASS, PASS, BLOCK because the third action lacks regenerated NADH/H+. This is distinct from failing to restore NAD+ after an LDH action.')
sub('Independent verification')
p('Sixteen focused tests passed. A separate reviewer checked the six biological event mappings. Root independently read the original source-transcription coefficients, rebuilt expected transitions without the benchmark’s oracle or compiled coefficients, and reexecuted all 12,150 cases plus 216 competent-backend batch checks. There were zero disagreements. Shared dependence on the manual Reactome transcription remains explicit [L3].')

page(); h('5. A precise interlock and partial-return result')
p('The two forward source equations are [S1, S5]:')
p('GAPDH: GA3P + Pi + NAD+ → 1,3BPG + NADH + H+<br/>LDH: PYR + NADH + H+ → LACT + NAD+','Eq')
p('Add them and cancel the identical cofactor terms on both sides:')
p('GA3P + Pi + PYR → 1,3BPG + LACT.','Eq')
p('Thus the NAD+/NADH/H+ projection returns after a valid pair, while the complete state does not. Material is converted from substrates to products. The independent stoichiometric check also verifies conservation of NAD+ + NADH, GA3P + 1,3BPG, and PYR + LACT for this closed two-reaction submodel [L4].')
sub('What this recovers from the TORUS discussion')
p('It provides a concrete example of why the answer to “did the system return?” depends on which state variables are observed. A shared subsystem can regenerate while the larger system progresses. It also shows why local mechanisms need interlocks: composition depends on shared resource identity and availability, not on similarity of labels.')
p('The TLD lexicon defines ladder closure using stable terminal convergence under frozen rules and its eligibility conditions. That is not automatically the same endpoint as a finite chemical-state return. This pass establishes the specific projected-return calculation above; it does not rerun a TLD notebook or reinterpret historical fourteen-versus-fifteen results [T1–T2].')
sub('How much state must be retained?')
p('I enumerated all 27 combinations of three required input counts in {0,1,2}, fixing the catalytic role as available. For a single next-step prediction, eight combinations are enabled. The smallest possible error of any deterministic classifier using the indicated information is:')
tab(['Information retained','Minimum errors / 27','Reason'],[
 ('Reaction metadata only','8','All inventories look identical.'),
 ('Total input-token count only','4','The same total can hide a missing required species.'),
 ('Presence of each required input','0','Enough for this unit-coefficient one-step guard.'),
 ('Exact per-input counts','0','Retains all distinctions in this table.'),
], [203,105,187])
p('For the different target “maximum consecutive firings without replenishment,” presence alone must make at least one error in the same table: (1,1,1) and (2,2,2) have identical presence but allow one versus two firings. These are exact finite information-loss bounds under uniform artificial table weights, not estimates of biological error rates.')
p('This makes the required fidelity task-dependent. A literal copy of every cell detail is not always necessary; collapsing a distinction that changes the intended prediction is never harmless. The result is elementary and useful, but it is not a new physical theorem or a derivation of fourteen layers.')

page(); h('6. Actual biological observations were analyzed')
p('To move beyond a proposed study, two real, identified CTCF tracking files were recovered from the publisher archive of the authors’ Spot-On repository. Their bytes match the provider Git-object identities. The analysis is a limited new descriptive check, not a rerun of the full Spot-On pipeline [S11; L5].')
tab(['Property','Rep1 cell01','Rep3 cell01'],[
 ('Recorded acquisition date','2017-02-23','2017-03-09'),
 ('All tracks / singleton tracks','7,678 / 3,681','6,136 / 3,324'),
 ('Eligible trajectories at lag 1','3,997','2,812'),
 ('Training / scoring use','2,791 train; 1,206 heldout','2,812 scored; no refit'),
 ('Identity','U2OS C32 Halo-CTCF','U2OS C32 Halo-CTCF'),
], [205,145,145])
p('Source files are PA-JF646, 1 ms illumination, nominal 134 Hz records. Coordinates are micrometers. Stored timestamps/settings use 7.5 ms per frame; the example script uses 7.477 ms, a 0.3076% discrepancy. This analysis consistently uses the stored timestamps and does not claim independent camera calibration. Singletons are counted in quality reporting and cannot supply displacements.')
sub('Frozen primary comparison')
p('The first named cell in each supplied replicate directory was selected before fitting. Whole trajectories in rep1 were assigned by a deterministic hash to training or heldout sets. At lags 1–4, the analysis takes at most the first valid endpoint pair per trajectory. All lags from one trajectory remain together. Rep3 is a second named cell evaluated without refitting.')
p('The score is the mean across trajectories of each trajectory’s average marginal two-dimensional log density. Overlapping lag increments are not treated as an independent joint likelihood. Both primary models use the same localization/exposure convention; the comparison is one Brownian displacement component versus a two-component mixture with shared localization error. No component-count search was performed.')
p('For displacement magnitude r, elapsed time Δt, exposure E = 0.001 s and localization error σ, one component uses:','B')
p('s = D(Δt − E/3) + σ²<br/>p(Δx, Δy) = exp[−r²/(4s)] / (4πs).','Eq')
p('All six one-component and eighteen two-component optimizer starts succeeded. The observed mixture weight is descriptive; it is not a calibrated bound fraction. Both models omit defocalization and tracking-selection effects and do not model molecular switching. In particular, the full Spot-On defocalization correction has not been reproduced here [S11].')

page(); h('7. Held-out results and the stronger challenge')
tab(['Scoring record','Two minus one component','Conditional 95% interval'],[
 ('Rep1 heldout; 1,206 trajectories','+0.615888','[0.526181, 0.710782]'),
 ('Rep3; 2,812 trajectories, no refit','+0.877488','[0.777256, 0.982268]'),
], [235,120,140])
p('Units are nats per trajectory-average marginal log score; higher is better. Intervals are paired trajectory-bootstrap intervals conditional on the fitted models and within-record exchangeability. They are not population-level biological uncertainty or parameter confidence intervals. All four lag-specific gains are positive in both records.','Small')
story.append(Image(str(ROOT/'research/ctcf_reanalysis/ctcf_heldout_cdfs.png'),width=495,height=346.5))
plain.append('Figure: observed versus modeled radial-displacement cumulative distributions; full-size PNG included in the evidence package.')
sub('The first null hit a bound, so it was challenged')
p('The primary one-component localization error hit its 0.075 µm upper bound. A separately sealed post-result sensitivity therefore fitted a free mean and full covariance independently at each lag, using training data only. This removes the variance cap, isotropy and zero-drift restrictions. The original mixture remains unchanged.')
tab(['Scoring record','Mixture minus free Gaussian','Conditional 95% interval'],[
 ('Rep1 heldout','+0.624185','[0.536998, 0.720693]'),
 ('Rep3 without refit','+0.877628','[0.778417, 0.981216]'),
], [235,120,140])
page(); h('8. How the biological result connects')
p('The empirical finding is specific: in these two selected records, the tested mixture predicts observed displacements better than the fitted single-Gaussian alternatives. The stronger sensitivity shows that the result does not depend solely on the first model’s variance cap, isotropy or zero mean. It remains a post-result sensitivity on the same data, not another independent validation.')
p('The mixture still fits imperfectly: maximum radial-CDF discrepancies are approximately 0.055–0.100 in rep1 and 0.085–0.112 in rep3. Root independently reparsed raw tracks and recomputed both comparisons with a different density implementation; score discrepancies were below 2.3 × 10⁻¹⁴ [L6].','Small')
sub('Observation is part of the model')
p('A measured trajectory is not the complete molecular state. Localization noise, the camera exposure, defocalization and track survival influence what appears in the observations. Different lags also retain different surviving tracks. Repeated trajectories need not represent independent molecules. Two selected cells do not estimate population variability.')
p('Accordingly, the fitted slow/fast components are descriptive features of the chosen observation model. They do not establish exactly two physical molecular states, a binding mechanism, a measured rate of switching, a crowding explanation, or a cell-wide causal law. The original Spot-On paper already treats observation bias as a modeling problem; this is not a discovery that mainstream biology ignores dynamics [S11].')
sub('The bridge to ControllerGate')
p('The relevant lesson is methodological and operational: retain the distinctions that change the specified outcome, and model how evidence is produced. In ControllerGate, source identity and a valid receipt are necessary provenance facts. They do not by themselves prove a resource was available, a causal intervention occurred, or a physical parameter was observed.')
p('The reaction-network experiment and the CTCF experiment answer different questions. The first checks faithful execution of a small declared transition model. The second checks predictive adequacy of a simplified observation model on real data. CTCF tracks are not validation data for LDH/GAPDH, and neither experiment establishes a literal cell-to-ControllerGate dynamic isomorphism.')
sub('What can reasonably raise confidence')
p('Confidence increases in the feasibility of building an inspectable functional translation and in the need to retain specified state distinctions. It also increases in the ability to perform useful, modest empirical checks without turning a qualitative analogy into evidence. Confidence in a unique TORUS/TLD architecture requires a discriminating result that these tests do not supply.')
p('The positive mechanism results and real-data scores are therefore retained as completed work, while broader claims remain open. This boundary protects the meaningful results from being weakened by claims their experiments did not test.')

F = json.loads((ROOT/'report/final_facts.json').read_text())
I = F['integration']
page(); h('9. The evidence pipeline was repaired and exercised')
p('The local candidate exercises the producer/parser and the same raw-to-fresh constructor used by the provider-installation wrapper. The wrapper’s installation main was not launched. Actual seal, public-compiler and planner CLIs ran afterward on marked fixtures. Explicit observation adapters retain missing/null evidence and role-specific obligations [L7].')
tab(['Executed check','Final result'],[
 ('Focused integration suite',str(I['test_methods'])+' test methods passed, including eight unchanged original source tests.'),
 ('Actual pipeline CLIs','12 explicitly synthetic receipts across six cells; all 70 registered cells accounted for; 90 arm/program executions across ten planner arms.'),
 ('Role classification versus effect','Two fixture pairs meet their role predicates. The identical Py-bugger pair is correctly recorded as having no declared outcome contrast.'),
 ('Causal claim boundary','Zero causal-sensitivity claims, zero ownership proofs and zero official provider operations.'),
 ('Actual local Audioread execution','Recovered pinned source plus the project harness ran on local Python 3.12.14. rawread satisfies its control predicate; unrelated_backend remains unresolved for that control.'),
], [164,331])
sub('Why incident/control booleans were insufficient')
p('The Py-bugger incident and control predicates overlap. An identical outcome can satisfy both role labels. Treating those two labels alone as sensitivity can promote classification into a causal claim. The repair compares the same declared predicate vector on both sides and separates descriptive contrast from invariants and intervention evidence. In the retained fixture, both vectors are [true, true], so contrast is false.')
sub('Contract mismatches were kept visible')
p('Of 70 registered software test cells, 12 incident and 14 control cells have acceptance predicates; 44 other roles retain diagnostics and unresolved role-specific obligations. The invoked producer selects only 32 cells. Of 38 later additions, 37 lack its required per-cell provider ID, resource budget and platform, although program-level provider lists exist. Some added recipes require harness substitutions not implemented by that producer or unsupported arguments. These are materialization gaps, not newly executed provider results.')
sub('The independent review found and closed a binding gap')
p(F['binding_review_summary'])
p('The original raw historical artifacts were not available for fresh reclassification. Local source and synthetic receipt tests cannot retroactively prove historical repair gain. The exact Audioread execution is a real local harness run in a new environment, not a replay of the historical provider campaign. Initial failed development runs and mutation receipts remain in the evidence package.')

page(); h('10. Where confidence now stands')
tab(['Claim','Assessment after this pass','Reason'],[
 ('Functional correspondence matters','Supported as a precise modeling requirement','Omitting tested state distinctions changes enabled actions or successor states.'),
 ('The selected source model can be preserved in code','Established within the declared domain','Conditional proof, fixed finite cases, composed traces and independent recomputation.'),
 ('The older source-conformance path fully tested that stronger claim','Not established','The executed adapter witness does not provide the required resource transaction.'),
 ('Biological structure uniquely improves ControllerGate predictions','Still unestablished','The equally informed generic interpreter ties; no new real-case causal repair gain was measured.'),
 ('A single observed Gaussian is adequate for the selected CTCF records','Worse than the tested mixture','Heldout and no-refit score gains survive a stronger post-result Gaussian comparison.'),
 ('TORUS/TLD has a unique fourteen-layer or 10+4 advantage','Not tested by these experiments','No alternative layer-count campaign or noncircular derivation was executed.'),
], [161,159,175])
sub('What would be worth publishing now?')
p('There is a defensible technical report now: exact source-to-runtime losses, a working bounded translation, an equally informed control, a documented pipeline correction, and reproducible receipts. It is suitable for technical review as an engineering and methodology artifact. The present report supplies that artifact rather than dividing small checks into multiple claimed breakthrough papers.')
p('Under Brad’s higher bar—a significant standalone scientific contribution—this pass does not establish a major biological or TORUS paper. The resource equations and preservation argument use established mathematics. The CTCF result is a small descriptive reanalysis of an already studied system. Combining them does not turn them into a newly demonstrated universal mechanism.')
p('The larger hypothesis remains credible as a testable engineering proposal: preserve function and environmental context, then ask whether that structure improves predictions or evidence acquisition when the situation changes. Its promise is more concrete now because a working transfer exists and specific lossy interfaces were found. Its special predictive advantage remains an empirical question.')
sub('Prior art changes the novelty claim')
p('Logical verification of Reactome knowledgebases was already published by Racunas and colleagues in 2006. Exact behavioral equivalences for chemical reaction networks and rigorous causal-abstraction definitions also predate this work. Those sources provide usable tools and comparison standards; they prevent presenting semantic compilation or abstraction itself as a new TORUS discovery [S7–S9].')

page(); h('11. Repair playbook and remaining boundaries')
tab(['Root cause','Fix and detection','Nearby exposure'],[
 ('Source metadata substituted for execution state','Supply explicit typed inventories and active-role observations. Test two states sharing metadata but requiring different decisions.','Any path using source presence or a receipt hash to imply current availability.'),
 ('Fallback values bypass specialized guards','Require numeric or dictionary schemas before entering resource/compartment primitives. Keep malformed evidence unresolved.','Generic fallback chains and type-dependent guard branches.'),
 ('Single-action checks ignore shared resources','Joint prerequisites and atomic state updates; test repeated use and competing actions.','Independent approvals on a shared initial snapshot.'),
 ('Role labels are mistaken for causal response','Evaluate common outcomes and explicit intervention/invariance obligations; retain identical-pair negative controls.','Public compilers, sensitivity summaries, ownership and attribution reports.'),
 ('Receipt identity does not fully bind actual execution','Reconstruct the allowed command/working directory, compare literal arguments and bind the broker operation; mutate and rehash inputs.','Attestation, wrapper expansion and normalization rules.'),
 ('Flexible fit is mistaken for physical identification','Heldout scoring, stronger alternatives, visible residual misfit and observation-model limits.','Mixture-state interpretations, inferred bound fractions and cross-cell claims.'),
], [137,209,149])
sub('What remains empirically unverified')
p('The inventory and active-role observations needed by the translation have not been measured for a biological cell. Rates, regulation, complex assembly, physical environment and observation errors are not jointly fitted. The local translation has not been deployed into the canonical live ControllerGate transaction path. Fresh independent provider outcomes have not established a repair or causal-ownership gain. No new TLD closure notebook or layer-count test was executed.')
p('Those are specific remaining evidence boundaries, not reasons to erase the completed tests. The completed result is a functioning, inspectable mechanism and a better separated claim structure. The next scientific claim must be supported by a new outcome of the appropriate kind, not by reclassifying these same finite controls as external biological validation.')

page(); h('12. Reproduction and verification record')
p('The companion archive is self-contained for the recorded local tests and includes exact biological data files, source snapshots, licenses, frozen specifications, code, results, counterexamples, repair candidate, review receipts and this report. Bulky provider/base64 envelopes, the unidentified format-example CSV and private Systems Guide contents are excluded.')
tab(['Evidence','Where to inspect'],[
 ('Original source transcription and provenance','research/reactome_event_contract.json; research/source_manifest.json'),
 ('Frozen functional experiment and all results','mechanisms/FROZEN_DESIGN.json; results.json; source_oracle_truth_table.csv'),
 ('Actual archived-function witnesses','mechanisms/legacy_witnesses.json; MAPPING_TRACE.md; SOURCE_LEDGER.json'),
 ('Independent transition and invariant checks','formal/independent_transition_review.json; independent_invariants.json; preservation_argument.txt'),
 ('Raw biological data and frozen primary analysis','research/ctcf_rep1_cell01.mat; ctcf_rep3_cell01.mat; ctcf_reanalysis/FROZEN_ANALYSIS.json'),
 ('Primary and sensitivity results','research/ctcf_reanalysis/results.json; gaussian_sensitivity_results.json'),
 ('Independent raw-data score check','formal/independent_ctcf_review.json'),
 ('Final local integration evidence',F['integration_final_relative_path']+'; integration/README.md'),
 ('Package identity and execution environment','PACKAGE_MANIFEST.json; verify_package.py; ENVIRONMENT.json'),
], [196,299])
p('Start with python verify_package.py from the extracted root. Its SHA256 checks establish consistency with the included manifest, not an external trust anchor. The README gives safe fresh-directory replay commands. Preserve original result files; CTCF scripts deliberately refuse to overwrite their outputs.')
p('The mechanism tests need Python’s standard library. The CTCF analysis used Python 3.12.14, NumPy 2.3.5 and SciPy 1.17.0; Matplotlib supplies the plot. Integration includes the small source/vendor subset needed by the executed local checks. The report build uses ReportLab and DejaVu fonts. Complete package versions are recorded in ENVIRONMENT.json.')
sub('Review already completed')
p('The reaction source review, independent source-direct transition review and independent raw-data score recomputation passed within their stated scope. The integration execution-binding mutations were reviewed separately. Failed intermediate integration attempts remain visible. The PDF was rendered and inspected for layout; the package manifest was verified after assembly.')
p('No remote repository, public paper, external provider environment or live Command Center record was changed. The README includes a completion record suitable for review; it is not a new board task. This pass is finished at the local evidence boundary described above.')

page(); h('13. Source index: biological and formal work')
sources=[
 ('S1','Reactome R-HSA-71849: pyruvate and NADH form lactate and NAD+.','https://reactome.org/content/detail/R-HSA-71849'),
 ('S2','Reactome R-HSA-70510: separately curated reverse LDH event.','https://reactome.org/content/detail/R-HSA-70510'),
 ('S3','Reactome R-HSA-373875: lactate/proton export via BSG:MCT.','https://reactome.org/content/detail/R-HSA-373875'),
 ('S4','Reactome R-HSA-373867: separately curated import direction.','https://reactome.org/content/detail/R-HSA-373867'),
 ('S5','Reactome R-HSA-70449: forward GAPDH conversion.','https://reactome.org/content/detail/R-HSA-70449'),
 ('S6','Reactome R-HSA-70482: reverse GAPDH conversion.','https://reactome.org/content/detail/R-HSA-70482'),
 ('S7','Racunas, Shah and Fedoroff. A case study in pathway knowledgebase verification. BMC Bioinformatics 7:196 (2006). DOI 10.1186/1471-2105-7-196.','https://pmc.ncbi.nlm.nih.gov/articles/PMC1522024/'),
 ('S8','Cardelli et al. Forward and Backward Bisimulations for Chemical Reaction Networks. CONCUR (2015). DOI 10.4230/LIPIcs.CONCUR.2015.226.','https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.CONCUR.2015.226'),
 ('S9','Beckers and Halpern. Abstracting Causal Models. AAAI (2019), arXiv:1812.03789. See also Rubenstein et al. Causal Consistency of Structural Equation Models, UAI 2017.','https://arxiv.org/abs/1812.03789'),
 ('S10','Reactome official data model: molecular entities, sets, complexes, compartments, catalytic activity and regulation.','https://reactome.org/documentation/data-model'),
 ('S11','Hansen et al. Robust model-based analysis of single-particle tracking experiments with Spot-On. eLife 7:e33125 (2018). DOI 10.7554/eLife.33125.','https://elifesciences.org/articles/33125'),
 ('S12','Publisher archive of the Spot-On MATLAB implementation and example data, pinned commit f155c4c889ea124a8f55ab8f620e540628e18f92.','https://github.com/elifesciences-publications/spot-on-matlab/tree/f155c4c889ea124a8f55ab8f620e540628e18f92'),
]
for key,desc,url in sources:
    p('<b>'+key+'.</b> '+escape(desc)+' '+link('Primary source',url),'Small')
p('The compact source manifest retains exact data filenames, SHA256 and Git-object identities, timing assumptions and route-specific access limitations. Sources provide the specified model and published context; numerical claims about this new pass are supported by the local experiment receipts.','Small')

page(); h('14. Source index: project and new evidence')
base='https://github.com/GenghisDarb/controllergate-research/blob/38897b79588f3ff4b1b9002eedc299a9bcf05140/'
for key,desc,path in [
 ('C1','Canonical implementation and analogy boundaries','docs/CONTROLLERGATE_CANONICAL_ISOMORPHISM_MAP.md'),
 ('C2','Source-bound adapter and nominal resource delta','controllergate/isomorphism/source_bound.py'),
 ('C3','Value-bound primitive selection and payload construction','controllergate/isomorphism/value_bound.py'),
 ('C4','Actual archived primitive guards','controllergate/isomorphism/primitives.py'),
 ('C5','Fresh-execution wrapper inspected and locally repaired','scripts/run_batch102_candidate_slice.py'),
 ('C6','Public evidence compilation and sensitivity boundary','scripts/compile_batch103_public_evidence.py'),
 ('C7','Original v4 semantic predicate registry','configs/batch102_outcome_semantic_registry_v4.jsonl'),
]:
    p('<b>'+key+'.</b> '+escape(desc)+'. '+link(path,base+path),'Small')
for key,desc in [
 ('T1','Formal Lexicon of TORUS Ladder Dynamics, provided project source. Consulted definitions: ladder closure, omega state, Te onset, Se persistence and winner_N label. Relevant local excerpts and source hashes are retained in formal/project_definition_context.txt.'),
 ('T2','Mislabeling & Notation History (Errata Map), provided project source. Used to preserve the distinction between ladder labels, physical dimension claims and retrospective notation corrections.'),
 ('L1','formal/transfer_contract.txt and preservation_argument.txt: model-transfer definition, elementary information-loss proposition, conditional preservation proof and limits.'),
 ('L2','mechanisms/results.json, FROZEN_DESIGN.json and legacy_witnesses.json: original experiment, preserved source bindings and executed controls.'),
 ('L3','formal/independent_transition_review.json: independent expected-state reconstruction from the original source transcription, all cases and ordered batches.'),
 ('L4','formal/independent_invariants.json: exact stoichiometric invariants, projected-return calculation and finite representation-loss bounds.'),
 ('L5','research/ctcf_reanalysis/: locally frozen primary analysis, quality report, fit diagnostics, raw data and post-result Gaussian sensitivity.'),
 ('L6','formal/independent_ctcf_review.json: separately parsed raw trajectories and independently computed score arithmetic.'),
 ('L7','integration/: original source subset, local edited checkout, observations/roles/recipe ledger, final receipts and preserved intermediate failures. The source and final candidate must not be confused.'),
]:
    p('<b>'+key+'.</b> '+escape(desc),'Small')
p('The selected excerpts support definitions only. They do not claim that all historical TLD experiments or the complete live repository were rerun. No invented message-number citation or inaccessible notebook outcome is used.','Small')

def footer(canvas,doc):
    canvas.saveState(); width,height=A4
    canvas.setStrokeColor(colors.HexColor('#cbd7dd'));canvas.line(50,40,width-50,40)
    canvas.setFont('DejaVu',7.3);canvas.setFillColor(MUTED)
    canvas.drawString(50,26,'Halcyon / TORUS research • Functional translation and local evidence • 23 Nov 2026')
    canvas.drawRightString(width-50,26,str(doc.page));canvas.restoreState()

pdf=OUT/'Reactome_ControllerGate_Functional_Validation_2026-11-23.pdf'
doc=SimpleDocTemplate(str(pdf),pagesize=A4,rightMargin=50,leftMargin=50,topMargin=45,bottomMargin=55,title='Preserving function from Reactome to ControllerGate',author='Halcyon for Brad')
doc.build(story,onFirstPage=footer,onLaterPages=footer)
(ROOT/'report/report_text.txt').write_text('\n\n'.join(plain)+'\n',encoding='utf-8')
print(pdf)
