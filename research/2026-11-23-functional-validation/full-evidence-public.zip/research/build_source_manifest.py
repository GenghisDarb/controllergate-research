"""Build a compact, credential-free provenance ledger from final research files."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import platform
import sys

ROOT = Path(__file__).resolve().parent
COMMIT = 'f155c4c889ea124a8f55ab8f620e540628e18f92'
REPO = 'https://github.com/elifesciences-publications/spot-on-matlab'
SOURCES = [
    ('ctcf_rep1_cell01.mat', 'Data/CTCF_134Hz_rep1/U2OS_C32_Halo-CTCF_PA-JF646_1ms-633nm_134Hz_rep1_cell01.mat', '6486d6b15c68faf47395f54427d25f1680fc7acd', 'Real experimental record used in primary fit/heldout split.'),
    ('ctcf_rep3_cell01.mat', 'Data/CTCF_134Hz_rep3/U2OS_C32_Halo-CTCF_PA-JF646_1ms-633nm_134Hz_rep3_cell01.mat', '49627183cf193d00c6a663750c2de408f58a4919', 'Real experimental record used for secondary no-refit check.'),
    ('SpotOn_main.m', 'SpotOn_main.m', 'd25a94b206d9e4b3f11ceac60fbbfd8a7f36d236', 'Author example source inspected for metadata/model context; full author pipeline not executed.'),
    ('spoton_matlab_README.md', 'README.md', 'b80587eb95d8439012f512b3db2f9f96cee98693', 'Author attribution, source-paper and usage context.'),
    ('SpotOn_LICENSE.md', 'LICENSE.md', '5dc6b429ba4a658bcd584331a5a38b20e6e3f3c3', 'Repository GPLv3 license retained. No separate data-license declaration recovered in inspected README/license.')]


def details(path):
    b = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(b),
            'sha256': hashlib.sha256(b).hexdigest()}


def main():
    source_files = []
    for local, remote, expected, scope in SOURCES:
        p = ROOT/local
        b = p.read_bytes()
        git = hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
        assert git == expected, local
        source_files.append({**details(p), 'git_blob_sha1': git, 'git_blob_verified': True,
            'repository_commit': COMMIT, 'repository_path': remote,
            'source_url': REPO + '/blob/' + COMMIT + '/' + remote,
            'retrieved_date_utc': '2026-11-23', 'receipt_timing_precision': 'date only; exact response time not separately attested',
            'byte_provenance': 'Decoded GitHub connector response; bytes independently matched Git object hash.', 'scope': scope})

    sys.path.insert(0, str(ROOT/'ctcf_reanalysis'))
    from analyze_ctcf import verify_seal
    from gaussian_sensitivity import verify
    verify_seal(); verify()
    import numpy
    import scipy
    import matplotlib
    contract = json.loads((ROOT/'reactome_event_contract.json').read_text())
    assert details(ROOT/'reactome_event_contract.json')['sha256'] == '3ff1a48296743786be42d32f25a5dfae0a569baf462e696c578def2844008af6'
    primary = json.loads((ROOT/'ctcf_reanalysis/results.json').read_text())
    sensitivity = json.loads((ROOT/'ctcf_reanalysis/gaussian_sensitivity_results.json').read_text())
    primary_seal = json.loads((ROOT/'ctcf_reanalysis/FROZEN_ANALYSIS.json').read_text())
    sensitivity_seal = json.loads((ROOT/'ctcf_reanalysis/GAUSSIAN_SENSITIVITY_SEAL.json').read_text())
    include = ['reactome_event_contract.json', 'spoton_repository_commit.json', 'public_download_attempts.json',
               'RESEARCH_MEMO.md', 'build_source_manifest.py']
    include += [p.relative_to(ROOT).as_posix() for p in sorted((ROOT/'ctcf_reanalysis').iterdir()) if p.is_file()]
    artifacts = [details(ROOT/n) for n in include]
    primary_sources = [
        {'title': 'Robust model-based analysis of single-particle tracking experiments with Spot-On',
         'doi': '10.7554/eLife.33125', 'url': 'https://doi.org/10.7554/eLife.33125',
         'open_text': 'https://pmc.ncbi.nlm.nih.gov/articles/PMC5809147/',
         'scope': 'Source paper and author/publisher data provenance. Our analysis is a simplified reanalysis, not full Spot-On reproduction.'},
        {'title': 'A case study in pathway knowledgebase verification', 'doi': '10.1186/1471-2105-7-196',
         'url': 'https://pmc.ncbi.nlm.nih.gov/articles/PMC1522024/', 'retrieval_ref': 'turn748473305view1',
         'scope': 'Primary source for existing logical verification of Reactome; no independent reproduction.'},
        {'title': 'Forward and Backward Bisimulations for Chemical Reaction Networks', 'doi': '10.4230/LIPIcs.CONCUR.2015.226',
         'url': 'https://drops.dagstuhl.de/entities/document/10.4230/LIPIcs.CONCUR.2015.226', 'retrieval_ref': 'turn748473305view3',
         'scope': 'Official proceedings abstract/metadata inspected; exact reduction prior art, not a new proof here.'},
        {'title': 'Automatic construction of Petri net models for computational simulations of molecular interaction network',
         'doi': '10.1038/s41540-024-00464-z', 'url': 'https://www.nature.com/articles/s41540-024-00464-z',
         'retrieval_ref': 'turn748473305view2', 'scope': 'Primary article inspected for signaling-Petri-net compilation prior art; no numerical reproduction.'},
        {'title': 'Abstracting Causal Models', 'identifier': 'arXiv:1812.03789v4',
         'url': 'https://arxiv.org/abs/1812.03789', 'retrieval_ref': 'turn801065390view0',
         'scope': 'Primary formal source for distinct abstraction strengths and intervention scope.'}]
    manifest = {'schema': 'FunctionalTransferResearchProvenanceV1',
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'status': 'PASS', 'status_scope': 'Exact source-byte and local-seal checks; not a scientific truth certificate.',
        'source_files': source_files,
        'reactome_contract': {**details(ROOT/'reactome_event_contract.json'),
            'source_kind': 'Manual transcription of official rendered records, not original JSON/SBML bytes.',
            'events': [{'id': e['id'], 'url': e['source'], 'original_retrieval_ref': e.get('source_ref')} for e in contract['events']],
            'additional_full_record_confirmation': {'event': 'R-HSA-70482', 'url': 'https://reactome.org/content/detail/R-HSA-70482',
                'agent': '/root/bridge_review', 'retrieval_ref': 'turn902408076view0',
                'note': 'Full reverse record independently opened after original manual contract was sealed; contract bytes unchanged.'},
            'unresolved': ['Exact SBML/source export byte verification', 'kinetic rates and concentrations', 'quantitative regulation', 'context-specific enzyme activity and tissue expression']},
        'primary_sources': primary_sources,
        'analysis_chronology': {'primary_frozen_utc': primary_seal['created_utc'], 'primary_completed_utc': primary['completed_utc'],
            'sensitivity_frozen_utc': sensitivity_seal['created_utc'], 'sensitivity_completed_utc': sensitivity['completed_utc'],
            'scope': 'Local inspectable sequence, not external preregistration or independent timestamp attestation.'},
        'runtime': {'python': platform.python_version(), 'numpy': numpy.__version__, 'scipy': scipy.__version__, 'matplotlib': matplotlib.__version__},
        'local_artifacts': artifacts,
        'packaging': {'include': 'Exact two MAT files, author example/README/license, compact provenance, own specs/code/results/plot/memos.',
            'exclude_patterns': ['*.provider.json', '*.capture.json', '__pycache__/*', 'spoton_standard_csv.csv'],
            'reason': 'Provider payloads duplicate base64 data; bulk web captures are unnecessary for replay. Unidentified format-example CSV was not used in empirical analysis.'},
        'method_limits': ['Two named cells do not estimate biological population variability.',
            'Within-track lags overlap; score is marginal/composite and bootstrap resamples trajectories.',
            'Tracking/defocalization selection and repeated-molecule identity are not modeled.',
            'Two-component weight is not a physical bound fraction; free-Gaussian sensitivity remains post-result.',
            'CTCF data do not validate the LDH/GAPDH network or any whole-cell/ControllerGate isomorphism.']}
    (ROOT/'source_manifest.json').write_text(json.dumps(manifest, indent=2, sort_keys=True, allow_nan=False)+'\n')
    print(json.dumps({'status': 'PASS', 'source_files': len(source_files), 'reactome_events': len(contract['events']),
        'local_artifacts': len(artifacts), 'manifest': details(ROOT/'source_manifest.json')}, indent=2))


if __name__ == '__main__':
    main()
