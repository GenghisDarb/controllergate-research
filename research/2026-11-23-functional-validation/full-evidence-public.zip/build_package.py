"""Assemble a reproducible evidence archive without bulky provider envelopes."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'deliverables'
PDF_NAME = 'Reactome_ControllerGate_Functional_Validation_2026-11-23.pdf'
ZIP_NAME = 'Reactome_ControllerGate_Functional_Evidence_2026-11-23.zip'
REPORT_FILES = {
    'build_report.py','final_facts.json','report_text.txt','pdf_quality_review.json',
    'research_scope_portability_review.json','final_report_scope_review.json',
}
TOP_FILES = {'README.txt','ENVIRONMENT.json','verify_package.py','build_package.py'}
integration_manifest = json.loads((ROOT/'integration/PORTABLE_FILE_MANIFEST.json').read_text())
INTEGRATION_FILES = {x['path'] for x in integration_manifest['files']} | {'PORTABLE_FILE_MANIFEST.json'}
for item in integration_manifest['files']:
    payload=(ROOT/'integration'/item['path']).read_bytes()
    assert len(payload)==item['bytes'],item['path']
    assert hashlib.sha256(payload).hexdigest()==item['sha256'],item['path']

def include(p):
    rel = p.relative_to(ROOT)
    if any(x in {'__pycache__','.git','.pytest_cache'} for x in rel.parts):
        return False
    if p.name.endswith(('.provider.json','.capture.json','.pyc')):
        return False
    if p.name == 'spoton_standard_csv.csv':
        return False
    if len(rel.parts) == 1:
        return p.name in TOP_FILES
    if rel.parts[0] == 'report':
        return p.name in REPORT_FILES
    if rel.parts[0] == 'deliverables':
        return p.name == PDF_NAME
    if rel.parts[0] == 'integration':
        return Path(*rel.parts[1:]).as_posix() in INTEGRATION_FILES
    return rel.parts[0] in {'formal','mechanisms','research'}

files = sorted(p for p in ROOT.rglob('*') if p.is_file() and include(p))
manifest = {
    'schema':'functional_validation_package.v1',
    'assembled_utc':datetime.now(timezone.utc).isoformat(),
    'source_commit':'38897b79588f3ff4b1b9002eedc299a9bcf05140',
    'source_scope':'Pinned source subsets, local candidates and explicitly scoped experiments.',
    'files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,
              'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files],
    'excluded':'Private Guide, bulky provider/base64 and capture envelopes, unidentified CSV, caches, rendered QA images, prior full audit package.',
    'trust_limit':'Included hash manifest is an integrity reference, not an externally authenticated anchor.',
}
mp = ROOT/'PACKAGE_MANIFEST.json'
mp.write_text(json.dumps(manifest,indent=2)+'\n')
archive = OUT/ZIP_NAME
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as z:
    for p in files+[mp]:
        z.write(p,arcname=p.relative_to(ROOT).as_posix())
with zipfile.ZipFile(archive) as z:
    assert z.testzip() is None
    for item in manifest['files']:
        payload=z.read(item['path'])
        assert len(payload)==item['bytes']
        assert hashlib.sha256(payload).hexdigest()==item['sha256']
receipt={
    'status':'PASS', 'payload_files':len(files),
    'payload_bytes':sum(x['bytes'] for x in manifest['files']),
    'archive_bytes':archive.stat().st_size,
    'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),
    'manifest_sha256':hashlib.sha256(mp.read_bytes()).hexdigest(),
    'pdf_sha256':hashlib.sha256((OUT/PDF_NAME).read_bytes()).hexdigest(),
    'scope':'Archive CRC and every included payload identity checked against manifest.',
}
(OUT/'Reactome_ControllerGate_Functional_Verification_2026-11-23.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
