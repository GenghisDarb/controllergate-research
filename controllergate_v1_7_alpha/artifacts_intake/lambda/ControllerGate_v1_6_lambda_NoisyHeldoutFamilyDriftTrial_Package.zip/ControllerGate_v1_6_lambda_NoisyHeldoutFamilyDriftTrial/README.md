# ControllerGate v1.6-lambda — Noisy Heldout Family Drift Trial Prototype

Status: diagnostic prototype, not proof of self-maintaining software.

Lambda extends the verified v1.6-kappa baseline by testing whether the frozen balanced memory threshold policy survives a noisier heldout split with family drift, weaker signature purity, partial validator disagreement, delayed validator noise, near-match pressure, and changing productive-action reliability.

Reproduce:

```bash
python -m benchmarks.run_agent_maintenance_trial --config locks/v1_6_lambda.json --out outputs
python -m benchmarks.analyze_agent_maintenance_trial --outputs outputs
sha256sum -c SHA256SUMS.txt
```

Strict reporting rule: do not claim pass unless SHA256 verification, rerun analyzer output, and packaged outputs/decision_report.json agree.
