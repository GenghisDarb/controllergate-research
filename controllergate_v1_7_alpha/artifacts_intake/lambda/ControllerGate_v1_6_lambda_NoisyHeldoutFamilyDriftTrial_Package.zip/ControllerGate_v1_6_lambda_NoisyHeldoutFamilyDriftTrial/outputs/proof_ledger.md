# v1.6-lambda Proof Ledger

Every scored trial includes runtime, split, action, outcome, policy mode, drift metadata, and proof hash. Calibration selects and freezes the balanced memory threshold policy before noisier heldout scoring.
