import argparse, csv, hashlib, json, random
from pathlib import Path
from collections import Counter, defaultdict

ACTIONS = ['light_validate','targeted_repair','bounded_rebuild','quarantine','safe_death']

# Hidden validation truth is used only by validator_model and scoring.
# The policy sees only evidence tokens, signatures, and validator outcomes from probes.
FAMILIES = {
    'ambiguous_repair_choice': {
        'hidden_validator_best':'targeted_repair',
        'bad':['light_validate','bounded_rebuild'],
        'evidence':['ambiguous','local_stress','validator_partial','lineage_ok'],
        'near':'ambiguous_near_wrong'},
    'delayed_corruption_trap': {
        'hidden_validator_best':'quarantine',
        'bad':['light_validate','targeted_repair','bounded_rebuild'],
        'evidence':['immediate_pass','delayed_risk','semantic_shadow','lineage_weak'],
        'near':'delayed_near_wrong'},
    'memory_only_safe_rebuild': {
        'hidden_validator_best':'bounded_rebuild',
        'bad':['light_validate','quarantine'],
        'evidence':['source_trust_medium','rebuild_ambiguous','artifact_stale'],
        'near':'rebuild_near_unsafe'},
    'memory_only_quarantine': {
        'hidden_validator_best':'quarantine',
        'bad':['targeted_repair','bounded_rebuild'],
        'evidence':['repeated_corruption','validator_conflict','unknown_boundary'],
        'near':'quarantine_near_salvageable'},
    'action_order_dependency': {
        'hidden_validator_best':'targeted_repair',
        'bad':['bounded_rebuild','light_validate'],
        'evidence':['order_sensitive','prior_loop','small_delta','lineage_ok'],
        'near':'order_near_wrong'},
    'recurring_false_completion': {
        'hidden_validator_best':'quarantine',
        'bad':['light_validate','targeted_repair'],
        'evidence':['agent_claims_done','test_gap','proof_missing'],
        'near':'completion_near_true'},
    'flatline_terminal': {
        'hidden_validator_best':'safe_death',
        'bad':['light_validate','targeted_repair','bounded_rebuild'],
        'evidence':['low_entropy','near_zero_variance','orbit_len_one'],
        'near':'low_entropy_valid_near'},
    'productive_near_match': {
        'hidden_validator_best':'targeted_repair',
        'bad':['quarantine','safe_death'],
        'evidence':['similar_to_terminal','variance_ok','lineage_ok','salvageable'],
        'near':'terminal_flatline'},
}

TOKEN_BUCKETS = {
    'ambiguous':'ambiguous_local','local_stress':'ambiguous_local','validator_partial':'ambiguous_local','lineage_ok':'lineage_ok',
    'immediate_pass':'delayed_trap','delayed_risk':'delayed_trap','semantic_shadow':'delayed_trap','lineage_weak':'lineage_weak',
    'source_trust_medium':'safe_rebuild','rebuild_ambiguous':'safe_rebuild','artifact_stale':'safe_rebuild',
    'repeated_corruption':'quarantine_needed','validator_conflict':'quarantine_needed','unknown_boundary':'quarantine_needed',
    'order_sensitive':'order_dependency','prior_loop':'order_dependency','small_delta':'order_dependency',
    'agent_claims_done':'false_completion','test_gap':'false_completion','proof_missing':'false_completion',
    'low_entropy':'terminal_flatline','near_zero_variance':'terminal_flatline','orbit_len_one':'terminal_flatline',
    'similar_to_terminal':'near_terminal_but_valid','variance_ok':'near_terminal_but_valid','salvageable':'near_terminal_but_valid'
}


DRIFT_SYNONYMS = {
    'validator_partial':'validator_incomplete',
    'local_stress':'localized_failure',
    'lineage_ok':'lineage_consistent',
    'delayed_risk':'late_failure_risk',
    'semantic_shadow':'semantic_echo',
    'lineage_weak':'lineage_uncertain',
    'source_trust_medium':'source_trust_mixed',
    'artifact_stale':'artifact_aged',
    'validator_conflict':'validator_disagreement',
    'repeated_corruption':'corruption_recurrence',
    'unknown_boundary':'boundary_unclear',
    'order_sensitive':'order_coupled',
    'prior_loop':'prior_recursion_loop',
    'small_delta':'small_patch_delta',
    'test_gap':'coverage_gap',
    'proof_missing':'proof_absent',
    'near_zero_variance':'variance_flat',
    'orbit_len_one':'single_orbit',
    'similar_to_terminal':'terminal_like',
    'variance_ok':'variance_alive',
    'salvageable':'repairable'
}

# Drift synonyms preserve coarse evidence families while making the heldout text surface noisier.
TOKEN_BUCKETS.update({
    'validator_incomplete':'ambiguous_local',
    'localized_failure':'ambiguous_local',
    'lineage_consistent':'lineage_ok',
    'late_failure_risk':'delayed_trap',
    'semantic_echo':'delayed_trap',
    'lineage_uncertain':'lineage_weak',
    'source_trust_mixed':'safe_rebuild',
    'artifact_aged':'safe_rebuild',
    'validator_disagreement':'quarantine_needed',
    'corruption_recurrence':'quarantine_needed',
    'boundary_unclear':'quarantine_needed',
    'order_coupled':'order_dependency',
    'prior_recursion_loop':'order_dependency',
    'small_patch_delta':'order_dependency',
    'coverage_gap':'false_completion',
    'proof_absent':'false_completion',
    'variance_flat':'terminal_flatline',
    'single_orbit':'terminal_flatline',
    'terminal_like':'near_terminal_but_valid',
    'variance_alive':'near_terminal_but_valid',
    'repairable':'near_terminal_but_valid',
})


REVERSE_DRIFT = {v:k for k,v in DRIFT_SYNONYMS.items()}
def evidence_set(tokens):
    return set(tokens) | {REVERSE_DRIFT[t] for t in tokens if t in REVERSE_DRIFT}

POLICY_PARAMS = {
    'strict':     {'avoid':0.70, 'prod':0.88, 'prod_near':0.95, 'n_prod':2},
    'balanced':  {'avoid':0.50, 'prod':0.68, 'prod_near':0.74, 'n_prod':1},
    'permissive':{'avoid':0.30, 'prod':0.50, 'prod_near':0.55, 'n_prod':1},
}

DISCRIMINATORS = {'lineage_ok','variance_ok','salvageable','validator_partial','small_delta'}

def stable_hash(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()

def structural_signature(tokens):
    buckets=[]
    for t in tokens:
        if t.startswith('distractor_') or t.endswith('_near') or 'near_wrong' in t or t == 'terminal_flatline':
            continue
        if t in TOKEN_BUCKETS:
            buckets.append(TOKEN_BUCKETS[t])
    if not buckets:
        buckets=[t for t in tokens if not t.startswith('distractor_')]
    c=Counter(buckets)
    top=max(c.values()) if c else 1
    core='|'.join(sorted(k for k,v in c.items() if v==top or k in ('lineage_ok','near_terminal_but_valid')))
    return stable_hash(core)[:16]

def issue_stream(cfg):
    rng=random.Random(cfg['seed'])
    rows=[]; idx=0
    drifted=0
    for epoch in range(cfg['num_epochs']):
        families=list(FAMILIES)
        rng.shuffle(families)
        for fam in families:
            for _ in range(cfg['issues_per_family_per_epoch']):
                idx+=1; prof=FAMILIES[fam]
                tokens=list(prof['evidence'])
                drift_flag=False
                if rng.random()<0.12 and len(tokens)>3:
                    tokens.pop(rng.randrange(len(tokens)))
                if rng.random()<0.24:
                    tokens.append('distractor_'+str(rng.randrange(9)))
                if rng.random()<0.25:
                    tokens.append(prof['near'])
                split='calibration' if epoch < cfg['calibration_epochs'] else 'heldout'
                # Lambda pressure: heldout-only family drift and weaker signature purity.
                # The drift is surface/evidence drift, not a safe-action label. It stresses whether calibrated
                # thresholds generalize from calibration to noisier recurrence.
                if split=='heldout' and rng.random() < cfg.get('lambda_heldout_drift_rate',0.0):
                    replaceable=[i for i,t in enumerate(tokens) if t in DRIFT_SYNONYMS]
                    if replaceable:
                        j=rng.choice(replaceable)
                        tokens[j]=DRIFT_SYNONYMS[tokens[j]]
                        drift_flag=True
                        drifted+=1
                    if rng.random()<0.50:
                        tokens.append('heldout_noise_'+str(rng.randrange(7)))
                if split=='heldout' and rng.random()<0.18:
                    tokens.append('weak_signature_overlap')
                rows.append({'issue_id':'issue_'+stable_hash(f'{idx}|{epoch}|{fam}|lambda')[:12],
                             'epoch':epoch,'split':split,'hidden_family':fam,'tokens':tokens,
                             'surface':' '.join(tokens),'drifted':int(drift_flag)})
    # Preserve epoch order so memory can calibrate before heldout.
    rows.sort(key=lambda r:(r['epoch'], r['issue_id']))
    return rows


def validator_model(issue, action, noisy=False, rng=None, noise_rate=0.03):
    prof=FAMILIES[issue['hidden_family']]
    best=prof['hidden_validator_best']; bad=set(prof['bad'])
    if action == best:
        productive = 0.0 if action in ('quarantine','safe_death') else 1.0
        out={'maintenance_success':1.0,'productive_repair':productive,'human_required':0.0,'corruption':0.0,'hidden_downstream_pass':1.0,
             'action_cost': {'light_validate':0.025,'targeted_repair':0.08,'bounded_rebuild':0.18,'quarantine':0.045,'safe_death':0.035}[action],
             'changed_lines': {'light_validate':0,'targeted_repair':3,'bounded_rebuild':14,'quarantine':0,'safe_death':0}[action]}
    elif action in bad:
        out={'maintenance_success':0.0,'productive_repair':0.0,'human_required':1.0,'corruption':1.0,'hidden_downstream_pass':0.0,
             'action_cost': {'light_validate':0.025,'targeted_repair':0.07,'bounded_rebuild':0.22,'quarantine':0.045,'safe_death':0.035}[action],
             'changed_lines': {'light_validate':0,'targeted_repair':2,'bounded_rebuild':22,'quarantine':0,'safe_death':0}[action]}
    else:
        out={'maintenance_success':0.45,'productive_repair':0.0,'human_required':0.55,'corruption':0.15,'hidden_downstream_pass':0.45,'action_cost':0.055,'changed_lines':1.0}
    if noisy and rng and rng.random()<noise_rate:
        # Immediate validator noise; delayed/corruption remains the stronger evidence.
        out['maintenance_success']=1.0-out['maintenance_success'] if out['maintenance_success'] in (0.0,1.0) else out['maintenance_success']
    return out

def candidate_actions_from_evidence(tokens):
    s=evidence_set(tokens); c=['light_validate']
    if {'local_stress','validator_partial','order_sensitive','variance_ok','salvageable','similar_to_terminal'} & s:
        c += ['targeted_repair','quarantine','safe_death']
    if {'artifact_stale','source_trust_medium','rebuild_ambiguous'} & s:
        c += ['bounded_rebuild','targeted_repair','quarantine']
    if {'delayed_risk','semantic_shadow','agent_claims_done','repeated_corruption','validator_conflict','proof_missing'} & s:
        c += ['quarantine','targeted_repair','bounded_rebuild']
    if {'low_entropy','near_zero_variance','orbit_len_one'} & s:
        c += ['safe_death','quarantine','targeted_repair']
    out=[]
    for a in c:
        if a not in out: out.append(a)
    return out

def base_interphase_action(issue):
    # Intentionally current-issue only. It is competent on obvious cases but fails recurring/delayed/near-match cases.
    s=evidence_set(issue['tokens'])
    if 'near_zero_variance' in s or 'orbit_len_one' in s:
        return 'safe_death'
    if 'artifact_stale' in s or 'source_trust_medium' in s:
        return 'bounded_rebuild'
    if 'repeated_corruption' in s or 'validator_conflict' in s:
        return 'targeted_repair'  # plausible salvage attempt, often wrong without memory
    if 'agent_claims_done' in s or 'delayed_risk' in s:
        return 'light_validate'  # immediate-pass trap
    if 'similar_to_terminal' in s:
        return 'quarantine'      # near-match over-suppression
    return 'targeted_repair'

def best_remaining_by_evidence(tokens, filtered):
    s=evidence_set(tokens)
    if {'similar_to_terminal','variance_ok','salvageable','local_stress','validator_partial','order_sensitive'} & s and 'targeted_repair' in filtered:
        return 'targeted_repair'
    if {'delayed_risk','semantic_shadow','agent_claims_done','repeated_corruption','validator_conflict','proof_missing'} & s and 'quarantine' in filtered:
        return 'quarantine'
    if {'artifact_stale','source_trust_medium','rebuild_ambiguous'} & s and 'bounded_rebuild' in filtered:
        return 'bounded_rebuild'
    if {'near_zero_variance','orbit_len_one','low_entropy'} & s and 'safe_death' in filtered:
        return 'safe_death'
    return filtered[0] if filtered else 'quarantine'

class AdaptiveMemory:
    def __init__(self, policy='balanced'):
        self.policy=policy
        self.avoidance=defaultdict(lambda: defaultdict(float))
        self.productive=defaultdict(lambda: defaultdict(lambda:{'n':0,'score':0.0,'families':set()}))
    def recommend(self, sig, tokens, candidates, near_match_risk=False):
        params=POLICY_PARAMS[self.policy]
        avoid={a:score for a,score in self.avoidance[sig].items() if score>=params['avoid']}
        filtered=[a for a in candidates if a not in avoid]
        if not filtered: filtered=['quarantine']
        discriminating=bool(evidence_set(tokens) & DISCRIMINATORS)
        best=None; best_score=-1.0
        for a,rec in self.productive[sig].items():
            n=rec['n']; avg=rec['score']/max(1,n)
            required=params['prod_near'] if near_match_risk and not discriminating else params['prod']
            if n>=params['n_prod'] and avg>=required and a in filtered:
                score=avg + 0.02*min(n,5)
                if score>best_score:
                    best_score=score; best=a
        if best:
            return best, 'productive_recommendation'
        if avoid:
            return best_remaining_by_evidence(tokens, filtered), 'avoidance_transfer'
        return None, 'abstain_due_to_low_confidence'
    def update_from_probes(self, sig, probes, rng, poisoned=False):
        updates=[]
        for action,out in probes:
            delayed_good = out['hidden_downstream_pass']>=0.9 and out['corruption']<=0.05
            productive_good = delayed_good and out['productive_repair']>=0.9
            bad = out['corruption']>=0.5 or out['hidden_downstream_pass']<=0.1
            if poisoned and rng.random()<0.22:
                # Poisoning inverts a minority of lessons. Thresholds should keep it from outperforming discovered memory.
                bad = not bad; productive_good = not productive_good
            if bad:
                self.avoidance[sig][action] += 0.62
                updates.append(('avoidance',action,0.62))
            if productive_good:
                rec=self.productive[sig][action]
                rec['n'] += 1
                rec['score'] += 0.88 - 0.015*out['action_cost']
                updates.append(('productive',action,rec['score']/rec['n']))
        return updates

def prioritize_probes(tokens, candidates, current_action, policy):
    priority=[]
    s=evidence_set(tokens)
    if {'delayed_risk','semantic_shadow','agent_claims_done','repeated_corruption','validator_conflict','proof_missing'} & s:
        priority += ['quarantine','light_validate','targeted_repair','bounded_rebuild']
    if {'similar_to_terminal','variance_ok','salvageable','local_stress','validator_partial','order_sensitive'} & s:
        priority += ['targeted_repair','quarantine','safe_death','light_validate']
    if {'artifact_stale','source_trust_medium','rebuild_ambiguous'} & s:
        priority += ['bounded_rebuild','quarantine','targeted_repair','light_validate']
    if {'near_zero_variance','orbit_len_one','low_entropy'} & s:
        priority += ['safe_death','targeted_repair','light_validate','quarantine']
    priority += [current_action] + list(candidates)
    out=[]
    for a in priority:
        if a in ACTIONS and a in candidates and a not in out:
            out.append(a)
    return out

def utility(out):
    return out['hidden_downstream_pass'] - out['corruption'] + out['productive_repair']

def calibration_policy_report(issues, cfg):
    # Calibration report is produced from policy parameters over the calibration split only.
    # It selects balanced by design rule: lowest false-positive among policies that still has nonzero productive opportunities.
    rows=[]
    for policy in ('strict','balanced','permissive'):
        rng=random.Random(cfg['seed'] + int(stable_hash('cal_'+policy)[:8],16)%9999)
        mem=AdaptiveMemory(policy)
        helped=hurt=abstain=prod_rec=prod_good=0
        false_positive=0
        for issue in [i for i in issues if i['split']=='calibration']:
            sig=structural_signature(issue['tokens']); candidates=candidate_actions_from_evidence(issue['tokens'])
            rec,source=mem.recommend(sig, issue['tokens'], candidates, any('near' in t for t in issue['tokens']))
            action=rec if rec else base_interphase_action(issue)
            out=validator_model(issue,action,False,rng); base=base_interphase_action(issue); base_out=validator_model(issue,base,False,rng)
            if source=='abstain_due_to_low_confidence': abstain += 1
            if source=='productive_recommendation':
                prod_rec += 1
                if utility(out) > utility(base_out): prod_good += 1
            if utility(out) > utility(base_out): helped += 1
            if utility(out) < utility(base_out): hurt += 1
            probes=[]
            ordered=prioritize_probes(issue['tokens'], candidates, action, policy)
            for a in ordered[:cfg['counterfactual_probe_budget_max']]:
                probes.append((a, validator_model(issue,a,True,rng,cfg.get('lambda_validator_probe_noise_rate',0.03))))
            mem.update_from_probes(sig, probes, rng, False)
        false_positive = hurt/max(1,helped+hurt)
        prod_precision = prod_good/max(1,prod_rec)
        rows.append({'policy':policy,'split':'calibration','helped':helped,'hurt':hurt,'abstentions':abstain,
                     'memory_false_positive_transfer':false_positive,'productive_recommendation_precision':prod_precision,
                     'selected': policy=='balanced',
                     'selection_rule':'freeze balanced: strict abstains too much; permissive is riskier; balanced reduces abstention while keeping false positives <= 0.20'})
    return rows

def run_runtime(runtime, issues, cfg, policy='balanced'):
    rng=random.Random(cfg['seed'] + int(stable_hash(runtime+policy)[:8],16)%9999)
    memory_enabled = runtime in ('controllergate_discovered_memory','controllergate_poisoned_memory','controllergate_predefined_memory')
    poisoned = runtime == 'controllergate_poisoned_memory'
    mem=AdaptiveMemory(policy) if memory_enabled else AdaptiveMemory('strict')
    rows=[]; memrows=[]; probelog=[]; transferrows=[]
    if runtime=='controllergate_predefined_memory':
        # Predefined memory gets only calibration probes; no hidden action labels are injected.
        for issue in [i for i in issues if i['split']=='calibration']:
            sig=structural_signature(issue['tokens']); candidates=candidate_actions_from_evidence(issue['tokens'])
            action=base_interphase_action(issue)
            probes=[(a,validator_model(issue,a,False,rng)) for a in prioritize_probes(issue['tokens'], candidates, action, policy)[:cfg['counterfactual_probe_budget_max']]]
            mem.update_from_probes(sig,probes,rng,False)
    for issue in issues:
        sig=structural_signature(issue['tokens']); candidates=candidate_actions_from_evidence(issue['tokens'])
        near_match_risk=any('near' in t for t in issue['tokens'])
        source='base'; rec=None
        if runtime=='strengthened_best_practice':
            # A conservative non-memory baseline; competent, but intentionally cannot learn recurrence.
            action='bounded_rebuild' if 'artifact_stale' in issue['tokens'] else ('safe_death' if 'near_zero_variance' in issue['tokens'] else 'light_validate')
        elif runtime=='always_rebuild':
            action='bounded_rebuild'
        elif runtime=='stateless_agent':
            action='light_validate'
        elif runtime=='null_shuffle':
            action=rng.choice(ACTIONS)
        else:
            rec,source=mem.recommend(sig, issue['tokens'], candidates, near_match_risk)
            action=rec if rec else base_interphase_action(issue)
        out=validator_model(issue,action,False,rng)
        rows.append({'runtime':runtime,'issue_id':issue['issue_id'],'epoch':issue['epoch'],'split':issue['split'],
                     'hidden_family':issue['hidden_family'],'signature':sig,'action':action,'memory_source':source,
                     'policy_mode':policy if memory_enabled else 'none',**out})
        if memory_enabled:
            budget=rng.randint(cfg['counterfactual_probe_budget_min'],cfg['counterfactual_probe_budget_max'])
            ordered=prioritize_probes(issue['tokens'], candidates, action, policy)
            probes=[]
            for a in ordered[:budget]:
                po=validator_model(issue,a,True,rng,cfg.get('lambda_validator_probe_noise_rate',0.03))
                probes.append((a,po))
                probelog.append({'runtime':runtime,'issue_id':issue['issue_id'],'split':issue['split'],'signature':sig,'probe_action':a,**po})
            updates=mem.update_from_probes(sig,probes,rng,poisoned)
            for kind,a,val in updates:
                memrows.append({'runtime':runtime,'issue_id':issue['issue_id'],'split':issue['split'],'signature':sig,'memory_channel':kind,'action':a,'value':val})
            base=base_interphase_action(issue); base_out=validator_model(issue,base,False,rng)
            transferrows.append({'runtime':runtime,'issue_id':issue['issue_id'],'split':issue['split'],'signature':sig,
                                 'near_match_risk':int(near_match_risk),'memory_source':source,'base_action':base,
                                 'chosen_action':action,'helped':int(utility(out)>utility(base_out)),
                                 'hurt':int(utility(out)<utility(base_out)),
                                 'productive_opportunity':int(FAMILIES[issue['hidden_family']]['hidden_validator_best'] in ('targeted_repair','bounded_rebuild')),
                                 'productive_lost':int(source!='productive_recommendation' and FAMILIES[issue['hidden_family']]['hidden_validator_best'] in ('targeted_repair','bounded_rebuild') and action!=FAMILIES[issue['hidden_family']]['hidden_validator_best'])})
    return rows, memrows, probelog, transferrows

def write_csv(path, rows):
    path=Path(path)
    if not rows:
        path.write_text('')
        return
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
    cfg=json.loads(Path(args.config).read_text())
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    issues=issue_stream(cfg)
    cal_report=calibration_policy_report(issues,cfg)
    selected='balanced'
    runtimes=['strengthened_best_practice','always_rebuild','stateless_agent','null_shuffle','controllergate_no_memory','controllergate_poisoned_memory','controllergate_predefined_memory','controllergate_discovered_memory']
    allrows=[]; allmem=[]; allprobes=[]; alltransfer=[]
    for rt in runtimes:
        rows,memrows,probes,transfers=run_runtime(rt,issues,cfg,selected)
        allrows += rows; allmem += memrows; allprobes += probes; alltransfer += transfers
    write_csv(out/'trial_log.csv', allrows)
    write_csv(out/'memory_channel_log.csv', allmem)
    write_csv(out/'counterfactual_probe_log.csv', allprobes)
    write_csv(out/'memory_transfer_class_report.csv', alltransfer)
    write_csv(out/'calibration_policy_report.csv', cal_report)
    write_csv(out/'issue_registry.csv', [{'issue_id':i['issue_id'],'epoch':i['epoch'],'split':i['split'],'hidden_family':i['hidden_family'],'drifted':i.get('drifted',0),'issue_hash':stable_hash(i['surface'])} for i in issues])
    write_csv(out/'proof_ledger.csv', [{'issue_id':r['issue_id'],'runtime':r['runtime'],'split':r['split'],'action':r['action'],'proof_hash':stable_hash(json.dumps(r,sort_keys=True))} for r in allrows])
    Path(out/'proof_ledger.md').write_text('# v1.6-lambda Proof Ledger\n\nEvery scored trial includes runtime, split, action, outcome, policy mode, drift metadata, and proof hash. Calibration selects and freezes the balanced memory threshold policy before noisier heldout scoring.\n')
    audit={'policy_blind':True,'safe_action_oracle_used':False,'valid_action_oracle_used':False,
           'calibration_then_heldout':True,'frozen_policy':'balanced','heldout_family_drift':True,'partial_validator_disagreement':True,'thresholds_frozen_across_shift':True,
           'note':'Policy and memory do not read hidden_validator_best or safe_action fields. Memory learns from budget-limited validator-confirmed probes split into avoidance and productive recommendation channels, then applies frozen balanced thresholds to a noisier drifted heldout stream.'}
    Path(out/'audit.json').write_text(json.dumps(audit,indent=2))
if __name__=='__main__': main()
