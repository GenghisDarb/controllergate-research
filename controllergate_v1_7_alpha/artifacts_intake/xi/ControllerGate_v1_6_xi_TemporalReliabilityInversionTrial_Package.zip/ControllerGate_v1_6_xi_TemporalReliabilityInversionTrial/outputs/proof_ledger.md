# v1.6-xi Proof Ledger

Every scored trial includes runtime, split, epoch, temporal phase, action, outcome, and proof hash. The discovered-memory runtime uses confidence aging, contradiction detection, and stale-lesson quarantine under temporal reliability inversion.
