
import argparse, csv, hashlib, json, random
from pathlib import Path
from collections import defaultdict, Counter

ACTIONS=['light_validate','targeted_repair','bounded_rebuild','quarantine','safe_death']

FAMILIES={
 'stable_repair': {'kind':'stable','best':'targeted_repair','bad':['quarantine','safe_death','light_validate'], 'tokens':['local_failure','tests_present','small_delta','repairable']},
 'stable_quarantine': {'kind':'stable','best':'quarantine','bad':['light_validate','targeted_repair','bounded_rebuild'], 'tokens':['corruption_recurrence','validator_conflict','hidden_risk']},
 'stable_rebuild': {'kind':'stable','best':'bounded_rebuild','bad':['light_validate','quarantine'], 'tokens':['artifact_stale','dependency_shift','rebuild_safe']},
 'terminal_flatline': {'kind':'stable','best':'safe_death','bad':['light_validate','targeted_repair','bounded_rebuild'], 'tokens':['low_entropy','orbit_len_one','terminal_signal']},
 # Temporal inversion families: the best action changes after inversion_epoch.
 'repair_becomes_unsafe': {'kind':'inversion','early':'targeted_repair','late':'quarantine','bad_early':['quarantine','safe_death','light_validate'], 'bad_late':['targeted_repair','light_validate','bounded_rebuild'], 'tokens':['local_failure','tests_present','repairable','reliability_clocked']},
 'quarantine_becomes_productive': {'kind':'inversion','early':'quarantine','late':'targeted_repair','bad_early':['targeted_repair','bounded_rebuild','light_validate'], 'bad_late':['quarantine','safe_death','light_validate'], 'tokens':['validator_conflict','previously_terminal','reopened_signal','reliability_clocked']},
 'rebuild_becomes_excessive': {'kind':'inversion','early':'bounded_rebuild','late':'targeted_repair','bad_early':['light_validate','quarantine'], 'bad_late':['bounded_rebuild','quarantine','safe_death'], 'tokens':['artifact_stale','dependency_shift','small_delta','reliability_clocked']},
 'safe_death_becomes_salvageable': {'kind':'inversion','early':'safe_death','late':'targeted_repair','bad_early':['targeted_repair','bounded_rebuild','light_validate'], 'bad_late':['safe_death','quarantine','light_validate'], 'tokens':['low_entropy','variance_recovered','salvage_signal','reliability_clocked']},
}

TOKEN_BUCKETS={
 'local_failure':'repair','tests_present':'repair','small_delta':'repair','repairable':'repair',
 'corruption_recurrence':'quarantine','validator_conflict':'quarantine','hidden_risk':'quarantine',
 'artifact_stale':'rebuild','dependency_shift':'rebuild','rebuild_safe':'rebuild',
 'low_entropy':'terminal','orbit_len_one':'terminal','terminal_signal':'terminal',
 'previously_terminal':'reopened','reopened_signal':'reopened','variance_recovered':'reopened','salvage_signal':'reopened',
 'reliability_clocked':'temporal_reliability'
}
DRIFT={'local_failure':'localized_failure','tests_present':'coverage_present','small_delta':'small_patch','repairable':'salvageable',
       'corruption_recurrence':'corruption_repeats','validator_conflict':'validator_disagreement','hidden_risk':'latent_risk',
       'artifact_stale':'artifact_aged','dependency_shift':'dependency_rotated','low_entropy':'entropy_low','variance_recovered':'variance_alive'}
REV={v:k for k,v in DRIFT.items()}
TOKEN_BUCKETS.update({v:TOKEN_BUCKETS[k] for k,v in DRIFT.items() if k in TOKEN_BUCKETS})

def stable_hash(s): return hashlib.sha256(s.encode()).hexdigest()

def evidence_set(tokens):
    return set(tokens)|{REV[t] for t in tokens if t in REV}

def signature(tokens):
    buckets=[]
    for t in tokens:
        if t.startswith('noise_') or t.startswith('near_') or t in ('phase_early','phase_late','phase_unknown'):
            continue
        if t in TOKEN_BUCKETS: buckets.append(TOKEN_BUCKETS[t])
    # Important: signature intentionally does not include absolute epoch, but does include temporal reliability bucket.
    # This lets memory learn contradictions from validator outcomes rather than reading hidden phase labels.
    c=Counter(buckets)
    core='|'.join(sorted(k for k,v in c.items() if v==max(c.values(), default=1) or k=='temporal_reliability'))
    return stable_hash(core or 'empty')[:16]

def phase_for(issue,cfg):
    if issue['epoch'] < cfg['inversion_epoch']: return 'early'
    return 'late'

def best_action(issue,cfg):
    f=FAMILIES[issue['hidden_family']]
    if f['kind']=='stable': return f['best']
    return f[phase_for(issue,cfg)]

def bad_actions(issue,cfg):
    f=FAMILIES[issue['hidden_family']]
    if f['kind']=='stable': return set(f['bad'])
    return set(f['bad_'+phase_for(issue,cfg)])

def issue_stream(cfg):
    rng=random.Random(cfg['seed'])
    rows=[]; idx=0
    families=list(FAMILIES)
    for epoch in range(cfg['num_epochs']):
        split='calibration' if epoch<cfg['calibration_epochs'] else 'heldout'
        for fam in families:
            reps=cfg['issues_per_family_per_epoch']
            # inversion families have a short gap around inversion, then repeat after drift
            if FAMILIES[fam]['kind']=='inversion' and epoch in (cfg['inversion_epoch']-1,): reps=1
            for rep in range(reps):
                idx+=1; tokens=list(FAMILIES[fam]['tokens']); drifted=False
                if split=='heldout' and rng.random()<cfg['surface_drift_rate']:
                    repl=[i for i,t in enumerate(tokens) if t in DRIFT]
                    if repl:
                        j=rng.choice(repl); tokens[j]=DRIFT[tokens[j]]; drifted=True
                if split=='heldout' and rng.random()<cfg['near_match_pressure']:
                    tokens.append('near_'+str(rng.randrange(7)))
                if rng.random()<0.20: tokens.append('noise_'+str(rng.randrange(12)))
                # Visible phase token is deliberately weak/ambiguous and not enough to know safe action.
                if FAMILIES[fam]['kind']=='inversion' and epoch>=cfg['inversion_epoch'] and rng.random()<cfg['visible_drift_hint_rate']:
                    tokens.append('phase_unknown')
                rows.append({'issue_id':'issue_'+stable_hash(f'{idx}|{epoch}|{fam}|xi')[:12],
                             'epoch':epoch,'split':split,'hidden_family':fam,'tokens':tokens,'surface':' '.join(tokens),
                             'drifted':int(drifted),'temporal_family':int(FAMILIES[fam]['kind']=='inversion'),
                             'temporal_phase': phase_for({'epoch':epoch,'hidden_family':fam},cfg) if FAMILIES[fam]['kind']=='inversion' else 'stable'})
    rows.sort(key=lambda r:(r['epoch'],r['issue_id']))
    return rows

def validator_model(issue,action,cfg, noisy=False, rng=None, noise_rate=0.02):
    best=best_action(issue,cfg); bad=bad_actions(issue,cfg)
    if action==best:
        prod=0.0 if action in ('quarantine','safe_death') else 1.0
        out={'maintenance_success':1.0,'productive_repair':prod,'human_required':0.0,'corruption':0.0,'hidden_downstream_pass':1.0,
             'action_cost':{'light_validate':0.025,'targeted_repair':0.080,'bounded_rebuild':0.180,'quarantine':0.045,'safe_death':0.035}[action],
             'changed_lines':{'light_validate':0,'targeted_repair':3,'bounded_rebuild':14,'quarantine':0,'safe_death':0}[action]}
    elif action in bad:
        out={'maintenance_success':0.0,'productive_repair':0.0,'human_required':1.0,'corruption':1.0,'hidden_downstream_pass':0.0,
             'action_cost':{'light_validate':0.025,'targeted_repair':0.075,'bounded_rebuild':0.215,'quarantine':0.045,'safe_death':0.035}[action],
             'changed_lines':{'light_validate':0,'targeted_repair':2,'bounded_rebuild':20,'quarantine':0,'safe_death':0}[action]}
    else:
        out={'maintenance_success':0.45,'productive_repair':0.0,'human_required':0.55,'corruption':0.18,'hidden_downstream_pass':0.45,'action_cost':0.058,'changed_lines':1.0}
    if noisy and rng and rng.random()<noise_rate:
        # noisy immediate validator disagreement does not alter the delayed hidden score used for final scoring
        out=dict(out); out['maintenance_success']=1.0-out['maintenance_success'] if out['maintenance_success'] in (0.0,1.0) else out['maintenance_success']
    return out

def candidate_actions(tokens):
    s=evidence_set(tokens); c=['light_validate']
    if {'local_failure','tests_present','small_delta','repairable','previously_terminal','reopened_signal','variance_recovered','salvage_signal'} & s:
        c+=['targeted_repair','quarantine','safe_death']
    if {'artifact_stale','dependency_shift','rebuild_safe'} & s:
        c+=['bounded_rebuild','targeted_repair','quarantine']
    if {'corruption_recurrence','validator_conflict','hidden_risk'} & s:
        c+=['quarantine','targeted_repair','bounded_rebuild']
    if {'low_entropy','orbit_len_one','terminal_signal'} & s:
        c+=['safe_death','quarantine','targeted_repair']
    out=[]
    for a in c:
        if a not in out: out.append(a)
    return out

def base_action(issue):
    s=evidence_set(issue['tokens'])
    if 'artifact_stale' in s or 'dependency_shift' in s: return 'bounded_rebuild'
    if 'corruption_recurrence' in s or 'validator_conflict' in s: return 'quarantine'
    if 'low_entropy' in s or 'orbit_len_one' in s: return 'safe_death'
    if 'previously_terminal' in s or 'reopened_signal' in s or 'variance_recovered' in s: return 'quarantine'
    return 'targeted_repair'

def utility(out): return out['hidden_downstream_pass'] - out['corruption'] + out['productive_repair']

class TemporalMemory:
    def __init__(self, mode='balanced', decay=True, quarantine=True):
        self.mode=mode; self.decay=decay; self.quarantine=quarantine
        self.records=defaultdict(lambda: defaultdict(lambda:{'pos':0.0,'neg':0.0,'n':0,'last_epoch':-999,'contradictions':0,'quarantined_until':-1}))
        self.audit=[]
    def age_decay(self, rec, epoch):
        if not self.decay: return
        gap=max(0,epoch-rec['last_epoch'])
        if gap>0:
            factor=0.86**min(gap,8)
            rec['pos']*=factor; rec['neg']*=factor
    def recommend(self, sig, issue, candidates):
        epoch=int(issue['epoch'])
        # avoidance-first check: when the current base action has become contradicted, do not let
        # stale productive memory cling to it. This is the xi-specific quarantine/decay behavior.
        b=base_action(issue); brec=self.records[sig][b]; self.age_decay(brec,epoch)
        if brec['neg']-brec['pos'] > 0.55:
            alt=self.best_evidence_alternative(issue,candidates,b)
            return alt,'stale_avoidance_transfer'
        best=None; best_score=-99
        for a in candidates:
            rec=self.records[sig][a]
            self.age_decay(rec, epoch)
            if self.quarantine and epoch < rec['quarantined_until']:
                continue
            score=rec['pos']-rec['neg']
            min_score=0.42 if self.mode=='balanced' else 0.65
            if rec['n']>=1 and score>=min_score and a!=b and score>best_score:
                best=a; best_score=score
            elif rec['n']>=1 and score>=min_score+0.25 and score>best_score:
                best=a; best_score=score
        if best:
            return best,'temporal_memory_transfer'
        return None,'abstain_due_to_low_confidence'
    def best_evidence_alternative(self,issue,candidates,avoid):
        s=evidence_set(issue['tokens'])
        prefs=[]
        if {'corruption_recurrence','validator_conflict','hidden_risk'} & s: prefs=['quarantine','targeted_repair','bounded_rebuild']
        elif {'previously_terminal','reopened_signal','variance_recovered','salvage_signal','small_delta','repairable'} & s: prefs=['targeted_repair','quarantine','safe_death']
        elif {'artifact_stale','dependency_shift'} & s: prefs=['targeted_repair','bounded_rebuild','quarantine']
        elif {'low_entropy','orbit_len_one'} & s: prefs=['targeted_repair','safe_death','quarantine']
        else: prefs=['targeted_repair','quarantine','bounded_rebuild','safe_death']
        for p in prefs:
            if p in candidates and p!=avoid: return p
        return candidates[0]
    def update(self, sig, issue, action, out, rng, poisoned=False):
        epoch=int(issue['epoch']); rec=self.records[sig][action]
        self.age_decay(rec,epoch)
        old_pos,old_neg=rec['pos'],rec['neg']
        good=out['hidden_downstream_pass']>=0.9 and out['corruption']<=0.05
        bad=out['corruption']>=0.5 or out['hidden_downstream_pass']<=0.1
        if poisoned and rng.random()<0.18:
            good,bad=bad,good
        if good:
            rec['pos']+=0.78 + (0.20 if out['productive_repair']>=0.9 else 0.0)
        if bad:
            rec['neg']+=0.92
        rec['n']+=1; rec['last_epoch']=epoch
        contradiction=False
        if old_pos>0.45 and bad:
            rec['contradictions']+=1; contradiction=True
            if self.quarantine: rec['quarantined_until']=epoch+2
        if old_neg>0.45 and good:
            rec['contradictions']+=1; contradiction=True
            # reopened action: reduce stale avoidance faster
            rec['neg']*=0.35
        if contradiction:
            self.audit.append({'issue_id':issue['issue_id'],'epoch':epoch,'signature':sig,'action':action,'event':'contradiction_detected','quarantined_until':rec['quarantined_until'],'pos':rec['pos'],'neg':rec['neg']})
        return contradiction

def probe_order(tokens,candidates,chosen):
    prefs=[chosen]+candidates+['targeted_repair','quarantine','bounded_rebuild','safe_death','light_validate']
    out=[]
    for a in prefs:
        if a in ACTIONS and a in candidates and a not in out: out.append(a)
    return out

def run_runtime(runtime, issues, cfg):
    rng=random.Random(cfg['seed']+int(stable_hash(runtime)[:8],16)%100000)
    rows=[]; transfers=[]; memlog=[]; probes=[]; stale_audit=[]
    mem=TemporalMemory(decay=(runtime!='controllergate_predefined_memory'), quarantine=(runtime!='controllergate_predefined_memory'))
    # predefined gets calibration and early heldout before inversion, but freezes at inversion boundary.
    if runtime=='controllergate_predefined_memory':
        for issue in issues:
            if issue['split']=='calibration' or (issue['split']=='heldout' and int(issue['epoch'])<cfg['inversion_epoch']):
                sig=signature(issue['tokens']); act=base_action(issue)
                for a in probe_order(issue['tokens'],candidate_actions(issue['tokens']),act)[:cfg['counterfactual_probe_budget_max']]:
                    mem.update(sig,issue,a,validator_model(issue,a,cfg,False,rng),rng,False)
    for issue in issues:
        sig=signature(issue['tokens']); cand=candidate_actions(issue['tokens'])
        source='base'
        if runtime=='strengthened_best_practice':
            # non-memory best practice is conservative; it avoids aggressive productive repair under uncertainty
            act='quarantine' if issue['temporal_family'] else ('bounded_rebuild' if 'artifact_stale' in evidence_set(issue['tokens']) else 'light_validate')
        elif runtime=='always_rebuild': act='bounded_rebuild'
        elif runtime=='stateless_agent': act='light_validate'
        elif runtime=='null_shuffle': act=rng.choice(ACTIONS)
        elif runtime=='controllergate_no_memory': act=base_action(issue)
        elif runtime in ('controllergate_discovered_memory','controllergate_poisoned_memory','controllergate_predefined_memory'):
            rec,source=mem.recommend(sig,issue,cand)
            act=rec if rec else base_action(issue)
        else: act=base_action(issue)
        out=validator_model(issue,act,cfg,False,rng)
        rows.append({'runtime':runtime,'issue_id':issue['issue_id'],'epoch':issue['epoch'],'split':issue['split'],'hidden_family':issue['hidden_family'],'temporal_family':issue['temporal_family'],'temporal_phase':issue['temporal_phase'],'signature':sig,'action':act,'memory_source':source,**out})
        base=base_action(issue); base_out=validator_model(issue,base,cfg,False,rng)
        if runtime in ('controllergate_discovered_memory','controllergate_poisoned_memory','controllergate_predefined_memory'):
            transfers.append({'runtime':runtime,'issue_id':issue['issue_id'],'split':issue['split'],'epoch':issue['epoch'],'hidden_family':issue['hidden_family'],'temporal_family':issue['temporal_family'],'temporal_phase':issue['temporal_phase'],'signature':sig,'memory_source':source,'base_action':base,'chosen_action':act,'helped':int(utility(out)>utility(base_out)),'hurt':int(utility(out)<utility(base_out)),'stale_cling':int(issue['temporal_family'] and issue['temporal_phase']=='late' and act in (FAMILIES[issue['hidden_family']].get('early'),) and out['hidden_downstream_pass']<0.5),'post_inversion':int(issue['temporal_family'] and issue['temporal_phase']=='late')})
        if runtime in ('controllergate_discovered_memory','controllergate_poisoned_memory'):
            for a in probe_order(issue['tokens'],cand,act)[:rng.randint(cfg['counterfactual_probe_budget_min'],cfg['counterfactual_probe_budget_max'])]:
                po=validator_model(issue,a,cfg,True,rng,cfg['validator_noise_rate']); probes.append({'runtime':runtime,'issue_id':issue['issue_id'],'split':issue['split'],'epoch':issue['epoch'],'signature':sig,'probe_action':a,**po})
                before=len(mem.audit); contrad=mem.update(sig,issue,a,po,rng,runtime=='controllergate_poisoned_memory')
                if contrad and len(mem.audit)>before: stale_audit.append(mem.audit[-1])
                memlog.append({'runtime':runtime,'issue_id':issue['issue_id'],'split':issue['split'],'epoch':issue['epoch'],'signature':sig,'memory_channel':'temporal_update','action':a,'contradiction':int(contrad),'hidden_downstream_pass':po['hidden_downstream_pass'],'corruption':po['corruption']})
        # predefined is frozen after inversion: no heldout updates after inversion.
    return rows,transfers,memlog,probes,stale_audit

def write_csv(path, rows):
    path=Path(path)
    if not rows: path.write_text(''); return
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
    cfg=json.loads(Path(args.config).read_text()); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    issues=issue_stream(cfg)
    allrows=[]; alltrans=[]; allmem=[]; allprobes=[]; allaudit=[]
    runtimes=['strengthened_best_practice','always_rebuild','stateless_agent','null_shuffle','controllergate_no_memory','controllergate_poisoned_memory','controllergate_predefined_memory','controllergate_discovered_memory']
    for rt in runtimes:
        rows,tr,ml,pr,au=run_runtime(rt,issues,cfg); allrows+=rows; alltrans+=tr; allmem+=ml; allprobes+=pr; allaudit+=au
    write_csv(out/'trial_log.csv',allrows)
    write_csv(out/'memory_transfer_class_report.csv',alltrans)
    write_csv(out/'memory_channel_log.csv',allmem)
    write_csv(out/'counterfactual_probe_log.csv',allprobes)
    write_csv(out/'stale_lesson_audit.csv',allaudit)
    write_csv(out/'issue_registry.csv',[{'issue_id':i['issue_id'],'epoch':i['epoch'],'split':i['split'],'hidden_family':i['hidden_family'],'temporal_family':i['temporal_family'],'temporal_phase':i['temporal_phase'],'drifted':i['drifted'],'issue_hash':stable_hash(i['surface'])} for i in issues])
    write_csv(out/'calibration_policy_report.csv',[{'policy':'balanced','split':'calibration','selected':'True','selection_rule':'freeze balanced temporal memory; use confidence aging, contradiction detection, and stale-lesson quarantine after calibration'}])
    proof=[{'issue_id':r['issue_id'],'runtime':r['runtime'],'split':r['split'],'epoch':r['epoch'],'action':r['action'],'proof_hash':stable_hash(json.dumps(r,sort_keys=True))} for r in allrows]
    write_csv(out/'proof_ledger.csv',proof)
    Path(out/'proof_ledger.md').write_text('# v1.6-xi Proof Ledger\n\nEvery scored trial includes runtime, split, epoch, temporal phase, action, outcome, and proof hash. The discovered-memory runtime uses confidence aging, contradiction detection, and stale-lesson quarantine under temporal reliability inversion.\n')
    audit={'policy_blind':True,'safe_action_oracle_used':False,'valid_action_oracle_used':False,'calibration_then_heldout':True,'frozen_policy':'balanced','temporal_reliability_inversion':True,'memory_decay_enabled':True,'confidence_aging_enabled':True,'contradiction_detection_enabled':True,'stale_lesson_quarantine_enabled':True,'predefined_memory_frozen_after_inversion':True,'note':'Hidden best actions are used only by validator_model/scoring. Policies see evidence tokens, signatures, and validator-confirmed probe outcomes; discovered memory revises records through outcome contradictions rather than hidden labels.'}
    Path(out/'audit.json').write_text(json.dumps(audit,indent=2))
if __name__=='__main__': main()
