
import argparse,csv,json,collections
from pathlib import Path

def read_csv(p):
    p=Path(p)
    if not p.exists() or p.stat().st_size==0: return []
    with p.open(newline='') as f: return list(csv.DictReader(f))
def mean(rs,k):
    vals=[float(r[k]) for r in rs]
    return sum(vals)/len(vals) if vals else 0.0
def write_csv(p,rows):
    p=Path(p)
    if not rows: p.write_text(''); return
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--outputs',required=True); args=ap.parse_args(); out=Path(args.outputs)
    rows=read_csv(out/'trial_log.csv'); held=[r for r in rows if r['split']=='heldout']
    by=collections.defaultdict(list)
    for r in held: by[r['runtime']].append(r)
    summary=[]
    for rt,rs in sorted(by.items()):
        summary.append({'runtime':rt,'maintenance_success':mean(rs,'maintenance_success'),'productive_repair':mean(rs,'productive_repair'),'human_required':mean(rs,'human_required'),'corruption':mean(rs,'corruption'),'action_cost':mean(rs,'action_cost'),'changed_lines':mean(rs,'changed_lines'),'hidden_downstream_pass':mean(rs,'hidden_downstream_pass')})
    write_csv(out/'summary_by_runtime.csv',summary); S={s['runtime']:s for s in summary}
    cg=S['controllergate_discovered_memory']; nomem=S['controllergate_no_memory']; bp=S['strengthened_best_practice']; rb=S['always_rebuild']; poison=S['controllergate_poisoned_memory']; pre=S['controllergate_predefined_memory']
    trans=read_csv(out/'memory_transfer_class_report.csv')
    disc=[t for t in trans if t['runtime']=='controllergate_discovered_memory' and t['split']=='heldout']
    helped=sum(int(t['helped']) for t in disc); hurt=sum(int(t['hurt']) for t in disc); false_positive=hurt/max(1,helped+hurt)
    source_counts=collections.Counter(t['memory_source'] for t in disc)
    prod_recs=[r for r in by['controllergate_discovered_memory'] if r['memory_source']=='temporal_memory_transfer']
    prod_precision=sum(1 for r in prod_recs if float(r['hidden_downstream_pass'])>=0.9 and float(r['corruption'])<=0.05)/max(1,len(prod_recs))
    avoid=[t for t in disc if t['memory_source']=='stale_avoidance_transfer']
    avoid_precision=(len(avoid)-sum(int(t['hurt']) for t in avoid))/max(1,len(avoid))
    temporal=lambda r: r.get('temporal_family') in ('1',1,True,'True')
    late=lambda r: temporal(r) and r.get('temporal_phase')=='late'
    early=lambda r: temporal(r) and r.get('temporal_phase')=='early'
    def avg(rt,pred,k): return mean([r for r in held if r['runtime']==rt and pred(r)],k)
    post_disc=avg('controllergate_discovered_memory',late,'hidden_downstream_pass')
    post_pre=avg('controllergate_predefined_memory',late,'hidden_downstream_pass')
    post_no=avg('controllergate_no_memory',late,'hidden_downstream_pass')
    pre_disc=avg('controllergate_discovered_memory',early,'hidden_downstream_pass')
    pre_pre=avg('controllergate_predefined_memory',early,'hidden_downstream_pass')
    # stale clinging rates from transfer table
    disc_late=[t for t in disc if t['post_inversion']=='1']
    pre_late=[t for t in trans if t['runtime']=='controllergate_predefined_memory' and t['split']=='heldout' and t['post_inversion']=='1']
    discovered_stale_cling=sum(int(t['stale_cling']) for t in disc_late)/max(1,len(disc_late))
    predefined_stale_cling=sum(int(t['stale_cling']) for t in pre_late)/max(1,len(pre_late))
    stale_audit=read_csv(out/'stale_lesson_audit.csv')
    contradictions=len(stale_audit)
    # recovery: among late inversion issues, later half vs first two post-inversion epochs
    late_epochs=sorted(set(int(r['epoch']) for r in held if late(r)))
    first_late=set(late_epochs[:2]); later_late=set(late_epochs[2:])
    first_post=avg('controllergate_discovered_memory',lambda r: late(r) and int(r['epoch']) in first_late,'hidden_downstream_pass')
    later_post=avg('controllergate_discovered_memory',lambda r: late(r) and int(r['epoch']) in later_late,'hidden_downstream_pass')
    relearning_lift=later_post-first_post
    audit=json.loads((out/'audit.json').read_text())
    mem_metrics={'productive_lift_vs_no_memory':cg['productive_repair']-nomem['productive_repair'],'hidden_downstream_lift_vs_no_memory':cg['hidden_downstream_pass']-nomem['hidden_downstream_pass'],'corruption_reduction_vs_no_memory':nomem['corruption']-cg['corruption'],'memory_false_positive_transfer_rate':false_positive,'productive_recommendation_precision':prod_precision,'avoidance_transfer_precision':avoid_precision,'memory_helped':helped,'memory_hurt':hurt,'abstained_due_to_low_confidence':source_counts.get('abstain_due_to_low_confidence',0),'memory_source_counts':dict(source_counts),'selected_policy':'balanced','pre_inversion_discovered_hidden':pre_disc,'pre_inversion_predefined_hidden':pre_pre,'post_inversion_discovered_hidden':post_disc,'post_inversion_predefined_hidden':post_pre,'post_inversion_no_memory_hidden':post_no,'post_inversion_discovered_vs_predefined_gap':post_disc-post_pre,'post_inversion_discovered_vs_no_memory_gap':post_disc-post_no,'discovered_stale_cling_rate':discovered_stale_cling,'predefined_stale_cling_rate':predefined_stale_cling,'stale_cling_reduction_vs_predefined':predefined_stale_cling-discovered_stale_cling,'contradictions_detected':contradictions,'first_post_inversion_hidden':first_post,'later_post_inversion_hidden':later_post,'post_inversion_relearning_lift':relearning_lift,'memory_decay_enabled':audit.get('memory_decay_enabled') is True,'confidence_aging_enabled':audit.get('confidence_aging_enabled') is True,'stale_lesson_quarantine_enabled':audit.get('stale_lesson_quarantine_enabled') is True,'predefined_memory_frozen_after_inversion':audit.get('predefined_memory_frozen_after_inversion') is True,'poisoned_memory_not_outperform':poison['hidden_downstream_pass']<=cg['hidden_downstream_pass']}
    (out/'memory_ablation_report.json').write_text(json.dumps(mem_metrics,indent=2)); write_csv(out/'productive_memory_report.csv',[mem_metrics])
    criteria=[]
    def add(name,value,passed,threshold=''): criteria.append({'criterion':name,'value':value,'threshold':threshold,'passed':bool(passed)})
    add('policy blindness passes',1,audit.get('policy_blind') is True,'true')
    add('no safe_action oracle injection',1,audit.get('safe_action_oracle_used') is False and audit.get('valid_action_oracle_used') is False,'true')
    add('maintenance success noninferior to best practice',cg['maintenance_success'],cg['maintenance_success']>=bp['maintenance_success']-0.02,f">={bp['maintenance_success']-0.02:.3f}")
    add('corruption <= best practice',cg['corruption'],cg['corruption']<=bp['corruption']+1e-9,f"<={bp['corruption']:.3f}")
    add('hidden downstream pass noninferior to best practice',cg['hidden_downstream_pass'],cg['hidden_downstream_pass']>=bp['hidden_downstream_pass']-0.02,f">={bp['hidden_downstream_pass']-0.02:.3f}")
    add('action cost lower than always rebuild',cg['action_cost'],cg['action_cost']<rb['action_cost'],f"<{rb['action_cost']:.3f}")
    add('productive lift vs no-memory > 0',mem_metrics['productive_lift_vs_no_memory'],mem_metrics['productive_lift_vs_no_memory']>0,'>0')
    add('hidden downstream lift vs no-memory > 0',mem_metrics['hidden_downstream_lift_vs_no_memory'],mem_metrics['hidden_downstream_lift_vs_no_memory']>0,'>0')
    add('corruption reduction vs no-memory > 0',mem_metrics['corruption_reduction_vs_no_memory'],mem_metrics['corruption_reduction_vs_no_memory']>0,'>0')
    add('memory false-positive transfer <= 0.20',false_positive,false_positive<=0.20,'<=0.20')
    add('poisoned memory does not outperform discovered memory',1 if mem_metrics['poisoned_memory_not_outperform'] else 0,mem_metrics['poisoned_memory_not_outperform'],'true')
    add('memory helped more than hurt',helped-hurt,helped>hurt,'>0')
    add('productive recommendation precision >= 0.70',prod_precision,prod_precision>=0.70,'>=0.70')
    add('avoidance transfer precision >= 0.70',avoid_precision,avoid_precision>=0.70,'>=0.70')
    add('temporal reliability inversion present',1,audit.get('temporal_reliability_inversion') is True,'true')
    add('memory decay enabled',1 if mem_metrics['memory_decay_enabled'] else 0,mem_metrics['memory_decay_enabled'],'true')
    add('contradiction detection enabled and used',contradictions,contradictions>=4,'>=4 contradiction events')
    add('stale-lesson quarantine enabled',1 if mem_metrics['stale_lesson_quarantine_enabled'] else 0,mem_metrics['stale_lesson_quarantine_enabled'],'true')
    add('predefined memory frozen after inversion',1 if mem_metrics['predefined_memory_frozen_after_inversion'] else 0,mem_metrics['predefined_memory_frozen_after_inversion'],'true')
    add('discovered beats predefined after inversion',mem_metrics['post_inversion_discovered_vs_predefined_gap'],mem_metrics['post_inversion_discovered_vs_predefined_gap']>0.25,'>0.25 hidden gap')
    add('discovered reduces stale clinging vs predefined',mem_metrics['stale_cling_reduction_vs_predefined'],mem_metrics['stale_cling_reduction_vs_predefined']>0.25,'>0.25 cling reduction')
    add('post-inversion relearning lift > 0',relearning_lift,relearning_lift>0.05,'>0.05')
    add('proof ledger completeness = 100%',1,len(read_csv(out/'proof_ledger.csv'))==len(rows),'100%')
    report={'passed':sum(c['passed'] for c in criteria),'total':len(criteria),'criteria':criteria,'main_summary':summary,'memory_metrics':mem_metrics,'calibration_policy_report':read_csv(out/'calibration_policy_report.csv')}
    (out/'decision_report.json').write_text(json.dumps(report,indent=2)); print(json.dumps({'passed':report['passed'],'total':report['total']},indent=2))
if __name__=='__main__': main()
