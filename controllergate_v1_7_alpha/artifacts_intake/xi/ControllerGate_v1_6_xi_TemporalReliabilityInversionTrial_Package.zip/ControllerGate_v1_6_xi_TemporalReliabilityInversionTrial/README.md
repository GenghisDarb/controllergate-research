# ControllerGate v1.6-xi — Temporal Reliability Inversion Trial Prototype

Diagnostic prototype, not proof of self-maintaining software.

This trial tests whether discovered memory can age, revise, and quarantine stale lessons when action reliability inverts over time. It extends v1.6-nu by introducing temporal inversion families where an action that was previously productive becomes unsafe, or a previously avoided action becomes productive again after drift.

Verification commands:

```bash
python -m benchmarks.run_agent_maintenance_trial --config locks/v1_6_xi.json --out outputs
python -m benchmarks.analyze_agent_maintenance_trial --outputs outputs
sha256sum -c SHA256SUMS.txt
```
