# ControllerGate v1.6-omicron — Adversarial Stale-Memory Spoofing Trial Prototype

Diagnostic prototype, not proof of self-maintaining software.

Omicron preserves xi's temporal inversion setup but adds adversarial stale-memory spoofing: familiar signatures that preserve obsolete lessons, fake immediate validator passes, delayed contradiction evidence, near-match poisoning, and stale-memory bait cases.

Rerun:

```bash
python -m benchmarks.run_agent_maintenance_trial --config locks/v1_6_omicron.json --out outputs
python -m benchmarks.analyze_agent_maintenance_trial --outputs outputs
sha256sum -c SHA256SUMS.txt
```
