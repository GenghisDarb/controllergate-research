# v1.6-omicron Proof Ledger

Every scored trial includes runtime, split, epoch, attack class, visible signature, action, outcome, and proof hash. Omicron tests adversarial stale-memory spoofing with familiar signatures, delayed contradiction evidence, and fake early validator support.
