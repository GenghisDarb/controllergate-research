
import argparse,csv,json,collections
from pathlib import Path

def read_csv(p):
    p=Path(p)
    if not p.exists() or p.stat().st_size==0: return []
    with p.open(newline='') as f: return list(csv.DictReader(f))
def mean(rs,k):
    vals=[float(r[k]) for r in rs]
    return sum(vals)/len(vals) if vals else 0.0
def write_csv(p,rows):
    p=Path(p)
    if not rows: p.write_text(''); return
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--outputs',required=True); args=ap.parse_args(); out=Path(args.outputs)
    rows=read_csv(out/'trial_log.csv'); held=[r for r in rows if r['split']=='heldout']
    by=collections.defaultdict(list)
    for r in held: by[r['runtime']].append(r)
    summary=[]
    for rt,rs in sorted(by.items()):
        summary.append({'runtime':rt,'maintenance_success':mean(rs,'maintenance_success'),'productive_repair':mean(rs,'productive_repair'),'human_required':mean(rs,'human_required'),'corruption':mean(rs,'corruption'),'action_cost':mean(rs,'action_cost'),'changed_lines':mean(rs,'changed_lines'),'hidden_downstream_pass':mean(rs,'hidden_downstream_pass')})
    write_csv(out/'summary_by_runtime.csv',summary); S={s['runtime']:s for s in summary}
    cg=S['controllergate_discovered_memory']; nomem=S['controllergate_no_memory']; bp=S['strengthened_best_practice']; rb=S['always_rebuild']; poison=S['controllergate_poisoned_memory']; pre=S['controllergate_predefined_memory']
    trans=read_csv(out/'memory_transfer_class_report.csv')
    disc=[t for t in trans if t['runtime']=='controllergate_discovered_memory']
    helped=sum(int(t['helped']) for t in disc); hurt=sum(int(t['hurt']) for t in disc); false_positive=hurt/max(1,helped+hurt)
    source_counts=collections.Counter(t['memory_source'] for t in disc)
    prod_recs=[r for r in by['controllergate_discovered_memory'] if r['memory_source'] in ('adversarial_memory_revised','near_match_skeptical_transfer')]
    prod_precision=sum(1 for r in prod_recs if float(r['hidden_downstream_pass'])>=0.9 and float(r['corruption'])<=0.05)/max(1,len(prod_recs))
    avoid=[t for t in disc if t['memory_source'] in ('near_match_skeptical_transfer','adversarial_memory_revised')]
    avoid_precision=(len(avoid)-sum(int(t['hurt']) for t in avoid))/max(1,len(avoid))
    spoof=read_csv(out/'adversarial_spoofing_audit.csv')
    def audit_rows(rt, attacks=None):
        rs=[r for r in spoof if r['runtime']==rt]
        if attacks: rs=[r for r in rs if r['attack'] in attacks]
        return rs
    attacks=('spoofed_stale_bait','delayed_contradiction','near_match_poison')
    disc_spoof=audit_rows('controllergate_discovered_memory',attacks)
    pre_spoof=audit_rows('controllergate_predefined_memory',attacks)
    poison_spoof=audit_rows('controllergate_poisoned_memory',attacks)
    no_spoof=audit_rows('controllergate_no_memory',attacks)
    spoof_disc_hidden=mean(disc_spoof,'hidden_downstream_pass')
    spoof_pre_hidden=mean(pre_spoof,'hidden_downstream_pass')
    spoof_poison_hidden=mean(poison_spoof,'hidden_downstream_pass')
    spoof_no_hidden=mean(no_spoof,'hidden_downstream_pass')
    disc_cling=mean(disc_spoof,'stale_cling')
    pre_cling=mean(pre_spoof,'stale_cling')
    poison_cling=mean(poison_spoof,'stale_cling')
    fake_support=sum(int(r['fake_immediate_validator_pass']) for r in spoof)
    delayed_disc=audit_rows('controllergate_discovered_memory',('delayed_contradiction',))
    # sort by epoch; first half vs later half measures delayed contradiction recovery
    epochs=sorted(set(int(r['epoch']) for r in delayed_disc)); cut=len(epochs)//2 or 1; early=set(epochs[:cut]); late=set(epochs[cut:])
    delayed_first=mean([r for r in delayed_disc if int(r['epoch']) in early],'hidden_downstream_pass')
    delayed_later=mean([r for r in delayed_disc if int(r['epoch']) in late],'hidden_downstream_pass')
    audit=json.loads((out/'audit.json').read_text())
    mem_metrics={'productive_lift_vs_no_memory':cg['productive_repair']-nomem['productive_repair'],'hidden_downstream_lift_vs_no_memory':cg['hidden_downstream_pass']-nomem['hidden_downstream_pass'],'corruption_reduction_vs_no_memory':nomem['corruption']-cg['corruption'],'memory_false_positive_transfer_rate':false_positive,'productive_recommendation_precision':prod_precision,'avoidance_transfer_precision':avoid_precision,'memory_helped':helped,'memory_hurt':hurt,'abstained_due_to_low_confidence':source_counts.get('abstain_due_to_low_confidence',0),'memory_source_counts':dict(source_counts),'selected_policy':'balanced','spoofed_discovered_hidden':spoof_disc_hidden,'spoofed_predefined_hidden':spoof_pre_hidden,'spoofed_poisoned_hidden':spoof_poison_hidden,'spoofed_no_memory_hidden':spoof_no_hidden,'spoofed_discovered_vs_predefined_gap':spoof_disc_hidden-spoof_pre_hidden,'spoofed_discovered_vs_no_memory_gap':spoof_disc_hidden-spoof_no_hidden,'discovered_stale_cling_rate_under_spoofing':disc_cling,'predefined_stale_cling_rate_under_spoofing':pre_cling,'poisoned_stale_cling_rate_under_spoofing':poison_cling,'stale_cling_reduction_vs_predefined':pre_cling-disc_cling,'stale_cling_reduction_vs_poisoned':poison_cling-disc_cling,'fake_immediate_validator_passes':fake_support,'delayed_contradiction_first_hidden':delayed_first,'delayed_contradiction_later_hidden':delayed_later,'delayed_contradiction_recovery_lift':delayed_later-delayed_first,'adversarial_spoofing_enabled':audit.get('adversarial_stale_memory_spoofing') is True,'spoofed_signature_pressure':audit.get('spoofed_signature_pressure') is True,'delayed_contradiction_evidence':audit.get('delayed_contradiction_evidence') is True,'fake_productive_validator_passes':audit.get('fake_productive_validator_passes') is True,'poisoned_memory_not_outperform':poison['hidden_downstream_pass']<=cg['hidden_downstream_pass']}
    (out/'memory_ablation_report.json').write_text(json.dumps(mem_metrics,indent=2)); write_csv(out/'productive_memory_report.csv',[mem_metrics])
    criteria=[]
    def add(name,value,passed,threshold=''): criteria.append({'criterion':name,'value':value,'threshold':threshold,'passed':bool(passed)})
    add('policy blindness passes',1,audit.get('policy_blind') is True,'true')
    add('no safe_action oracle injection',1,audit.get('safe_action_oracle_used') is False and audit.get('valid_action_oracle_used') is False,'true')
    add('maintenance success noninferior to best practice',cg['maintenance_success'],cg['maintenance_success']>=bp['maintenance_success']-0.02,f">={bp['maintenance_success']-0.02:.3f}")
    add('corruption <= best practice',cg['corruption'],cg['corruption']<=bp['corruption']+1e-9,f"<={bp['corruption']:.3f}")
    add('hidden downstream pass noninferior to best practice',cg['hidden_downstream_pass'],cg['hidden_downstream_pass']>=bp['hidden_downstream_pass']-0.02,f">={bp['hidden_downstream_pass']-0.02:.3f}")
    add('action cost lower than always rebuild',cg['action_cost'],cg['action_cost']<rb['action_cost'],f"<{rb['action_cost']:.3f}")
    add('productive lift vs no-memory > 0',mem_metrics['productive_lift_vs_no_memory'],mem_metrics['productive_lift_vs_no_memory']>0,'>0')
    add('hidden downstream lift vs no-memory > 0',mem_metrics['hidden_downstream_lift_vs_no_memory'],mem_metrics['hidden_downstream_lift_vs_no_memory']>0,'>0')
    add('corruption reduction vs no-memory > 0',mem_metrics['corruption_reduction_vs_no_memory'],mem_metrics['corruption_reduction_vs_no_memory']>0,'>0')
    add('memory false-positive transfer <= 0.20',false_positive,false_positive<=0.20,'<=0.20')
    add('poisoned memory does not outperform discovered memory',1 if mem_metrics['poisoned_memory_not_outperform'] else 0,mem_metrics['poisoned_memory_not_outperform'],'true')
    add('memory helped more than hurt',helped-hurt,helped>hurt,'>0')
    add('productive recommendation precision >= 0.70',prod_precision,prod_precision>=0.70,'>=0.70')
    add('avoidance transfer precision >= 0.70',avoid_precision,avoid_precision>=0.70,'>=0.70')
    add('adversarial stale-memory spoofing present',1 if mem_metrics['adversarial_spoofing_enabled'] else 0,mem_metrics['adversarial_spoofing_enabled'],'true')
    add('spoofed signature pressure present',1 if mem_metrics['spoofed_signature_pressure'] else 0,mem_metrics['spoofed_signature_pressure'],'true')
    add('fake immediate validator passes present',fake_support,fake_support>=20,'>=20 bait passes')
    add('delayed contradiction evidence present',1 if mem_metrics['delayed_contradiction_evidence'] else 0,mem_metrics['delayed_contradiction_evidence'],'true')
    add('discovered beats predefined under spoofing',mem_metrics['spoofed_discovered_vs_predefined_gap'],mem_metrics['spoofed_discovered_vs_predefined_gap']>0.25,'>0.25 hidden gap')
    add('discovered beats no-memory under spoofing',mem_metrics['spoofed_discovered_vs_no_memory_gap'],mem_metrics['spoofed_discovered_vs_no_memory_gap']>0.25,'>0.25 hidden gap')
    add('discovered stale-cling rate under spoofing <= 0.25',disc_cling,disc_cling<=0.25,'<=0.25')
    add('discovered reduces stale clinging vs predefined',mem_metrics['stale_cling_reduction_vs_predefined'],mem_metrics['stale_cling_reduction_vs_predefined']>0.40,'>0.40')
    add('discovered reduces stale clinging vs poisoned',mem_metrics['stale_cling_reduction_vs_poisoned'],mem_metrics['stale_cling_reduction_vs_poisoned']>0.25,'>0.25')
    add('delayed contradiction recovery lift > 0',mem_metrics['delayed_contradiction_recovery_lift'],mem_metrics['delayed_contradiction_recovery_lift']>0.01,'>0.01')
    add('proof ledger completeness = 100%',1,len(read_csv(out/'proof_ledger.csv'))==len(rows),'100%')
    report={'passed':sum(c['passed'] for c in criteria),'total':len(criteria),'criteria':criteria,'main_summary':summary,'memory_metrics':mem_metrics,'calibration_policy_report':read_csv(out/'calibration_policy_report.csv')}
    (out/'decision_report.json').write_text(json.dumps(report,indent=2)); print(json.dumps({'passed':report['passed'],'total':report['total']},indent=2))
if __name__=='__main__': main()
