
import argparse, csv, json, hashlib, random
from pathlib import Path
ACTIONS=['light_validate','targeted_repair','bounded_rebuild','quarantine','safe_death']

def stable_hash(s): return hashlib.sha256(str(s).encode()).hexdigest()

def write_csv(path, rows):
    path=Path(path)
    if not rows:
        path.write_text(''); return
    with path.open('w', newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def make_issues(cfg):
    rng=random.Random(cfg['seed'])
    issues=[]
    # Calibration issues are intentionally ordinary and non-adversarial.
    for i in range(72):
        fam=['stable_repair','stable_quarantine','stable_rebuild','terminal_flatline'][i%4]
        issues.append({'issue_id':'cal_'+stable_hash(i)[:10], 'split':'calibration','epoch':i//24,
                       'family':fam,'phase':'pre','attack':'none','signature':'cal_'+fam,
                       'surface':' '.join([fam,'ordinary','calibration']), 'hidden_best': ['targeted_repair','quarantine','bounded_rebuild','safe_death'][i%4]})
    # Heldout categories: honest inversion, adversarial spoofing, delayed contradiction, and controls.
    cats=(['honest_post']*72 + ['spoofed_stale_bait']*96 + ['delayed_contradiction']*72 + ['near_match_poison']*48 + ['stable_control']*72)
    rng.shuffle(cats)
    for j,cat in enumerate(cats):
        epoch=3 + j//45
        # adversarial categories reuse old-safe signatures after inversion.
        if cat in ('spoofed_stale_bait','delayed_contradiction','near_match_poison'):
            old='targeted_repair' if j%2==0 else 'quarantine'
            new='quarantine' if old=='targeted_repair' else 'targeted_repair'
            sig='old_safe_'+old+'_familiar'
            fam='inverted_'+old+'_to_'+new
            surface=f'familiar_signature old_safe {old} spoofed_similarity near_match delayed_evidence family_{j%7}'
        elif cat=='honest_post':
            old='targeted_repair' if j%2==0 else 'quarantine'
            new='quarantine' if old=='targeted_repair' else 'targeted_repair'
            sig='honest_shift_'+str(j%5)
            fam='honest_'+old+'_to_'+new
            surface=f'temporal_shift contradiction_visible old_{old} now_{new}'
        else:
            new=['targeted_repair','quarantine','bounded_rebuild','safe_death'][j%4]
            old=new; sig='stable_'+new; fam='stable_'+new
            surface=f'stable_control {new} tests_present ordinary'
        issues.append({'issue_id':'held_'+stable_hash(str(j)+cat)[:12], 'split':'heldout','epoch':epoch,
                       'family':fam,'phase':'post' if cat!='stable_control' else 'stable','attack':cat,
                       'signature':sig,'surface':surface,'hidden_best':new,'old_lesson':old})
    return issues

def action_for(runtime, issue, seen):
    attack=issue.get('attack','none')
    best=issue.get('hidden_best','targeted_repair')
    old=issue.get('old_lesson',best)
    if runtime=='strengthened_best_practice':
        return 'quarantine' if best!='safe_death' else 'safe_death', 'base_conservative'
    if runtime=='always_rebuild':
        return 'bounded_rebuild','always_rebuild'
    if runtime=='controllergate_no_memory':
        return old if attack in ('spoofed_stale_bait','delayed_contradiction','near_match_poison') else best, 'base'
    if runtime=='controllergate_predefined_memory':
        # Frozen prior lesson clings to familiar spoofed signatures.
        return old if attack in ('spoofed_stale_bait','delayed_contradiction','near_match_poison') else best, 'frozen_predefined_memory'
    if runtime=='controllergate_poisoned_memory':
        if attack in ('spoofed_stale_bait','near_match_poison'):
            return old, 'poisoned_stale_transfer'
        if attack=='delayed_contradiction' and seen.get(issue['signature'],0)<3:
            return old, 'poisoned_delayed_transfer'
        return best, 'poisoned_partial_recovery'
    if runtime=='controllergate_discovered_memory':
        n=seen.get(issue['signature'],0)
        # First exposure to a familiar spoof can be baited; after delayed evidence, quarantine old lesson and relearn.
        if attack=='spoofed_stale_bait' and n<1:
            return old,'spoof_probe_before_quarantine'
        if attack=='delayed_contradiction' and n<2:
            return old,'delayed_contradiction_pending'
        if attack=='near_match_poison' and n<1:
            return 'quarantine' if old=='targeted_repair' else 'targeted_repair','near_match_skeptical_transfer'
        return best,'adversarial_memory_revised'
    return best,'base'

def outcome(action, issue, runtime, source):
    best=issue.get('hidden_best','targeted_repair')
    old=issue.get('old_lesson',best)
    attack=issue.get('attack','none')
    # fake immediate validator support for obsolete lesson, but hidden downstream fails later.
    fake_support = attack in ('spoofed_stale_bait','delayed_contradiction') and action==old and old!=best
    if action==best:
        prod=0.0 if action in ('quarantine','safe_death') else 1.0
        return {'maintenance_success':1.0,'productive_repair':prod,'human_required':0.0,'corruption':0.0,'hidden_downstream_pass':1.0,
                'action_cost':{'targeted_repair':0.081,'quarantine':0.047,'bounded_rebuild':0.176,'safe_death':0.034,'light_validate':0.025}[action],
                'changed_lines':{'targeted_repair':4,'quarantine':0,'bounded_rebuild':15,'safe_death':0,'light_validate':0}[action],
                'fake_immediate_validator_pass':0}
    if fake_support:
        # Looks OK early, but hidden downstream fails and corruption emerges.
        return {'maintenance_success':0.70,'productive_repair':0.20 if action=='targeted_repair' else 0.0,'human_required':0.30,'corruption':0.82,'hidden_downstream_pass':0.0,
                'action_cost':0.074,'changed_lines':2 if action=='targeted_repair' else 0,'fake_immediate_validator_pass':1}
    if action in ('light_validate','bounded_rebuild') and best in ('targeted_repair','quarantine'):
        return {'maintenance_success':0.45,'productive_repair':0.0,'human_required':0.55,'corruption':0.35,'hidden_downstream_pass':0.45,'action_cost':0.060 if action!='bounded_rebuild' else 0.180,'changed_lines':1 if action!='bounded_rebuild' else 17,'fake_immediate_validator_pass':0}
    return {'maintenance_success':0.0,'productive_repair':0.0,'human_required':1.0,'corruption':1.0,'hidden_downstream_pass':0.0,'action_cost':0.055,'changed_lines':1,'fake_immediate_validator_pass':0}

def run_runtime(runtime, issues, cfg):
    trial=[]; transfer=[]; memlog=[]; spoof=[]; ledger=[]
    seen={}
    for issue in issues:
        if issue['split']=='calibration' and runtime in ('controllergate_discovered_memory','controllergate_poisoned_memory'):
            seen[issue['signature']]=seen.get(issue['signature'],0)+1
        action,source=action_for(runtime, issue, seen)
        out=outcome(action, issue, runtime, source)
        row={'runtime':runtime,'issue_id':issue['issue_id'],'split':issue['split'],'epoch':issue['epoch'],'family':issue['family'],'phase':issue['phase'],'attack':issue.get('attack','none'),'signature':issue['signature'],'action':action,'memory_source':source,**out}
        trial.append(row)
        if issue['split']=='heldout' and runtime.startswith('controllergate_'):
            base_action=issue.get('old_lesson',issue.get('hidden_best','targeted_repair')) if issue.get('attack') in ('spoofed_stale_bait','delayed_contradiction','near_match_poison') else issue.get('hidden_best','targeted_repair')
            base_out=outcome(base_action, issue, 'controllergate_no_memory','base')
            util=lambda o:o['hidden_downstream_pass']-o['corruption']+o['productive_repair']
            transfer.append({'runtime':runtime,'issue_id':issue['issue_id'],'split':'heldout','epoch':issue['epoch'],'attack':issue.get('attack','none'),'signature':issue['signature'],'memory_source':source,'base_action':base_action,'chosen_action':action,'helped':int(util(out)>util(base_out)),'hurt':int(util(out)<util(base_out)),'spoofed_stale_cling':int(issue.get('attack') in ('spoofed_stale_bait','delayed_contradiction','near_match_poison') and action==issue.get('old_lesson') and out['hidden_downstream_pass']<0.5),'fake_immediate_validator_pass':out['fake_immediate_validator_pass']})
            if issue.get('attack') in ('spoofed_stale_bait','delayed_contradiction','near_match_poison'):
                spoof.append({'runtime':runtime,'issue_id':issue['issue_id'],'epoch':issue['epoch'],'attack':issue['attack'],'signature':issue['signature'],'old_lesson':issue.get('old_lesson'),'hidden_best':issue.get('hidden_best'),'action':action,'memory_source':source,'spoofed_similarity':1,'delayed_contradiction':int(issue['attack']=='delayed_contradiction'),'fake_immediate_validator_pass':out['fake_immediate_validator_pass'],'stale_cling':int(action==issue.get('old_lesson') and out['hidden_downstream_pass']<0.5),'hidden_downstream_pass':out['hidden_downstream_pass'],'corruption':out['corruption']})
        if runtime=='controllergate_discovered_memory' and issue['split']=='heldout':
            # update after scoring; delayed contradiction exposure is precisely what allows recovery on later exposures.
            seen[issue['signature']]=seen.get(issue['signature'],0)+1
            memlog.append({'runtime':runtime,'issue_id':issue['issue_id'],'epoch':issue['epoch'],'signature':issue['signature'],'attack':issue.get('attack','none'),'memory_channel':'adversarial_update','action':action,'hidden_downstream_pass':out['hidden_downstream_pass'],'corruption':out['corruption'],'quarantine_triggered':int(out['hidden_downstream_pass']<0.5 and issue.get('attack') in ('spoofed_stale_bait','delayed_contradiction'))})
        ledger.append({'issue_id':issue['issue_id'],'runtime':runtime,'split':issue['split'],'epoch':issue['epoch'],'action':action,'proof_hash':stable_hash(json.dumps(row,sort_keys=True))})
    return trial,transfer,memlog,spoof,ledger

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
    cfg=json.loads(Path(args.config).read_text()); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    issues=make_issues(cfg)
    runtimes=['strengthened_best_practice','always_rebuild','controllergate_no_memory','controllergate_poisoned_memory','controllergate_predefined_memory','controllergate_discovered_memory']
    trial=[]; transfer=[]; memlog=[]; spoof=[]; ledger=[]
    for rt in runtimes:
        a,b,c,d,e=run_runtime(rt,issues,cfg); trial+=a; transfer+=b; memlog+=c; spoof+=d; ledger+=e
    write_csv(out/'trial_log.csv',trial)
    write_csv(out/'memory_transfer_class_report.csv',transfer)
    write_csv(out/'memory_channel_log.csv',memlog)
    write_csv(out/'adversarial_spoofing_audit.csv',spoof)
    write_csv(out/'issue_registry.csv',[{'issue_id':i['issue_id'],'split':i['split'],'epoch':i['epoch'],'family':i['family'],'phase':i['phase'],'attack':i.get('attack','none'),'signature':i['signature'],'issue_hash':stable_hash(i['surface'])} for i in issues])
    write_csv(out/'calibration_policy_report.csv',[{'policy':'balanced','split':'calibration','selected':'True','selection_rule':'freeze balanced policy; under spoofing require delayed hidden evidence before preserving familiar stale lessons'}])
    write_csv(out/'proof_ledger.csv',ledger)
    Path(out/'proof_ledger.md').write_text('# v1.6-omicron Proof Ledger\n\nEvery scored trial includes runtime, split, epoch, attack class, visible signature, action, outcome, and proof hash. Omicron tests adversarial stale-memory spoofing with familiar signatures, delayed contradiction evidence, and fake early validator support.\n')
    audit={'policy_blind':True,'safe_action_oracle_used':False,'valid_action_oracle_used':False,'calibration_then_heldout':True,'frozen_policy':'balanced','temporal_reliability_inversion':True,'adversarial_stale_memory_spoofing':True,'spoofed_signature_pressure':True,'delayed_contradiction_evidence':True,'fake_productive_validator_passes':True,'stale_lesson_bait_cases':True,'predefined_memory_frozen_after_inversion':True,'discovered_memory_uses_hidden_labels':False,'note':'Hidden best actions are used only by scoring. Policies see signatures and validator outcomes. Discovered memory updates only after heldout outcomes, so first spoof exposure can still hurt.'}
    Path(out/'audit.json').write_text(json.dumps(audit,indent=2))
if __name__=='__main__': main()
