# Proof ledger

All trial rows carry deterministic proof_hash values. Hidden best actions are present only in registry/scoring artifacts and are not imported by any valid-action oracle.
