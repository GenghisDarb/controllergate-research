# ControllerGate v1.6-pi — Adaptive Adversary Counter-Quarantine Trial Prototype

Diagnostic prototype, not proof of self-maintaining software.

This package extends v1.6-omicron. Omicron tested fixed stale-memory spoofing. Pi tests an adaptive adversary that changes strategy after ControllerGate begins quarantining stale lessons.

Stressors:
- familiar stale signatures before quarantine;
- fake contradiction signals after quarantine begins;
- mutated familiar signatures;
- baited re-learning windows;
- intermittent delayed evidence;
- poisoned and predefined baselines that cling to obsolete lessons.

Verification commands:

```bash
python -m benchmarks.run_agent_maintenance_trial --config locks/v1_6_pi.json --out outputs
python -m benchmarks.analyze_agent_maintenance_trial --outputs outputs
sha256sum -c SHA256SUMS.txt
```
