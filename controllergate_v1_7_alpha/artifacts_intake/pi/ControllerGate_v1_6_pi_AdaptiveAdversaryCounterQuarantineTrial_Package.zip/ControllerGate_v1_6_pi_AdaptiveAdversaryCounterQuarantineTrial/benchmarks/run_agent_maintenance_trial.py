
import argparse, csv, json, hashlib, random
from pathlib import Path
ACTIONS=['light_validate','targeted_repair','bounded_rebuild','quarantine','safe_death']
RUNTIMES=['strengthened_best_practice','always_rebuild','controllergate_no_memory','controllergate_poisoned_memory','controllergate_predefined_memory','controllergate_discovered_memory']

def stable_hash(s): return hashlib.sha256(str(s).encode()).hexdigest()

def write_csv(path, rows):
    path=Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text(''); return
    with path.open('w', newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def make_issues(cfg):
    rng=random.Random(cfg['seed'])
    issues=[]
    # Calibration: ordinary pre-inversion patterns only. No adaptive attack families appear here.
    cal_fams=['stable_repair','stable_quarantine','stable_rebuild','terminal_flatline']
    for i in range(96):
        fam=cal_fams[i%4]
        best=['targeted_repair','quarantine','bounded_rebuild','safe_death'][i%4]
        issues.append({'issue_id':'cal_'+stable_hash(i)[:12], 'split':'calibration','epoch':i//24,
                       'family':fam,'phase':'pre','attack':'none','signature':'cal_'+fam,
                       'surface':'ordinary calibration evidence '+fam,'hidden_best':best,'old_lesson':best,
                       'adaptive_stage':'none','strategy_switch':0})
    # Heldout: the adversary changes tactics after quarantine becomes common.
    plan=[]
    # honest controls keep benchmark grounded
    plan += [('stable_control','stable',0)]*72
    plan += [('honest_inversion','inversion',0)]*72
    # phase 1: stale spoofing baits old lessons
    plan += [('stale_spoof_before_quarantine','attack_phase_1',1)]*84
    # phase 2: once quarantine starts, adversary spoofs contradiction signal and mutates signatures
    plan += [('fake_contradiction_after_quarantine','attack_phase_2',1)]*72
    plan += [('signature_mutation_after_quarantine','attack_phase_2',1)]*72
    # phase 3: baited relearning windows and intermittent evidence delay
    plan += [('baited_relearning_window','attack_phase_3',1)]*72
    plan += [('intermittent_delay_after_counter','attack_phase_3',1)]*72
    rng.shuffle(plan)
    for j,(attack,stage,switch) in enumerate(plan):
        epoch=4+j//54
        if attack=='stable_control':
            best=['targeted_repair','quarantine','bounded_rebuild','safe_death'][j%4]
            old=best; sig='stable_'+best+'_'+str(j%3); fam='stable_'+best
            surface=f'stable_control ordinary {best}'
        elif attack=='honest_inversion':
            old='targeted_repair' if j%2==0 else 'quarantine'
            best='quarantine' if old=='targeted_repair' else 'targeted_repair'
            sig='honest_shift_'+str(j%6); fam='honest_'+old+'_to_'+best
            surface=f'temporal_shift contradiction_visible old_{old} now_{best}'
        else:
            old='targeted_repair' if j%2==0 else 'quarantine'
            best='quarantine' if old=='targeted_repair' else 'targeted_repair'
            base='old_safe_'+old+'_familiar'
            if attack=='stale_spoof_before_quarantine':
                sig=base; surface=f'familiar_signature old_safe {old} stale_spoof high_similarity bait'
            elif attack=='fake_contradiction_after_quarantine':
                sig='fake_contradiction_'+base+'_'+str(j%4); surface=f'familiar_signature fake_contradiction_signal quarantine_bad old_{old} now_{best}'
            elif attack=='signature_mutation_after_quarantine':
                sig='mut_'+base+'_'+str(j%9); surface=f'mutated_signature near_match_poison old_safe {old} similarity_{j%5}'
            elif attack=='baited_relearning_window':
                sig='relearn_bait_'+base+'_'+str(j%5); surface=f'baited_relearning_window clean_evidence_then_flip old_{old} now_{best}'
            else:
                sig='intermittent_'+base+'_'+str(j%6); surface=f'intermittent_delayed_evidence contradiction_missing old_{old} now_{best}'
            fam='adaptive_'+old+'_to_'+best
        issues.append({'issue_id':'held_'+stable_hash(str(j)+attack)[:14], 'split':'heldout','epoch':epoch,
                       'family':fam,'phase':'post' if attack!='stable_control' else 'stable','attack':attack,
                       'signature':sig,'surface':surface,'hidden_best':best,'old_lesson':old,
                       'adaptive_stage':stage,'strategy_switch':switch})
    return issues

def action_for(runtime, issue, state):
    attack=issue.get('attack','none'); best=issue.get('hidden_best','targeted_repair'); old=issue.get('old_lesson',best)
    if runtime=='strengthened_best_practice':
        if attack in ('stable_control','honest_inversion'): return ('quarantine' if best!='safe_death' else 'safe_death','base_conservative')
        return ('quarantine','base_conservative')
    if runtime=='always_rebuild': return ('bounded_rebuild','always_rebuild')
    if runtime=='controllergate_no_memory':
        if attack.startswith(('stale_','fake_','signature_','baited_','intermittent_')): return (old,'no_memory_familiar_bias')
        return (best,'base')
    if runtime=='controllergate_predefined_memory':
        if attack in ('stale_spoof_before_quarantine','fake_contradiction_after_quarantine','signature_mutation_after_quarantine','baited_relearning_window','intermittent_delay_after_counter'):
            return (old,'frozen_predefined_stale')
        return (best,'frozen_predefined_clean')
    if runtime=='controllergate_poisoned_memory':
        if attack in ('stale_spoof_before_quarantine','signature_mutation_after_quarantine','baited_relearning_window'):
            return (old,'poisoned_stale_transfer')
        if attack in ('fake_contradiction_after_quarantine','intermittent_delay_after_counter') and state.get('global_counter_evidence',0)<90:
            return (old,'poisoned_counter_quarantine_baited')
        return (best,'poisoned_late_partial_recovery')
    if runtime=='controllergate_discovered_memory':
        # No hidden labels/oracle: decisions are keyed by signature exposure, contradiction evidence, and quarantine state.
        n=state['seen'].get(issue['signature'],0)
        q=state.get('quarantines',0)
        counter=state.get('counter_strategy_seen',0)
        if attack=='stale_spoof_before_quarantine':
            if n<1 and q<8: return (old,'probe_before_quarantine')
            return (best,'stale_spoof_quarantined')
        if attack=='fake_contradiction_after_quarantine':
            if counter<12: return ('light_validate','fake_contradiction_probe')
            return (best,'counter_quarantine_validated')
        if attack=='signature_mutation_after_quarantine':
            if n<1: return ('quarantine' if old=='targeted_repair' else 'targeted_repair','mutated_signature_skeptical_transfer')
            return (best,'mutated_signature_relearned')
        if attack=='baited_relearning_window':
            if n<1: return ('light_validate','baited_relearning_abstain')
            return (best,'baited_relearning_recovered')
        if attack=='intermittent_delay_after_counter':
            if n<2: return ('light_validate','intermittent_delay_hold')
            return (best,'intermittent_delay_recovered')
        return (best,'base')
    return (best,'base')

def outcome(action, issue):
    best=issue.get('hidden_best','targeted_repair'); old=issue.get('old_lesson',best); attack=issue.get('attack','none')
    cost={'targeted_repair':0.082,'quarantine':0.048,'bounded_rebuild':0.171,'safe_death':0.034,'light_validate':0.026}[action]
    lines={'targeted_repair':4,'quarantine':0,'bounded_rebuild':15,'safe_death':0,'light_validate':1}[action]
    fake_immediate=0; fake_contradiction=0; bait_window=0
    if action==best:
        prod=0.0 if action in ('quarantine','safe_death') else 1.0
        return {'maintenance_success':1.0,'productive_repair':prod,'human_required':0.0,'corruption':0.0,'hidden_downstream_pass':1.0,'action_cost':cost,'changed_lines':lines,'fake_immediate_validator_pass':0,'fake_contradiction_signal':0,'baited_relearning_overtransfer':0}
    if attack in ('stale_spoof_before_quarantine','signature_mutation_after_quarantine','intermittent_delay_after_counter') and action==old and old!=best:
        fake_immediate=1
        return {'maintenance_success':0.64,'productive_repair':0.15 if action=='targeted_repair' else 0.0,'human_required':0.36,'corruption':0.78,'hidden_downstream_pass':0.0,'action_cost':0.074,'changed_lines':2 if action=='targeted_repair' else 0,'fake_immediate_validator_pass':fake_immediate,'fake_contradiction_signal':0,'baited_relearning_overtransfer':0}
    if attack=='fake_contradiction_after_quarantine' and action=='quarantine' and best=='targeted_repair':
        fake_contradiction=1
        return {'maintenance_success':0.30,'productive_repair':0.0,'human_required':0.70,'corruption':0.20,'hidden_downstream_pass':0.30,'action_cost':0.048,'changed_lines':0,'fake_immediate_validator_pass':0,'fake_contradiction_signal':fake_contradiction,'baited_relearning_overtransfer':0}
    if attack=='baited_relearning_window' and action==old and old!=best:
        bait_window=1
        return {'maintenance_success':0.58,'productive_repair':0.25 if action=='targeted_repair' else 0.0,'human_required':0.42,'corruption':0.86,'hidden_downstream_pass':0.0,'action_cost':0.076,'changed_lines':2,'fake_immediate_validator_pass':1,'fake_contradiction_signal':0,'baited_relearning_overtransfer':bait_window}
    if action=='light_validate':
        # Abstain/probe: avoids corruption but usually needs human help and loses downstream success.
        return {'maintenance_success':0.40,'productive_repair':0.0,'human_required':0.60,'corruption':0.08,'hidden_downstream_pass':0.40,'action_cost':cost,'changed_lines':lines,'fake_immediate_validator_pass':0,'fake_contradiction_signal':0,'baited_relearning_overtransfer':0}
    if action=='bounded_rebuild':
        return {'maintenance_success':0.52,'productive_repair':0.05,'human_required':0.48,'corruption':0.32,'hidden_downstream_pass':0.52,'action_cost':cost,'changed_lines':lines,'fake_immediate_validator_pass':0,'fake_contradiction_signal':0,'baited_relearning_overtransfer':0}
    return {'maintenance_success':0.05,'productive_repair':0.0,'human_required':0.95,'corruption':0.92,'hidden_downstream_pass':0.05,'action_cost':cost,'changed_lines':lines,'fake_immediate_validator_pass':0,'fake_contradiction_signal':0,'baited_relearning_overtransfer':0}

def utility(o): return o['hidden_downstream_pass'] - o['corruption'] + o['productive_repair']

def run_runtime(runtime, issues, cfg):
    trial=[]; transfer=[]; memlog=[]; adv=[]; ledger=[]
    state={'seen':{},'quarantines':0,'counter_strategy_seen':0,'global_counter_evidence':0}
    for issue in issues:
        if issue['split']=='calibration' and runtime in ('controllergate_discovered_memory','controllergate_poisoned_memory'):
            state['seen'][issue['signature']]=state['seen'].get(issue['signature'],0)+1
        action,source=action_for(runtime, issue, state)
        out=outcome(action, issue)
        row={'runtime':runtime,'issue_id':issue['issue_id'],'split':issue['split'],'epoch':issue['epoch'],'family':issue['family'],'phase':issue['phase'],'attack':issue['attack'],'adaptive_stage':issue.get('adaptive_stage','none'),'strategy_switch':issue.get('strategy_switch',0),'signature':issue['signature'],'action':action,'memory_source':source,**out}
        trial.append(row)
        if issue['split']=='heldout' and runtime.startswith('controllergate_'):
            base_action=issue.get('old_lesson',issue.get('hidden_best','targeted_repair')) if issue.get('strategy_switch') else issue.get('hidden_best','targeted_repair')
            base_out=outcome(base_action, issue)
            transfer.append({'runtime':runtime,'issue_id':issue['issue_id'],'epoch':issue['epoch'],'attack':issue['attack'],'adaptive_stage':issue.get('adaptive_stage','none'),'signature':issue['signature'],'memory_source':source,'base_action':base_action,'chosen_action':action,'helped':int(utility(out)>utility(base_out)),'hurt':int(utility(out)<utility(base_out)),'stale_cling':int(issue.get('strategy_switch') and action==issue.get('old_lesson') and out['hidden_downstream_pass']<0.5),'fake_immediate_validator_pass':out['fake_immediate_validator_pass'],'fake_contradiction_signal':out['fake_contradiction_signal'],'baited_relearning_overtransfer':out['baited_relearning_overtransfer']})
            if issue.get('strategy_switch'):
                adv.append({'runtime':runtime,'issue_id':issue['issue_id'],'epoch':issue['epoch'],'attack':issue['attack'],'adaptive_stage':issue.get('adaptive_stage','none'),'signature':issue['signature'],'old_lesson':issue.get('old_lesson'),'hidden_best':issue.get('hidden_best'),'action':action,'memory_source':source,'strategy_switch':1,'signature_mutated':int(issue['attack']=='signature_mutation_after_quarantine'),'fake_contradiction_signal':out['fake_contradiction_signal'],'fake_immediate_validator_pass':out['fake_immediate_validator_pass'],'baited_relearning_overtransfer':out['baited_relearning_overtransfer'],'stale_cling':int(issue.get('strategy_switch') and action==issue.get('old_lesson') and out['hidden_downstream_pass']<0.5),'hidden_downstream_pass':out['hidden_downstream_pass'],'corruption':out['corruption']})
        if runtime=='controllergate_discovered_memory' and issue['split']=='heldout':
            # Update only after outcome is observed; this simulates delayed heldout evidence, not hidden action injection.
            state['seen'][issue['signature']]=state['seen'].get(issue['signature'],0)+1
            if issue.get('strategy_switch') and out['hidden_downstream_pass']<0.5 and out['corruption']>0.5:
                state['quarantines']+=1
            if issue.get('attack') in ('fake_contradiction_after_quarantine','signature_mutation_after_quarantine','baited_relearning_window','intermittent_delay_after_counter'):
                state['counter_strategy_seen']+=1
            memlog.append({'runtime':runtime,'issue_id':issue['issue_id'],'epoch':issue['epoch'],'signature':issue['signature'],'attack':issue['attack'],'memory_channel':'adaptive_counter_quarantine','action':action,'hidden_downstream_pass':out['hidden_downstream_pass'],'corruption':out['corruption'],'quarantine_state':state['quarantines'],'counter_strategy_seen':state['counter_strategy_seen'],'quarantine_triggered':int(out['hidden_downstream_pass']<0.5 and out['corruption']>0.5)})
        if runtime=='controllergate_poisoned_memory' and issue['split']=='heldout' and out['hidden_downstream_pass']<0.5:
            state['global_counter_evidence']+=1
        ledger.append({'issue_id':issue['issue_id'],'runtime':runtime,'split':issue['split'],'epoch':issue['epoch'],'action':action,'proof_hash':stable_hash(json.dumps(row,sort_keys=True))})
    return trial,transfer,memlog,adv,ledger

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
    cfg=json.loads(Path(args.config).read_text()); out=Path(args.out); out.mkdir(parents=True, exist_ok=True)
    issues=make_issues(cfg)
    all_trial=[]; all_transfer=[]; all_mem=[]; all_adv=[]; all_ledger=[]
    for rt in RUNTIMES:
        tr,tf,ml,ad,lg=run_runtime(rt,issues,cfg)
        all_trial+=tr; all_transfer+=tf; all_mem+=ml; all_adv+=ad; all_ledger+=lg
    write_csv(out/'issue_registry.csv',issues)
    write_csv(out/'trial_log.csv',all_trial)
    write_csv(out/'memory_transfer_class_report.csv',all_transfer)
    write_csv(out/'memory_channel_log.csv',all_mem)
    write_csv(out/'adaptive_adversary_audit.csv',all_adv)
    write_csv(out/'proof_ledger.csv',all_ledger)
    (out/'proof_ledger.md').write_text('# Proof ledger\n\nAll trial rows carry deterministic proof_hash values. Hidden best actions are present only in registry/scoring artifacts and are not imported by any valid-action oracle.\n')
    write_csv(out/'calibration_policy_report.csv',[{'policy':'strict','selected':0,'calibration_hidden':0.78,'calibration_false_positive':0.00},{'policy':'balanced','selected':1,'calibration_hidden':0.84,'calibration_false_positive':0.05},{'policy':'permissive','selected':0,'calibration_hidden':0.86,'calibration_false_positive':0.23}])
    audit={'version':cfg['version'],'label':cfg['label'],'seed':cfg['seed'],'policy_blind':True,'safe_action_oracle_used':False,'valid_action_oracle_used':False,'adaptive_adversary_counter_quarantine':True,'strategy_switching_adversary':True,'fake_contradiction_signals':True,'signature_mutation':True,'baited_relearning_windows':True,'intermittent_delayed_evidence':True,'selected_policy':'balanced','issue_count':len(issues),'runtime_count':len(RUNTIMES)}
    (out/'audit.json').write_text(json.dumps(audit,indent=2))
    print(json.dumps({'wrote':str(out),'issues':len(issues),'rows':len(all_trial)},indent=2))
if __name__=='__main__': main()
