# ControllerGate v1.6-nu — Sparse Recurrence Online Learning Trial Prototype

Status: diagnostic prototype, not proof of self-maintaining software.

This package tests whether online discovered memory still produces net positive lift when novel recurrence is sparse, delayed, and partially non-repeating. It extends v1.6-mu by adding heldout-only one-shot, two-shot, and long-gap sparse recurrence families while freezing predefined memory during heldout scoring.

Reproduce:

```bash
python -m benchmarks.run_agent_maintenance_trial --config locks/v1_6_nu.json --out outputs
python -m benchmarks.analyze_agent_maintenance_trial --outputs outputs
sha256sum -c SHA256SUMS.txt
```

Important interpretation: v1.6-nu is a controlled diagnostic benchmark. It does not prove self-maintaining software. It tests sparse online learning boundaries after kappa/lambda/mu established calibrated memory, drift tolerance, and discovered-vs-predefined separation.
