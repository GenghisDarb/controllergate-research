# v1.6-nu Proof Ledger

Every scored trial includes runtime, split, action, outcome, policy mode, drift metadata, and proof hash. Calibration selects and freezes the balanced memory threshold policy before heldout scoring with sparse novel recurrence, delayed outcomes, one-shot pressure, and frozen predefined memory.
