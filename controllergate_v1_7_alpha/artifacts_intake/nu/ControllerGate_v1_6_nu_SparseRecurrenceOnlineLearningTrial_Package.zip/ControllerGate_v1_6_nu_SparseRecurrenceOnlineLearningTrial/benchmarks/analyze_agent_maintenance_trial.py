import argparse, csv, json, collections
from pathlib import Path

def read_csv(path):
    if not Path(path).exists() or Path(path).stat().st_size == 0:
        return []
    with open(path,newline='') as f: return list(csv.DictReader(f))

def mean(rows,key):
    vals=[float(r[key]) for r in rows]
    return sum(vals)/len(vals) if vals else 0.0

def write_csv(path, rows):
    if not rows:
        Path(path).write_text('')
        return
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--outputs',required=True); args=ap.parse_args(); out=Path(args.outputs)
    rows=read_csv(out/'trial_log.csv')
    held=[r for r in rows if r.get('split')=='heldout']
    by=collections.defaultdict(list)
    for r in held: by[r['runtime']].append(r)
    summary=[]
    for rt,rs in sorted(by.items()):
        summary.append({'runtime':rt,'maintenance_success':mean(rs,'maintenance_success'),'productive_repair':mean(rs,'productive_repair'),
                        'human_required':mean(rs,'human_required'),'corruption':mean(rs,'corruption'),'action_cost':mean(rs,'action_cost'),
                        'changed_lines':mean(rs,'changed_lines'),'hidden_downstream_pass':mean(rs,'hidden_downstream_pass')})
    write_csv(out/'summary_by_runtime.csv', summary)
    S={s['runtime']:s for s in summary}
    cg=S['controllergate_discovered_memory']; nomem=S['controllergate_no_memory']; bp=S['strengthened_best_practice']; rb=S['always_rebuild']; poison=S['controllergate_poisoned_memory']; predef=S['controllergate_predefined_memory']
    transfers=read_csv(out/'memory_transfer_class_report.csv')
    disc=[t for t in transfers if t['runtime']=='controllergate_discovered_memory' and t.get('split')=='heldout']
    helped=sum(int(t['helped']) for t in disc); hurt=sum(int(t['hurt']) for t in disc)
    source_counts=collections.Counter(t['memory_source'] for t in disc)
    false_positive=hurt/max(1,helped+hurt)
    productive_recs=[r for r in by['controllergate_discovered_memory'] if r['memory_source']=='productive_recommendation']
    prod_precision=sum(1 for r in productive_recs if float(r['productive_repair'])>=0.9 and float(r['hidden_downstream_pass'])>=0.9 and float(r['corruption'])<=0.05)/max(1,len(productive_recs))
    avoidance=[t for t in disc if t['memory_source']=='avoidance_transfer']
    avoid_precision=(len(avoidance)-sum(int(t['hurt']) for t in avoidance))/max(1,len(avoidance))
    abstain=sum(1 for t in disc if t['memory_source']=='abstain_due_to_low_confidence')
    productive_lost=sum(int(t.get('productive_lost',0)) for t in disc)
    novel_families=set(r['hidden_family'] for r in held if r['hidden_family'].startswith('novel_'))
    calibration_novel_count=sum(1 for r in rows if r.get('split')=='calibration' and r.get('hidden_family','').startswith('novel_'))
    novel_absent_from_calibration = calibration_novel_count == 0 and len(novel_families) >= 3
    def avg_runtime(rt, predicate, key):
        rs=[r for r in held if r['runtime']==rt and predicate(r)]
        return sum(float(r[key]) for r in rs)/len(rs) if rs else 0.0
    novel_pred=lambda r: r['hidden_family'].startswith('novel_')
    discovered_vs_predefined_hidden_gap = cg['hidden_downstream_pass'] - predef['hidden_downstream_pass']
    discovered_vs_predefined_productive_gap = cg['productive_repair'] - predef['productive_repair']
    novel_discovered_hidden = avg_runtime('controllergate_discovered_memory', novel_pred, 'hidden_downstream_pass')
    novel_predefined_hidden = avg_runtime('controllergate_predefined_memory', novel_pred, 'hidden_downstream_pass')
    novel_no_memory_hidden = avg_runtime('controllergate_no_memory', novel_pred, 'hidden_downstream_pass')
    novel_discovered_vs_predefined_gap = novel_discovered_hidden - novel_predefined_hidden
    novel_discovered_vs_no_memory_gap = novel_discovered_hidden - novel_no_memory_hidden
    first_novel_epoch=min((int(r['epoch']) for r in held if r['hidden_family'].startswith('novel_')), default=999)
    first_novel_hidden=avg_runtime('controllergate_discovered_memory', lambda r: r['hidden_family'].startswith('novel_') and int(r['epoch'])==first_novel_epoch, 'hidden_downstream_pass')
    later_novel_hidden=avg_runtime('controllergate_discovered_memory', lambda r: r['hidden_family'].startswith('novel_') and int(r['epoch'])>first_novel_epoch, 'hidden_downstream_pass')
    online_novel_learning_lift = later_novel_hidden - first_novel_hidden
    # Nu sparse recurrence diagnostics: count one-shot/two-shot/long-gap exposure classes and test whether
    # discovered memory abstains on first/one-shot exposure while improving on later sparse recurrence.
    sparse_disc=[r for r in held if r['runtime']=='controllergate_discovered_memory' and r['hidden_family'].startswith('novel_')]
    sparse_classes=collections.Counter(r.get('sparse_exposure_class','unknown') for r in sparse_disc)
    one_shot=[r for r in sparse_disc if r.get('sparse_exposure_class')=='one_shot']
    two_shot=[r for r in sparse_disc if r.get('sparse_exposure_class')=='two_shot']
    long_gap=[r for r in sparse_disc if r.get('sparse_exposure_class')=='long_gap_sparse']
    one_shot_no_productive_overfit = all(r.get('memory_source')!='productive_recommendation' for r in one_shot) if one_shot else False
    sparse_later=[r for r in sparse_disc if int(r.get('sparse_exposure_index') or 0) > 1]
    sparse_first=[r for r in sparse_disc if int(r.get('sparse_exposure_index') or 0) == 1]
    sparse_first_hidden=sum(float(r['hidden_downstream_pass']) for r in sparse_first)/len(sparse_first) if sparse_first else 0.0
    sparse_later_hidden=sum(float(r['hidden_downstream_pass']) for r in sparse_later)/len(sparse_later) if sparse_later else 0.0
    sparse_later_lift=sparse_later_hidden-sparse_first_hidden

    # Recurrence metrics from heldout signatures: precision = dominant family fraction; recall = compact signature coverage.
    sig_to_fam=collections.defaultdict(list); fam_to_sig=collections.defaultdict(set)
    for r in by['controllergate_discovered_memory']:
        sig_to_fam[r['signature']].append(r['hidden_family']); fam_to_sig[r['hidden_family']].add(r['signature'])
    pure=total=0
    for sig,fams in sig_to_fam.items():
        c=collections.Counter(fams); pure += c.most_common(1)[0][1]; total += len(fams)
    precision=pure/total if total else 0.0
    recall=sum(1 for fam,sigs in fam_to_sig.items() if len(sigs)<=2)/max(1,len(fam_to_sig))
    cal=read_csv(out/'calibration_policy_report.csv')
    selected=[r for r in cal if r.get('selected')=='True']
    selected_policy=selected[0]['policy'] if selected else 'balanced'
    audit=json.loads((out/'audit.json').read_text()) if (out/'audit.json').exists() else {}
    mem_metrics={
        'productive_lift_vs_no_memory': cg['productive_repair']-nomem['productive_repair'],
        'hidden_downstream_lift_vs_no_memory': cg['hidden_downstream_pass']-nomem['hidden_downstream_pass'],
        'corruption_reduction_vs_no_memory': nomem['corruption']-cg['corruption'],
        'recurrence_match_precision': precision,
        'recurrence_match_recall': recall,
        'memory_false_positive_transfer_rate': false_positive,
        'productive_recommendation_precision': prod_precision,
        'avoidance_transfer_precision': avoid_precision,
        'memory_helped': helped,
        'memory_hurt': hurt,
        'abstained_due_to_low_confidence': abstain,
        'productive_opportunity_lost': productive_lost,
        'iota_reference_abstentions': 98,
        'iota_reference_productive_opportunity_lost': 70,
        'memory_source_counts': dict(source_counts),
        'selected_policy': selected_policy,
        'poisoned_memory_not_outperform': poison['hidden_downstream_pass'] <= cg['hidden_downstream_pass'],
        'predefined_memory_frozen_on_heldout': audit.get('predefined_memory_frozen_on_heldout') is True,
        'novel_heldout_families_absent_from_calibration': novel_absent_from_calibration,
        'discovered_vs_predefined_hidden_downstream_gap': discovered_vs_predefined_hidden_gap,
        'discovered_vs_predefined_productive_gap': discovered_vs_predefined_productive_gap,
        'novel_discovered_hidden_downstream': novel_discovered_hidden,
        'novel_predefined_hidden_downstream': novel_predefined_hidden,
        'novel_no_memory_hidden_downstream': novel_no_memory_hidden,
        'novel_discovered_vs_predefined_gap': novel_discovered_vs_predefined_gap,
        'novel_discovered_vs_no_memory_gap': novel_discovered_vs_no_memory_gap,
        'online_novel_learning_lift': online_novel_learning_lift,
        'sparse_exposure_classes': dict(sparse_classes),
        'one_shot_no_productive_overfit': one_shot_no_productive_overfit,
        'sparse_first_hidden_downstream': sparse_first_hidden,
        'sparse_later_hidden_downstream': sparse_later_hidden,
        'sparse_later_lift': sparse_later_lift
    }
    (out/'memory_ablation_report.json').write_text(json.dumps(mem_metrics,indent=2))
    write_csv(out/'productive_memory_report.csv',[mem_metrics])
    criteria=[]
    def add(name,value,passed,threshold=''):
        criteria.append({'criterion':name,'value':value,'threshold':threshold,'passed':bool(passed)})
    add('policy blindness passes',1,audit.get('policy_blind') is True,'true')
    add('no safe_action oracle injection',1,audit.get('safe_action_oracle_used') is False and audit.get('valid_action_oracle_used') is False,'true')
    add('maintenance success noninferior to best practice',cg['maintenance_success'], cg['maintenance_success'] >= bp['maintenance_success']-0.02, f">={bp['maintenance_success']-0.02:.3f}")
    add('corruption <= best practice',cg['corruption'], cg['corruption'] <= bp['corruption']+1e-9, f"<={bp['corruption']:.3f}")
    add('hidden downstream pass noninferior to best practice',cg['hidden_downstream_pass'], cg['hidden_downstream_pass'] >= bp['hidden_downstream_pass']-0.02, f">={bp['hidden_downstream_pass']-0.02:.3f}")
    add('action cost lower than always rebuild',cg['action_cost'], cg['action_cost'] < rb['action_cost'], f"<{rb['action_cost']:.3f}")
    add('productive lift vs no-memory > 0',mem_metrics['productive_lift_vs_no_memory'], mem_metrics['productive_lift_vs_no_memory']>0, '>0')
    add('hidden downstream lift vs no-memory > 0',mem_metrics['hidden_downstream_lift_vs_no_memory'], mem_metrics['hidden_downstream_lift_vs_no_memory']>0, '>0')
    add('corruption reduction vs no-memory > 0',mem_metrics['corruption_reduction_vs_no_memory'], mem_metrics['corruption_reduction_vs_no_memory']>0, '>0')
    add('memory false-positive transfer <= 0.20',false_positive, false_positive<=0.20, '<=0.20')
    add('poisoned memory does not outperform discovered memory',1 if mem_metrics['poisoned_memory_not_outperform'] else 0, mem_metrics['poisoned_memory_not_outperform'], 'true')
    add('memory helped more than hurt',helped-hurt, helped>hurt, '>0')
    add('productive recommendation precision >= 0.70',prod_precision, prod_precision>=0.70, '>=0.70')
    add('avoidance transfer precision >= 0.70',avoid_precision, avoid_precision>=0.70, '>=0.70')
    add('novel heldout families absent from calibration',1 if novel_absent_from_calibration else 0, novel_absent_from_calibration, 'true')
    add('predefined memory frozen on heldout',1 if mem_metrics['predefined_memory_frozen_on_heldout'] else 0, mem_metrics['predefined_memory_frozen_on_heldout'], 'true')
    add('discovered memory noninferior to predefined overall under sparsity',discovered_vs_predefined_hidden_gap, discovered_vs_predefined_hidden_gap >= -0.02, '>=-0.02 overall hidden gap')
    add('discovered memory outperforms predefined on sparse novel families',novel_discovered_vs_predefined_gap, novel_discovered_vs_predefined_gap > 0.25, '>0.25 sparse novel hidden gap')
    add('online discovered memory improves after first sparse exposure',sparse_later_lift, sparse_later_lift > 0.05, '>0.05 later-vs-first sparse lift')
    add('one-shot sparse families do not trigger productive overfit',1 if one_shot_no_productive_overfit else 0, one_shot_no_productive_overfit, 'true')
    add('proof ledger completeness = 100%',1, len(read_csv(out/'proof_ledger.csv')) == len(rows), '100%')
    passed=sum(c['passed'] for c in criteria); total=len(criteria)
    report={'passed':passed,'total':total,'criteria':criteria,'main_summary':summary,'memory_metrics':mem_metrics,'calibration_policy_report':cal}
    (out/'decision_report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({'passed':passed,'total':total},indent=2))
if __name__=='__main__': main()
