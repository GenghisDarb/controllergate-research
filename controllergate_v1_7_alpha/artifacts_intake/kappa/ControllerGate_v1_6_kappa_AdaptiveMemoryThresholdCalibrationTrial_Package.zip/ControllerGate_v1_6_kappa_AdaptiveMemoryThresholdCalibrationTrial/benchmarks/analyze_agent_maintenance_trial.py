import argparse, csv, json, collections
from pathlib import Path

def read_csv(path):
    if not Path(path).exists() or Path(path).stat().st_size == 0:
        return []
    with open(path,newline='') as f: return list(csv.DictReader(f))

def mean(rows,key):
    vals=[float(r[key]) for r in rows]
    return sum(vals)/len(vals) if vals else 0.0

def write_csv(path, rows):
    if not rows:
        Path(path).write_text('')
        return
    with open(path,'w',newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--outputs',required=True); args=ap.parse_args(); out=Path(args.outputs)
    rows=read_csv(out/'trial_log.csv')
    held=[r for r in rows if r.get('split')=='heldout']
    by=collections.defaultdict(list)
    for r in held: by[r['runtime']].append(r)
    summary=[]
    for rt,rs in sorted(by.items()):
        summary.append({'runtime':rt,'maintenance_success':mean(rs,'maintenance_success'),'productive_repair':mean(rs,'productive_repair'),
                        'human_required':mean(rs,'human_required'),'corruption':mean(rs,'corruption'),'action_cost':mean(rs,'action_cost'),
                        'changed_lines':mean(rs,'changed_lines'),'hidden_downstream_pass':mean(rs,'hidden_downstream_pass')})
    write_csv(out/'summary_by_runtime.csv', summary)
    S={s['runtime']:s for s in summary}
    cg=S['controllergate_discovered_memory']; nomem=S['controllergate_no_memory']; bp=S['strengthened_best_practice']; rb=S['always_rebuild']; poison=S['controllergate_poisoned_memory']
    transfers=read_csv(out/'memory_transfer_class_report.csv')
    disc=[t for t in transfers if t['runtime']=='controllergate_discovered_memory' and t.get('split')=='heldout']
    helped=sum(int(t['helped']) for t in disc); hurt=sum(int(t['hurt']) for t in disc)
    source_counts=collections.Counter(t['memory_source'] for t in disc)
    false_positive=hurt/max(1,helped+hurt)
    productive_recs=[r for r in by['controllergate_discovered_memory'] if r['memory_source']=='productive_recommendation']
    prod_precision=sum(1 for r in productive_recs if float(r['productive_repair'])>=0.9 and float(r['hidden_downstream_pass'])>=0.9 and float(r['corruption'])<=0.05)/max(1,len(productive_recs))
    avoidance=[t for t in disc if t['memory_source']=='avoidance_transfer']
    avoid_precision=(len(avoidance)-sum(int(t['hurt']) for t in avoidance))/max(1,len(avoidance))
    abstain=sum(1 for t in disc if t['memory_source']=='abstain_due_to_low_confidence')
    productive_lost=sum(int(t.get('productive_lost',0)) for t in disc)
    # Recurrence metrics from heldout signatures: precision = dominant family fraction; recall = compact signature coverage.
    sig_to_fam=collections.defaultdict(list); fam_to_sig=collections.defaultdict(set)
    for r in by['controllergate_discovered_memory']:
        sig_to_fam[r['signature']].append(r['hidden_family']); fam_to_sig[r['hidden_family']].add(r['signature'])
    pure=total=0
    for sig,fams in sig_to_fam.items():
        c=collections.Counter(fams); pure += c.most_common(1)[0][1]; total += len(fams)
    precision=pure/total if total else 0.0
    recall=sum(1 for fam,sigs in fam_to_sig.items() if len(sigs)<=2)/max(1,len(fam_to_sig))
    cal=read_csv(out/'calibration_policy_report.csv')
    selected=[r for r in cal if r.get('selected')=='True']
    selected_policy=selected[0]['policy'] if selected else 'balanced'
    audit=json.loads((out/'audit.json').read_text()) if (out/'audit.json').exists() else {}
    mem_metrics={
        'productive_lift_vs_no_memory': cg['productive_repair']-nomem['productive_repair'],
        'hidden_downstream_lift_vs_no_memory': cg['hidden_downstream_pass']-nomem['hidden_downstream_pass'],
        'corruption_reduction_vs_no_memory': nomem['corruption']-cg['corruption'],
        'recurrence_match_precision': precision,
        'recurrence_match_recall': recall,
        'memory_false_positive_transfer_rate': false_positive,
        'productive_recommendation_precision': prod_precision,
        'avoidance_transfer_precision': avoid_precision,
        'memory_helped': helped,
        'memory_hurt': hurt,
        'abstained_due_to_low_confidence': abstain,
        'productive_opportunity_lost': productive_lost,
        'iota_reference_abstentions': 98,
        'iota_reference_productive_opportunity_lost': 70,
        'memory_source_counts': dict(source_counts),
        'selected_policy': selected_policy,
        'poisoned_memory_not_outperform': poison['hidden_downstream_pass'] <= cg['hidden_downstream_pass']
    }
    (out/'memory_ablation_report.json').write_text(json.dumps(mem_metrics,indent=2))
    write_csv(out/'productive_memory_report.csv',[mem_metrics])
    criteria=[]
    def add(name,value,passed,threshold=''):
        criteria.append({'criterion':name,'value':value,'threshold':threshold,'passed':bool(passed)})
    add('policy blindness passes',1,audit.get('policy_blind') is True,'true')
    add('no safe_action oracle injection',1,audit.get('safe_action_oracle_used') is False and audit.get('valid_action_oracle_used') is False,'true')
    add('maintenance success noninferior to best practice',cg['maintenance_success'], cg['maintenance_success'] >= bp['maintenance_success']-0.02, f">={bp['maintenance_success']-0.02:.3f}")
    add('corruption <= best practice',cg['corruption'], cg['corruption'] <= bp['corruption']+1e-9, f"<={bp['corruption']:.3f}")
    add('hidden downstream pass noninferior to best practice',cg['hidden_downstream_pass'], cg['hidden_downstream_pass'] >= bp['hidden_downstream_pass']-0.02, f">={bp['hidden_downstream_pass']-0.02:.3f}")
    add('action cost lower than always rebuild',cg['action_cost'], cg['action_cost'] < rb['action_cost'], f"<{rb['action_cost']:.3f}")
    add('changed lines lower than always rebuild',cg['changed_lines'], cg['changed_lines'] < rb['changed_lines'], f"<{rb['changed_lines']:.3f}")
    add('productive lift vs no-memory > 0',mem_metrics['productive_lift_vs_no_memory'], mem_metrics['productive_lift_vs_no_memory']>0, '>0')
    add('hidden downstream lift vs no-memory > 0',mem_metrics['hidden_downstream_lift_vs_no_memory'], mem_metrics['hidden_downstream_lift_vs_no_memory']>0, '>0')
    add('corruption reduction vs no-memory > 0',mem_metrics['corruption_reduction_vs_no_memory'], mem_metrics['corruption_reduction_vs_no_memory']>0, '>0')
    add('recurrence precision >= 0.70',precision, precision>=0.70, '>=0.70')
    add('recurrence recall >= 0.50',recall, recall>=0.50, '>=0.50')
    add('memory false-positive transfer <= 0.20',false_positive, false_positive<=0.20, '<=0.20')
    add('poisoned memory does not outperform discovered memory',1 if mem_metrics['poisoned_memory_not_outperform'] else 0, mem_metrics['poisoned_memory_not_outperform'], 'true')
    add('memory helped more than hurt',helped-hurt, helped>hurt, '>0')
    add('productive recommendation precision >= 0.70',prod_precision, prod_precision>=0.70, '>=0.70')
    add('avoidance transfer precision >= 0.70',avoid_precision, avoid_precision>=0.70, '>=0.70')
    add('abstention decreases versus iota without increasing false positives',abstain, abstain < 98 and false_positive<=0.20, '<98 and FP<=0.20')
    add('productive opportunity lost decreases versus iota',productive_lost, productive_lost < 70, '<70')
    add('proof ledger completeness = 100%',1, len(read_csv(out/'proof_ledger.csv')) == len(rows), '100%')
    passed=sum(c['passed'] for c in criteria); total=len(criteria)
    report={'passed':passed,'total':total,'criteria':criteria,'main_summary':summary,'memory_metrics':mem_metrics,'calibration_policy_report':cal}
    (out/'decision_report.json').write_text(json.dumps(report,indent=2))
    print(json.dumps({'passed':passed,'total':total},indent=2))
if __name__=='__main__': main()
