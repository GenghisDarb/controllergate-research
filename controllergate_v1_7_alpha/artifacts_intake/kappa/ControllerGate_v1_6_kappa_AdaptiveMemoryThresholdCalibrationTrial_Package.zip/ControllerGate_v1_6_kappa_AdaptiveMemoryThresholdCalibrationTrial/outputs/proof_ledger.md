# v1.6-kappa Proof Ledger

Every scored trial includes runtime, split, action, outcome, policy mode, and proof hash. Calibration selects and freezes the balanced memory threshold policy before heldout scoring.
