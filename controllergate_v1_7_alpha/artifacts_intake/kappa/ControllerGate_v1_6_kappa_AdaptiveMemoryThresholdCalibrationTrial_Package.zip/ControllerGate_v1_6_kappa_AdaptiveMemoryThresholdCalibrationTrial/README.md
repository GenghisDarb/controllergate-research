# ControllerGate v1.6-kappa — Adaptive Memory Threshold Calibration Trial Prototype

Diagnostic prototype, not proof of self-maintaining software.

Run:

```bash
python -m benchmarks.run_agent_maintenance_trial --config locks/v1_6_kappa.json --out outputs
python -m benchmarks.analyze_agent_maintenance_trial --outputs outputs
sha256sum -c SHA256SUMS.txt
```

Verification rule: do not call this passed unless rerun outputs/decision_report.json, analyzer stdout, and SHA256 verification agree.
