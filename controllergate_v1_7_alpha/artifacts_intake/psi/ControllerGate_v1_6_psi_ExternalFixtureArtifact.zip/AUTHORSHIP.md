# External Fixture Artifact Authorship

Simulated independent external red-team fixture artifact for ControllerGate v1.6-psi. This artifact is intentionally separate from the benchmark code package.
