# ControllerGate v1.6-psi — Separate Fixture Artifact Custody Trial Prototype

Diagnostic prototype, not proof of self-maintaining software.

This benchmark code package intentionally does **not** bundle the red-team fixture artifact for scoring. The external fixture artifact must be supplied separately at runtime and must match the custody SHA locks in `locks/v1_6_psi.json`.

Required external artifact:

`ControllerGate_v1_6_psi_ExternalFixtureArtifact.zip`

Rerun:

```bash
python -m benchmarks.run_agent_maintenance_trial --config locks/v1_6_psi.json --fixture-artifact ../ControllerGate_v1_6_psi_ExternalFixtureArtifact.zip --out outputs
python -m benchmarks.analyze_agent_maintenance_trial --outputs outputs
sha256sum -c SHA256SUMS.txt
```
