import argparse,json
from pathlib import Path

def main():
    p=argparse.ArgumentParser(); p.add_argument('--outputs',required=True); a=p.parse_args()
    out=Path(a.outputs); out=out if out.is_absolute() else Path.cwd()/out
    data=json.loads((out/'decision_report.json').read_text())
    print(f"decision report: {data['passed']} / {data['total']} passed")
    failed=[c for c in data.get('criteria',[]) if not c.get('passed')]
    if failed:
        print('failed criteria:')
        for c in failed: print(f"- {c['criterion']}: {c['value']} threshold {c['threshold']}")
    else: print('all criteria passed')
if __name__=='__main__': main()
