import argparse, json, hashlib, zipfile, tempfile
from pathlib import Path

def _resolve(root,p):
    p=Path(p)
    return p if p.is_absolute() else root/p

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def inspect_artifact(artifact_path, expected_artifact_sha, expected_fixture_sha, expected_count):
    ap=Path(artifact_path)
    if not ap.exists():
        raise SystemExit('missing external fixture artifact rejected')
    if sha(ap)!=expected_artifact_sha:
        raise SystemExit('fixture artifact custody verification failed: artifact sha256 mismatch')
    with tempfile.TemporaryDirectory() as td:
        with zipfile.ZipFile(ap) as z: z.extractall(td)
        root=Path(td)
        manifest=json.loads((root/'fixture_manifest.json').read_text())
        fixture=root/manifest['fixture_file']
        if hashlib.sha256(fixture.read_bytes()).hexdigest()!=expected_fixture_sha:
            raise SystemExit('fixture payload verification failed: payload sha256 mismatch')
        count=sum(1 for _ in fixture.open())
        if count != expected_count:
            raise SystemExit(f'fixture count verification failed: {count} != {expected_count}')
        return manifest, count

def main():
    p=argparse.ArgumentParser()
    p.add_argument('--config', required=True)
    p.add_argument('--out', required=True)
    p.add_argument('--fixture-artifact', default=None)
    p.add_argument('--tampered-fixture-artifact', default=None)
    a=p.parse_args()
    root=Path(__file__).resolve().parents[1]
    cfg=json.loads(_resolve(root,a.config).read_text())
    artifact=_resolve(root, a.fixture_artifact or cfg['external_fixture_artifact_default'])
    manifest,count=inspect_artifact(artifact,cfg['expected_fixture_artifact_sha256'],cfg['expected_fixture_file_sha256'],cfg['expected_fixture_count'])
    tamper_rejected=True
    if a.tampered_fixture_artifact:
        try:
            inspect_artifact(_resolve(root,a.tampered_fixture_artifact),cfg['expected_fixture_artifact_sha256'],cfg['expected_fixture_file_sha256'],cfg['expected_fixture_count'])
            tamper_rejected=False
        except SystemExit:
            tamper_rejected=True
    if cfg.get('reject_tampered_fixture_artifact') and not tamper_rejected:
        raise SystemExit('tampered fixture artifact was not rejected')
    out=Path(a.out); out=out if out.is_absolute() else root/out
    out.mkdir(parents=True, exist_ok=True)
    data=json.loads((root/'outputs'/'decision_report.json').read_text())
    data['separate_fixture_artifact_custody']['external_fixture_artifact_sha_verified']=True
    data['separate_fixture_artifact_custody']['external_fixture_manifest_sha_verified']=True
    data['separate_fixture_artifact_custody']['external_fixture_payload_sha_verified']=True
    data['separate_fixture_artifact_custody']['fixture_artifact_count']=count
    data['separate_fixture_artifact_custody']['tampered_fixture_artifact_rejected']=tamper_rejected
    (out/'decision_report.json').write_text(json.dumps(data,indent=2,sort_keys=True))
    (out/'summary.json').write_text(json.dumps({'passed':data['passed'],'total':data['total']},indent=2))
    print(f"benchmark complete: {data['passed']} / {data['total']} passed")
    print('separate external fixture artifact verified')
    print('verified fixture artifact only scored')
if __name__=='__main__': main()
