# ControllerGate v1.6-iota — Precision-Gated Budget Memory Trial Prototype

Diagnostic prototype, not proof of self-maintaining software.

Run:

```bash
python -m benchmarks.run_agent_maintenance_trial --config locks/v1_6_iota.json --out outputs
python -m benchmarks.analyze_agent_maintenance_trial --outputs outputs
sha256sum -c SHA256SUMS.txt
```

This run splits causal trace memory into avoidance memory and productive recommendation memory under a 1–3 probe counterfactual budget.
