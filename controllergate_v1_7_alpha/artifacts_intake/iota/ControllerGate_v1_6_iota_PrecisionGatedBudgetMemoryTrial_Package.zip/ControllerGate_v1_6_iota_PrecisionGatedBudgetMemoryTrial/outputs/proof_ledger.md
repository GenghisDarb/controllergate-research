# v1.6-iota Proof Ledger

Every scored trial includes runtime, action, outcome, and proof hash. Memory transfer is split into avoidance and productive recommendation channels.
