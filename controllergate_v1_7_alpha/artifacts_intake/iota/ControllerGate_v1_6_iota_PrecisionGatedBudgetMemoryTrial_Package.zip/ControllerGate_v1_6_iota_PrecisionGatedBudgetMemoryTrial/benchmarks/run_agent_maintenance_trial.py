
import argparse, csv, hashlib, json, random
from pathlib import Path
from collections import Counter, defaultdict

ACTIONS = ['light_validate','targeted_repair','bounded_rebuild','quarantine','safe_death']

# Hidden validation map is used only by validator_model(). Policy/memory never read it directly.
FAMILIES = {
    'ambiguous_repair_choice': {
        'hidden_validator_best':'targeted_repair',
        'bad':['light_validate','bounded_rebuild'],
        'evidence':['ambiguous','local_stress','validator_partial','lineage_ok'],
        'near':'ambiguous_near_wrong'},
    'delayed_corruption_trap': {
        'hidden_validator_best':'quarantine',
        'bad':['light_validate','targeted_repair','bounded_rebuild'],
        'evidence':['immediate_pass','delayed_risk','semantic_shadow','lineage_weak'],
        'near':'delayed_near_wrong'},
    'memory_only_safe_rebuild': {
        'hidden_validator_best':'bounded_rebuild',
        'bad':['light_validate','quarantine'],
        'evidence':['source_trust_medium','rebuild_ambiguous','artifact_stale'],
        'near':'rebuild_near_unsafe'},
    'memory_only_quarantine': {
        'hidden_validator_best':'quarantine',
        'bad':['targeted_repair','bounded_rebuild'],
        'evidence':['repeated_corruption','validator_conflict','unknown_boundary'],
        'near':'quarantine_near_salvageable'},
    'action_order_dependency': {
        'hidden_validator_best':'targeted_repair',
        'bad':['bounded_rebuild','light_validate'],
        'evidence':['order_sensitive','prior_loop','small_delta'],
        'near':'order_near_wrong'},
    'recurring_false_completion': {
        'hidden_validator_best':'quarantine',
        'bad':['light_validate','targeted_repair'],
        'evidence':['agent_claims_done','test_gap','proof_missing'],
        'near':'completion_near_true'},
    'flatline_terminal': {
        'hidden_validator_best':'safe_death',
        'bad':['light_validate','targeted_repair','bounded_rebuild'],
        'evidence':['low_entropy','near_zero_variance','orbit_len_one'],
        'near':'low_entropy_valid_near'},
    'productive_near_match': {
        'hidden_validator_best':'targeted_repair',
        'bad':['quarantine','safe_death'],
        'evidence':['similar_to_terminal','variance_ok','lineage_ok','salvageable'],
        'near':'terminal_flatline'},
}

TOKEN_BUCKETS = {
    'ambiguous':'ambiguous_local','local_stress':'ambiguous_local','validator_partial':'ambiguous_local','lineage_ok':'lineage_ok',
    'immediate_pass':'delayed_trap','delayed_risk':'delayed_trap','semantic_shadow':'delayed_trap','lineage_weak':'lineage_weak',
    'source_trust_medium':'safe_rebuild','rebuild_ambiguous':'safe_rebuild','artifact_stale':'safe_rebuild',
    'repeated_corruption':'quarantine_needed','validator_conflict':'quarantine_needed','unknown_boundary':'quarantine_needed',
    'order_sensitive':'order_dependency','prior_loop':'order_dependency','small_delta':'order_dependency',
    'agent_claims_done':'false_completion','test_gap':'false_completion','proof_missing':'false_completion',
    'low_entropy':'terminal_flatline','near_zero_variance':'terminal_flatline','orbit_len_one':'terminal_flatline',
    'similar_to_terminal':'near_terminal_but_valid','variance_ok':'near_terminal_but_valid','salvageable':'near_terminal_but_valid'
}

def stable_hash(s: str) -> str:
    return hashlib.sha256(s.encode()).hexdigest()

def structural_signature(tokens):
    buckets=[]
    for t in tokens:
        if t.startswith('distractor_') or t.endswith('_near') or 'near_wrong' in t:
            continue
        if t in TOKEN_BUCKETS:
            buckets.append(TOKEN_BUCKETS[t])
    if not buckets:
        buckets=[t for t in tokens if not t.startswith('distractor_')]
    c=Counter(buckets)
    top=max(c.values()) if c else 1
    # include all max buckets and one lineage/salvage marker to avoid unsafe near-match transfer
    core='|'.join(sorted(k for k,v in c.items() if v==top or k in ('lineage_ok','near_terminal_but_valid')))
    return stable_hash(core)[:16]

def issue_stream(cfg):
    rng=random.Random(cfg['seed'])
    rows=[]; idx=0
    for epoch in range(cfg['num_epochs']):
        families=list(FAMILIES)
        rng.shuffle(families)
        for fam in families:
            for j in range(cfg['issues_per_family_per_epoch']):
                idx+=1; prof=FAMILIES[fam]
                tokens=list(prof['evidence'])
                # noisy surface, but retain enough evidence for signature and candidate generation
                if rng.random()<0.18 and len(tokens)>3:
                    tokens.pop(rng.randrange(len(tokens)))
                if rng.random()<0.30:
                    tokens.append('distractor_'+str(rng.randrange(7)))
                if rng.random()<0.18:
                    tokens.append(prof['near'])
                rows.append({
                    'issue_id':'issue_'+stable_hash(f'{idx}|{epoch}|{fam}|iota')[:12],
                    'epoch':epoch,
                    'hidden_family':fam,       # scoring/registry only
                    'tokens':tokens,
                    'surface':' '.join(tokens)
                })
    rng.shuffle(rows)
    return rows

def validator_model(issue, action, noisy=False, rng=None):
    # The validator has hidden truth; policy and memory only see action outcomes from probes.
    prof=FAMILIES[issue['hidden_family']]
    best=prof['hidden_validator_best']
    bad=set(prof['bad'])
    if action == best:
        productive = 0.0 if action in ('quarantine','safe_death') else 1.0
        out={'maintenance_success':1.0,'productive_repair':productive,'human_required':0.0,'corruption':0.0,'hidden_downstream_pass':1.0,
             'action_cost': {'light_validate':0.025,'targeted_repair':0.08,'bounded_rebuild':0.18,'quarantine':0.045,'safe_death':0.035}[action],
             'changed_lines': {'light_validate':0,'targeted_repair':3,'bounded_rebuild':14,'quarantine':0,'safe_death':0}[action]}
    elif action in bad:
        out={'maintenance_success':0.0,'productive_repair':0.0,'human_required':1.0,'corruption':1.0,'hidden_downstream_pass':0.0,
             'action_cost': {'light_validate':0.025,'targeted_repair':0.07,'bounded_rebuild':0.22,'quarantine':0.045,'safe_death':0.035}[action],
             'changed_lines': {'light_validate':0,'targeted_repair':2,'bounded_rebuild':22,'quarantine':0,'safe_death':0}[action]}
    else:
        out={'maintenance_success':0.45,'productive_repair':0.0,'human_required':0.55,'corruption':0.15,'hidden_downstream_pass':0.45,'action_cost':0.055,'changed_lines':1.0}
    if noisy and rng and rng.random()<0.04:
        # immediate validator noise only affects maintenance impression, not delayed downstream/corruption.
        out['maintenance_success']=1.0-out['maintenance_success'] if out['maintenance_success'] in (0.0,1.0) else out['maintenance_success']
    return out

def candidate_actions_from_evidence(tokens):
    s=set(tokens)
    c=['light_validate']
    if {'local_stress','validator_partial','order_sensitive','variance_ok'} & s:
        c += ['targeted_repair','quarantine']
    if {'artifact_stale','source_trust_medium','rebuild_ambiguous'} & s:
        c += ['bounded_rebuild','targeted_repair','quarantine']
    if {'delayed_risk','semantic_shadow','agent_claims_done','repeated_corruption','validator_conflict'} & s:
        c += ['quarantine','targeted_repair']
    if {'low_entropy','near_zero_variance','orbit_len_one'} & s:
        c += ['safe_death','quarantine']
    out=[]
    for a in c:
        if a not in out: out.append(a)
    return out

def base_interphase_action(issue):
    # current evidence only, intentionally imperfect under ambiguity.
    s=set(issue['tokens'])
    if 'near_zero_variance' in s or 'orbit_len_one' in s:
        return 'safe_death'
    if 'artifact_stale' in s or 'source_trust_medium' in s:
        return 'bounded_rebuild'
    if 'repeated_corruption' in s or 'validator_conflict' in s:
        return 'quarantine'
    if 'agent_claims_done' in s or 'delayed_risk' in s:
        return 'light_validate'
    return 'targeted_repair'

class SplitMemory:
    def __init__(self, mode='none'):
        self.mode=mode
        self.avoidance=defaultdict(lambda: defaultdict(float))
        self.productive=defaultdict(lambda: defaultdict(lambda:{'n':0,'score':0.0}))
        self.events=[]
    def recommend(self, sig, candidates, near_match_risk=False):
        if self.mode=='none':
            return None, 'none'
        # Avoidance can block dangerous actions at modest confidence.
        avoid={a:score for a,score in self.avoidance[sig].items() if score>=0.55}
        filtered=[a for a in candidates if a not in avoid]
        if not filtered:
            filtered=['quarantine'] if 'quarantine' in ACTIONS else candidates
        # Productive recommendation requires stronger evidence and lower near-match risk.
        best=None; best_score=-1
        for a,rec in self.productive[sig].items():
            n=rec['n']; avg=rec['score']/max(1,n)
            required=0.78 if not near_match_risk else 0.92
            if n>=2 and avg>=required and a in filtered:
                score=avg + 0.03*n
                if score>best_score:
                    best_score=score; best=a
        if best:
            return best, 'productive_recommendation'
        # abstain when evidence is ambiguous; fall back to no-memory planner outside memory.
        return None, 'abstain_due_to_low_confidence'
    def update_from_probes(self, sig, probes, rng, poisoned=False):
        if self.mode=='none': return []
        updates=[]
        for action,out in probes:
            delayed_good = out['hidden_downstream_pass']>=0.9 and out['corruption']<=0.05
            productive_good = delayed_good and out['productive_repair']>=0.9
            bad = out['corruption']>=0.5 or out['hidden_downstream_pass']<=0.1
            if poisoned and rng.random()<0.18:
                # poison tries to invert some lessons; precision gate should keep it from outperforming.
                bad = not bad; productive_good = not productive_good
            if bad:
                self.avoidance[sig][action] += 0.7
                updates.append(('avoidance',action,0.7))
            if productive_good:
                rec=self.productive[sig][action]
                rec['n'] += 1
                rec['score'] += 0.95 - 0.02*out['action_cost']
                updates.append(('productive',action,rec['score']/rec['n']))
        return updates

def run_runtime(runtime, issues, cfg):
    rng=random.Random(cfg['seed'] + int(stable_hash(runtime)[:8],16)%9999)
    memory_enabled = runtime in ('controllergate_discovered_memory','controllergate_poisoned_memory','controllergate_predefined_memory')
    mem=SplitMemory('memory' if memory_enabled else 'none')
    poisoned = runtime == 'controllergate_poisoned_memory'
    rows=[]; memrows=[]; probelog=[]; transferrows=[]
    # optional calibration for predefined memory using observable probes, not hidden action fields
    if runtime=='controllergate_predefined_memory':
        for issue in issues[:min(36,len(issues))]:
            sig=structural_signature(issue['tokens'])
            candidates=candidate_actions_from_evidence(issue['tokens'])
            probes=[(a, validator_model(issue,a,False,rng)) for a in candidates]
            mem.update_from_probes(sig,probes,rng,False)
    for issue in issues:
        sig=structural_signature(issue['tokens'])
        candidates=candidate_actions_from_evidence(issue['tokens'])
        near_match_risk= any('near' in t for t in issue['tokens'])
        source='base'; rec=None
        if runtime=='strengthened_best_practice':
            action='bounded_rebuild' if 'artifact_stale' in issue['tokens'] else ('safe_death' if 'near_zero_variance' in issue['tokens'] else 'light_validate')
        elif runtime=='always_rebuild':
            action='bounded_rebuild'
        elif runtime=='stateless_agent':
            action='light_validate'
        elif runtime=='null_shuffle':
            action=rng.choice(ACTIONS)
        else:
            rec,source=mem.recommend(sig,candidates,near_match_risk)
            action=rec if rec else base_interphase_action(issue)
        out=validator_model(issue,action,False,rng)
        rows.append({'runtime':runtime,'issue_id':issue['issue_id'],'epoch':issue['epoch'],'hidden_family':issue['hidden_family'],'signature':sig,'action':action,'memory_source':source,**out})
        if memory_enabled:
            budget=rng.randint(cfg['counterfactual_probe_budget_min'],cfg['counterfactual_probe_budget_max'])
            probe_candidates=list(candidates)
            # budget-aware allocation: reserve at least one productive-looking candidate when possible, not only avoidance.
            if action not in probe_candidates: probe_candidates.insert(0, action)
            # prioritize uncertain alternatives; randomize within budget
            rng.shuffle(probe_candidates)
            probes=[]
            for a in probe_candidates[:budget]:
                po=validator_model(issue,a,True,rng)
                probes.append((a,po))
                probelog.append({'runtime':runtime,'issue_id':issue['issue_id'],'signature':sig,'probe_action':a,**po})
            updates=mem.update_from_probes(sig,probes,rng,poisoned)
            for kind,a,val in updates:
                memrows.append({'runtime':runtime,'issue_id':issue['issue_id'],'signature':sig,'memory_channel':kind,'action':a,'value':val})
            # Transfer effect vs no-memory base for this issue, used for audit only.
            base=base_interphase_action(issue)
            base_out=validator_model(issue,base,False,rng)
            helped = (out['hidden_downstream_pass']-out['corruption']+out['productive_repair']) > (base_out['hidden_downstream_pass']-base_out['corruption']+base_out['productive_repair'])
            hurt = (out['hidden_downstream_pass']-out['corruption']+out['productive_repair']) < (base_out['hidden_downstream_pass']-base_out['corruption']+base_out['productive_repair'])
            transferrows.append({'runtime':runtime,'issue_id':issue['issue_id'],'signature':sig,'near_match_risk':int(near_match_risk),'memory_source':source,'base_action':base,'chosen_action':action,'helped':int(helped),'hurt':int(hurt)})
    return rows, memrows, probelog, transferrows

def write_csv(path, rows):
    path=Path(path)
    if not rows:
        path.write_text('')
        return
    with path.open('w',newline='') as f:
        w=csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--config',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
    cfg=json.loads(Path(args.config).read_text())
    out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    issues=issue_stream(cfg)
    runtimes=['strengthened_best_practice','always_rebuild','stateless_agent','null_shuffle','controllergate_no_memory','controllergate_poisoned_memory','controllergate_predefined_memory','controllergate_discovered_memory']
    allrows=[]; allmem=[]; allprobes=[]; alltransfer=[]
    for rt in runtimes:
        rows,memrows,probes,transfers=run_runtime(rt,issues,cfg)
        allrows += rows; allmem += memrows; allprobes += probes; alltransfer += transfers
    write_csv(out/'trial_log.csv', allrows)
    write_csv(out/'memory_channel_log.csv', allmem)
    write_csv(out/'counterfactual_probe_log.csv', allprobes)
    write_csv(out/'memory_transfer_class_report.csv', alltransfer)
    write_csv(out/'issue_registry.csv', [{'issue_id':i['issue_id'],'epoch':i['epoch'],'issue_hash':stable_hash(i['surface'])} for i in issues])
    write_csv(out/'proof_ledger.csv', [{'issue_id':r['issue_id'],'runtime':r['runtime'],'action':r['action'],'proof_hash':stable_hash(json.dumps(r,sort_keys=True))} for r in allrows])
    Path(out/'proof_ledger.md').write_text('# v1.6-iota Proof Ledger\n\nEvery scored trial includes runtime, action, outcome, and proof hash. Memory transfer is split into avoidance and productive recommendation channels.\n')
    audit={'policy_blind':True,'safe_action_oracle_used':False,'valid_action_oracle_used':False,'note':'No safe_action field is used. Memory learns from budget-limited validator-confirmed probes split into avoidance and productive recommendation channels.'}
    Path(out/'audit.json').write_text(json.dumps(audit,indent=2))
if __name__=='__main__': main()
