# ControllerGate v1.6-mu — Discovery-vs-Predefinition Separation Trial Prototype

Status: diagnostic prototype, not proof of self-maintaining software.

Purpose: stress-test whether discovered memory earns its advantage through online recurrence learning rather than receiving effectively equivalent predefined calibration structure.

Key additions over v1.6-lambda:
- heldout-only novel recurrence families absent from calibration;
- predefined memory is frozen during heldout and cannot adapt online;
- discovered memory is allowed to learn only from budget-limited validator-confirmed outcomes as heldout issues recur;
- changed action reliability after calibration;
- delayed outcomes and near-match pressure without hidden labels or safe-action oracle injection;
- explicit separation gates comparing discovered memory against predefined memory, especially on novel heldout-only families.

Rerun:

```bash
python -m benchmarks.run_agent_maintenance_trial --config locks/v1_6_mu.json --out outputs
python -m benchmarks.analyze_agent_maintenance_trial --outputs outputs
sha256sum -c SHA256SUMS.txt
```
