# v1.6-mu Proof Ledger

Every scored trial includes runtime, split, action, outcome, policy mode, drift metadata, and proof hash. Calibration selects and freezes the balanced memory threshold policy before heldout scoring with novel family drift and frozen predefined memory.
