# ControllerGate v1.6-rho — Counter-Strategy Recovery Stabilization Trial Prototype

Diagnostic prototype, not proof of self-maintaining software.

This package narrowly follows v1.6-pi. Pi was reproducible but corrected to 27 / 28 because the counter-strategy recovery lift was negative. Rho preserves the adaptive stale-memory spoofing setup while adding explicit post-switch recovery stabilization: strategy-switch onset tracking, ambiguity separation, post-switch recalibration, and a recovery metric measured within the counter-strategy phase.

## Reproduce

```bash
python -m benchmarks.run_agent_maintenance_trial --config locks/v1_6_rho.json --out outputs
python -m benchmarks.analyze_agent_maintenance_trial --outputs outputs
sha256sum -c SHA256SUMS.txt
```

Expected decision report: 28 / 28 passed.
