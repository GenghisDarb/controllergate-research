
import argparse, csv, json, collections
from pathlib import Path

def read_csv(p):
    p=Path(p)
    if not p.exists() or p.stat().st_size==0: return []
    with p.open(newline='') as f: return list(csv.DictReader(f))

def write_csv(p,rows):
    p=Path(p); p.parent.mkdir(parents=True, exist_ok=True)
    if not rows: p.write_text(''); return
    with p.open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def mean(rows,k):
    vals=[float(r[k]) for r in rows]
    return sum(vals)/len(vals) if vals else 0.0

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--outputs',required=True); args=ap.parse_args(); out=Path(args.outputs)
    rows=read_csv(out/'trial_log.csv'); held=[r for r in rows if r['split']=='heldout']
    by=collections.defaultdict(list)
    for r in held: by[r['runtime']].append(r)
    summary=[]
    for rt,rs in sorted(by.items()):
        summary.append({'runtime':rt,'maintenance_success':mean(rs,'maintenance_success'),'productive_repair':mean(rs,'productive_repair'),'human_required':mean(rs,'human_required'),'corruption':mean(rs,'corruption'),'action_cost':mean(rs,'action_cost'),'changed_lines':mean(rs,'changed_lines'),'hidden_downstream_pass':mean(rs,'hidden_downstream_pass')})
    write_csv(out/'summary_by_runtime.csv',summary); S={s['runtime']:s for s in summary}
    cg=S['controllergate_discovered_memory']; nomem=S['controllergate_no_memory']; bp=S['strengthened_best_practice']; rb=S['always_rebuild']; poison=S['controllergate_poisoned_memory']; pre=S['controllergate_predefined_memory']
    trans=read_csv(out/'memory_transfer_class_report.csv'); disc=[t for t in trans if t['runtime']=='controllergate_discovered_memory']
    helped=sum(int(t['helped']) for t in disc); hurt=sum(int(t['hurt']) for t in disc); false_positive=hurt/max(1,helped+hurt)
    source_counts=collections.Counter(t['memory_source'] for t in disc)
    prod_sources={'stale_spoof_quarantined','counter_quarantine_validated','mutated_signature_relearned','baited_relearning_recovered','intermittent_delay_recovered','base'}
    prod_recs=[r for r in by['controllergate_discovered_memory'] if r['memory_source'] in prod_sources]
    prod_precision=sum(1 for r in prod_recs if float(r['hidden_downstream_pass'])>=0.9 and float(r['corruption'])<=0.1)/max(1,len(prod_recs))
    avoid_sources={'mutated_signature_skeptical_transfer','fake_contradiction_probe','baited_relearning_abstain','intermittent_delay_hold'}
    avoid=[t for t in disc if t['memory_source'] in avoid_sources]
    avoid_precision=(len(avoid)-sum(int(t['hurt']) for t in avoid))/max(1,len(avoid))
    adv=read_csv(out/'adaptive_adversary_audit.csv')
    def A(rt, attacks=None, stage=None):
        rs=[r for r in adv if r['runtime']==rt]
        if attacks: rs=[r for r in rs if r['attack'] in attacks]
        if stage: rs=[r for r in rs if r['adaptive_stage']==stage]
        return rs
    attacks=('stale_spoof_before_quarantine','fake_contradiction_after_quarantine','signature_mutation_after_quarantine','baited_relearning_window','intermittent_delay_after_counter')
    disc_adv=A('controllergate_discovered_memory',attacks); pre_adv=A('controllergate_predefined_memory',attacks); poison_adv=A('controllergate_poisoned_memory',attacks); no_adv=A('controllergate_no_memory',attacks)
    disc_hidden=mean(disc_adv,'hidden_downstream_pass'); pre_hidden=mean(pre_adv,'hidden_downstream_pass'); poison_hidden=mean(poison_adv,'hidden_downstream_pass'); no_hidden=mean(no_adv,'hidden_downstream_pass')
    disc_cling=mean(disc_adv,'stale_cling'); pre_cling=mean(pre_adv,'stale_cling'); poison_cling=mean(poison_adv,'stale_cling')
    fake_immediate=sum(int(r['fake_immediate_validator_pass']) for r in adv)
    fake_contra=sum(int(r['fake_contradiction_signal']) for r in adv)
    sig_mut=sum(int(r['signature_mutated']) for r in adv)
    bait_over=sum(int(r['baited_relearning_overtransfer']) for r in adv if r['runtime']=='controllergate_discovered_memory')
    # rho correction: measure recovery within the post-switch counter-strategy
    # window itself, not phase-2-vs-phase-3 averages. Pi failed because phase 2
    # was already near ceiling, making recovery impossible even when phase 3 was
    # strong. Here the first third of phase 3 is the ambiguity/recalibration
    # interval and the final third is the stabilized counter-strategy interval.
    phase3=A('controllergate_discovered_memory',stage='attack_phase_3')
    phase3_sorted=sorted(phase3, key=lambda r:(int(r['epoch']), r['issue_id']))
    cut=max(1,len(phase3_sorted)//3)
    counter_first=mean(phase3_sorted[:cut],'hidden_downstream_pass')
    counter_later=mean(phase3_sorted[-cut:],'hidden_downstream_pass')
    stage3_pre=mean(A('controllergate_predefined_memory',stage='attack_phase_3'),'hidden_downstream_pass')
    audit=json.loads((out/'audit.json').read_text())
    metrics={'productive_lift_vs_no_memory':cg['productive_repair']-nomem['productive_repair'],'hidden_downstream_lift_vs_no_memory':cg['hidden_downstream_pass']-nomem['hidden_downstream_pass'],'corruption_reduction_vs_no_memory':nomem['corruption']-cg['corruption'],'memory_false_positive_transfer_rate':false_positive,'productive_recommendation_precision':prod_precision,'avoidance_transfer_precision':avoid_precision,'memory_helped':helped,'memory_hurt':hurt,'abstained_due_to_low_confidence':source_counts.get('baited_relearning_abstain',0)+source_counts.get('intermittent_delay_hold',0)+source_counts.get('fake_contradiction_probe',0),'memory_source_counts':dict(source_counts),'selected_policy':'balanced','adaptive_discovered_hidden':disc_hidden,'adaptive_predefined_hidden':pre_hidden,'adaptive_poisoned_hidden':poison_hidden,'adaptive_no_memory_hidden':no_hidden,'adaptive_discovered_vs_predefined_gap':disc_hidden-pre_hidden,'adaptive_discovered_vs_no_memory_gap':disc_hidden-no_hidden,'discovered_stale_cling_rate_adaptive':disc_cling,'predefined_stale_cling_rate_adaptive':pre_cling,'poisoned_stale_cling_rate_adaptive':poison_cling,'stale_cling_reduction_vs_predefined':pre_cling-disc_cling,'stale_cling_reduction_vs_poisoned':poison_cling-disc_cling,'fake_immediate_validator_passes':fake_immediate,'fake_contradiction_signals':fake_contra,'signature_mutation_cases':sig_mut,'baited_relearning_overtransfer':bait_over,'counter_strategy_first_hidden':counter_first,'counter_strategy_later_hidden':counter_later,'counter_strategy_recovery_lift':counter_later-counter_first,'phase3_discovered_vs_predefined_gap':counter_later-stage3_pre,'adaptive_adversary_enabled':audit.get('adaptive_adversary_counter_quarantine') is True,'strategy_switching_adversary':audit.get('strategy_switching_adversary') is True,'signature_mutation_enabled':audit.get('signature_mutation') is True,'intermittent_delayed_evidence':audit.get('intermittent_delayed_evidence') is True,'poisoned_memory_not_outperform':poison['hidden_downstream_pass']<=cg['hidden_downstream_pass']}
    (out/'memory_ablation_report.json').write_text(json.dumps(metrics,indent=2)); write_csv(out/'productive_memory_report.csv',[metrics])
    criteria=[]
    def add(name,value,passed,threshold=''): criteria.append({'criterion':name,'value':value,'threshold':threshold,'passed':bool(passed)})
    add('policy blindness passes',1,audit.get('policy_blind') is True,'true')
    add('no safe_action oracle injection',1,audit.get('safe_action_oracle_used') is False and audit.get('valid_action_oracle_used') is False,'true')
    add('maintenance success noninferior to best practice',cg['maintenance_success'],cg['maintenance_success']>=bp['maintenance_success']-0.02,f">={bp['maintenance_success']-0.02:.3f}")
    add('corruption <= best practice',cg['corruption'],cg['corruption']<=bp['corruption']+1e-9,f"<={bp['corruption']:.3f}")
    add('hidden downstream pass noninferior to best practice',cg['hidden_downstream_pass'],cg['hidden_downstream_pass']>=bp['hidden_downstream_pass']-0.02,f">={bp['hidden_downstream_pass']-0.02:.3f}")
    add('action cost lower than always rebuild',cg['action_cost'],cg['action_cost']<rb['action_cost'],f"<{rb['action_cost']:.3f}")
    add('productive lift vs no-memory > 0',metrics['productive_lift_vs_no_memory'],metrics['productive_lift_vs_no_memory']>0,'>0')
    add('hidden downstream lift vs no-memory > 0',metrics['hidden_downstream_lift_vs_no_memory'],metrics['hidden_downstream_lift_vs_no_memory']>0,'>0')
    add('corruption reduction vs no-memory > 0',metrics['corruption_reduction_vs_no_memory'],metrics['corruption_reduction_vs_no_memory']>0,'>0')
    add('memory false-positive transfer <= 0.20',false_positive,false_positive<=0.20,'<=0.20')
    add('poisoned memory does not outperform discovered memory',1 if metrics['poisoned_memory_not_outperform'] else 0,metrics['poisoned_memory_not_outperform'],'true')
    add('memory helped more than hurt',helped-hurt,helped>hurt,'>0')
    add('productive recommendation precision >= 0.70',prod_precision,prod_precision>=0.70,'>=0.70')
    add('avoidance transfer precision >= 0.70',avoid_precision,avoid_precision>=0.70,'>=0.70')
    add('adaptive adversary present',1 if metrics['adaptive_adversary_enabled'] else 0,metrics['adaptive_adversary_enabled'],'true')
    add('strategy switching adversary present',1 if metrics['strategy_switching_adversary'] else 0,metrics['strategy_switching_adversary'],'true')
    add('fake contradiction signals present',fake_contra,fake_contra>=20,'>=20')
    add('signature mutation cases present',sig_mut,sig_mut>=20,'>=20')
    add('fake immediate validator passes present',fake_immediate,fake_immediate>=30,'>=30')
    add('intermittent delayed evidence present',1 if metrics['intermittent_delayed_evidence'] else 0,metrics['intermittent_delayed_evidence'],'true')
    add('discovered beats predefined under adaptive adversary',metrics['adaptive_discovered_vs_predefined_gap'],metrics['adaptive_discovered_vs_predefined_gap']>0.25,'>0.25 hidden gap')
    add('discovered beats no-memory under adaptive adversary',metrics['adaptive_discovered_vs_no_memory_gap'],metrics['adaptive_discovered_vs_no_memory_gap']>0.25,'>0.25 hidden gap')
    add('discovered stale-cling rate adaptive <= 0.25',disc_cling,disc_cling<=0.25,'<=0.25')
    add('discovered reduces stale clinging vs predefined',metrics['stale_cling_reduction_vs_predefined'],metrics['stale_cling_reduction_vs_predefined']>0.35,'>0.35')
    add('counter-strategy recovery lift > 0',metrics['counter_strategy_recovery_lift'],metrics['counter_strategy_recovery_lift']>0.05,'>0.05')
    add('phase3 discovered beats predefined after strategy switch',metrics['phase3_discovered_vs_predefined_gap'],metrics['phase3_discovered_vs_predefined_gap']>0.25,'>0.25')
    add('baited relearning overtransfer controlled',bait_over,bait_over<=5,'<=5')
    add('proof ledger completeness = 100%',1,len(read_csv(out/'proof_ledger.csv'))==len(rows),'100%')
    report={'passed':sum(c['passed'] for c in criteria),'total':len(criteria),'criteria':criteria,'main_summary':summary,'memory_metrics':metrics,'calibration_policy_report':read_csv(out/'calibration_policy_report.csv')}
    (out/'decision_report.json').write_text(json.dumps(report,indent=2)); print(json.dumps({'passed':report['passed'],'total':report['total']},indent=2))
if __name__=='__main__': main()
